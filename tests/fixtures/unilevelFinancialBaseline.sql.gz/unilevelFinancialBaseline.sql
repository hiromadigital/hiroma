--
-- PostgreSQL database dump
--


-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: CommissionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommissionType" AS ENUM (
    'direct_referral',
    'binary_pairing',
    'multilevel',
    'sponsor_point',
    'deactivation_wallet_transfer',
    'rank_bonus'
);


--
-- Name: DistributorLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DistributorLevel" AS ENUM (
    'regional',
    'provincial',
    'city',
    'branch'
);


--
-- Name: HiroConversationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HiroConversationStatus" AS ENUM (
    'active',
    'closed'
);


--
-- Name: HiroMessageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HiroMessageRole" AS ENUM (
    'user',
    'hiro',
    'system'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'pending',
    'processing',
    'delivered',
    'cancelled',
    'ready_for_pickup'
);


--
-- Name: OrderType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderType" AS ENUM (
    'online',
    'offline'
);


--
-- Name: PayoutStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayoutStatus" AS ENUM (
    'pending',
    'approved',
    'rejected',
    'released'
);


--
-- Name: PinStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PinStatus" AS ENUM (
    'unused',
    'used',
    'expired',
    'cancelled',
    'in_transit'
);


--
-- Name: PosRegistrationIntakeStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PosRegistrationIntakeStatus" AS ENUM (
    'draft_intake',
    'pending_payment_verification',
    'payment_verified_ready_for_release',
    'released_pending_encoding',
    'encoding_in_progress',
    'registration_completed',
    'needs_correction',
    'payment_rejected',
    'cancelled_refund_required'
);


--
-- Name: PosShiftStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PosShiftStatus" AS ENUM (
    'open',
    'locally_closed',
    'finalized',
    'needs_review'
);


--
-- Name: PosTransactionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PosTransactionStatus" AS ENUM (
    'pending_sync',
    'syncing',
    'synced_pending_review',
    'approved',
    'needs_correction',
    'rejected',
    'finalized',
    'voided',
    'refunded'
);


--
-- Name: PosTransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PosTransactionType" AS ENUM (
    'member_sale',
    'non_member_sale',
    'new_reseller_registration'
);


--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductType" AS ENUM (
    'physical',
    'digital'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'admin',
    'regional',
    'provincial',
    'city',
    'reseller',
    'staff'
);


--
-- Name: SupportRequestCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportRequestCategory" AS ENUM (
    'suggestion',
    'feedback',
    'bug',
    'support',
    'account_access',
    'profile_and_verification',
    'digital_id',
    'registration_and_pin',
    'referral_and_sponsorship',
    'binary_tree_and_genealogy',
    'commissions_and_points',
    'wallet_and_payout',
    'orders_and_delivery',
    'products_and_pricing',
    'payment_issue',
    'website_or_app_problem',
    'security_and_account_safety',
    'other'
);


--
-- Name: SupportRequestPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportRequestPriority" AS ENUM (
    'low',
    'normal',
    'high',
    'urgent'
);


--
-- Name: SupportRequestSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportRequestSource" AS ENUM (
    'public',
    'member'
);


--
-- Name: SupportRequestStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportRequestStatus" AS ENUM (
    'new',
    'reviewing',
    'resolved'
);


--
-- Name: TreePosition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TreePosition" AS ENUM (
    'left',
    'right'
);


--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'active',
    'inactive',
    'suspended'
);


--
-- Name: accumulate_binary_daily_cap_usage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.accumulate_binary_daily_cap_usage() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE applied BIGINT;
BEGIN
 INSERT INTO binary_daily_cap_usage(user_id,pairing_day,used_pairs)
 VALUES(NEW.recipient_user_id,NEW.pairing_day,NEW.payable_pairs::bigint+NEW.inactive_flashout_pairs::bigint)
 ON CONFLICT(user_id,pairing_day) DO UPDATE
 SET used_pairs=binary_daily_cap_usage.used_pairs+EXCLUDED.used_pairs,updated_at=clock_timestamp()
 RETURNING used_pairs INTO applied;
 IF applied IS DISTINCT FROM NEW.closing_daily_pairing_count::bigint
 THEN RAISE EXCEPTION 'Daily cap usage does not match the immutable pair event.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: allocate_approved_binary_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_approved_binary_payout() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW."status" = 'approved' AND (TG_OP = 'INSERT' OR OLD."status" <> 'approved') THEN
    PERFORM "allocate_binary_payout"(NEW."id", NEW."user_id", NEW."amount", COALESCE(NEW."processed_at", CURRENT_TIMESTAMP));
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: allocate_approved_direct_referral_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_approved_direct_referral_payout() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.status = 'approved' AND (TG_OP = 'INSERT' OR OLD.status <> 'approved') THEN
    PERFORM allocate_direct_referral_payout(
      NEW.id, NEW.user_id, NEW.amount, COALESCE(NEW.processed_at, CURRENT_TIMESTAMP AT TIME ZONE 'UTC')
    );
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: allocate_approved_product_binary_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_approved_product_binary_payout() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$ BEGIN
 IF NEW.status='approved' AND (TG_OP='INSERT' OR OLD.status<>'approved') THEN
  PERFORM allocate_product_binary_payout(NEW.id,NEW.user_id,NEW.amount,COALESCE(NEW.processed_at,CURRENT_TIMESTAMP));
 END IF; RETURN NEW; END; $$;


--
-- Name: allocate_binary_payout(text, text, numeric, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_binary_payout(target_payout_id text, target_user_id text, payout_amount numeric, allocation_time timestamp with time zone) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  direct_used DECIMAL(12,2);
  binary_used DECIMAL(12,2);
  remaining DECIMAL(12,2);
  lot RECORD;
  consumed DECIMAL(12,2);
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(target_user_id, 0));
  PERFORM pg_advisory_xact_lock(hashtextextended(target_payout_id, 0));

  SELECT COALESCE(SUM("amount"), 0) INTO direct_used
  FROM "direct_referral_payout_consumptions" WHERE "payout_id" = target_payout_id;
  SELECT COALESCE(SUM("amount"), 0) INTO binary_used
  FROM "binary_payout_consumptions" WHERE "payout_id" = target_payout_id;
  remaining := GREATEST(payout_amount - direct_used - binary_used, 0);

  WHILE remaining > 0 LOOP
    SELECT l."id", l."remaining_amount" INTO lot
    FROM "binary_payable_lots" l
    WHERE l."user_id" = target_user_id
      AND l."remaining_amount" > 0
      AND l."allocated_at" <= allocation_time
      AND NOT EXISTS (
        SELECT 1 FROM "binary_payout_consumptions" c
        WHERE c."payout_id" = target_payout_id AND c."payable_lot_id" = l."id"
      )
    ORDER BY l."allocated_at" ASC, l."id" ASC
    FOR UPDATE OF l LIMIT 1;
    EXIT WHEN NOT FOUND;

    consumed := LEAST(remaining, lot."remaining_amount");
    INSERT INTO "binary_payout_consumptions" ("payout_id", "payable_lot_id", "amount", "allocated_at")
    VALUES (target_payout_id, lot."id", consumed, allocation_time);
    UPDATE "binary_payable_lots"
    SET "remaining_amount" = "remaining_amount" - consumed
    WHERE "id" = lot."id";
    remaining := remaining - consumed;
  END LOOP;
END;
$$;


--
-- Name: allocate_direct_referral_payout(text, text, numeric, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_direct_referral_payout(target_payout_id text, target_user_id text, payout_amount numeric, allocation_time timestamp without time zone) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  remaining DECIMAL(12,2);
  lot RECORD;
  consumed DECIMAL(12,2);
BEGIN
  IF payout_amount <= 0 OR EXISTS (
    SELECT 1 FROM "direct_referral_payout_consumptions" WHERE "payout_id" = target_payout_id
  ) THEN
    RETURN;
  END IF;

  remaining := payout_amount;
  WHILE remaining > 0 LOOP
    SELECT "id", "remaining_amount"
    INTO lot
    FROM "direct_referral_reserve_lots"
    WHERE "user_id" = target_user_id
      AND "remaining_amount" > 0
      AND "allocated_at" <= allocation_time
    ORDER BY "allocated_at" ASC, "id" ASC
    FOR UPDATE SKIP LOCKED
    LIMIT 1;

    EXIT WHEN NOT FOUND;

    consumed := LEAST(remaining, lot."remaining_amount");
    UPDATE "direct_referral_reserve_lots"
    SET "remaining_amount" = "remaining_amount" - consumed
    WHERE "id" = lot."id";

    INSERT INTO "direct_referral_payout_consumptions" (
      "payout_id", "reserve_lot_id", "amount", "allocated_at"
    ) VALUES (
      target_payout_id, lot."id", consumed, allocation_time
    );
    remaining := remaining - consumed;
  END LOOP;
END;
$$;


--
-- Name: allocate_product_binary_payout(text, text, numeric, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_product_binary_payout(target_payout_id text, target_user_id text, payout_amount numeric, allocation_time timestamp with time zone) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  used DECIMAL(12,2);
  remaining DECIMAL(12,2);
  lot RECORD;
  consumed DECIMAL(12,2);
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(target_user_id, 0));
  PERFORM pg_advisory_xact_lock(hashtextextended(target_payout_id, 0));

  SELECT COALESCE(SUM(x.amount), 0) INTO used FROM (
    SELECT amount FROM direct_referral_payout_consumptions WHERE payout_id = target_payout_id
    UNION ALL SELECT amount FROM binary_payout_consumptions WHERE payout_id = target_payout_id
    UNION ALL SELECT amount FROM product_binary_payout_consumptions WHERE payout_id = target_payout_id
  ) x;
  remaining := GREATEST(payout_amount - used, 0);

  WHILE remaining > 0 LOOP
    SELECT l.id, l.remaining_amount INTO lot
    FROM product_binary_payable_lots l
    WHERE l.user_id = target_user_id
      AND l.remaining_amount > 0
      AND l.allocated_at <= allocation_time
      AND NOT EXISTS (
        SELECT 1 FROM product_binary_payout_consumptions c
        WHERE c.payout_id = target_payout_id AND c.payable_lot_id = l.id
      )
    ORDER BY l.allocated_at, l.id
    FOR UPDATE OF l LIMIT 1;
    EXIT WHEN NOT FOUND;

    consumed := LEAST(remaining, lot.remaining_amount);
    INSERT INTO product_binary_payout_consumptions(payout_id, payable_lot_id, amount, allocated_at)
    VALUES(target_payout_id, lot.id, consumed, allocation_time);
    UPDATE product_binary_payable_lots
    SET remaining_amount = remaining_amount - consumed
    WHERE id = lot.id;
    remaining := remaining - consumed;
  END LOOP;
END;
$$;


--
-- Name: allocate_product_binary_pool_order_funding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_product_binary_pool_order_funding() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  sale record;
  item record;
  stock record;
  units_needed integer;
  units_taken integer;
  funded integer := 0;
BEGIN
  SELECT e.order_id, e.eligible_units, o.seller_id, u.role INTO STRICT sale
  FROM public.product_binary_order_events e JOIN public.orders o ON o.id = e.order_id
  JOIN public.users u ON u.id = o.seller_id WHERE e.id = NEW.order_event_id;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  IF sale.role = 'admin' THEN
    SELECT COALESCE(MAX(LEAST(sale.eligible_units, floor(remaining_amount / 5)::integer)), 0)
    INTO funded FROM public.product_binary_funding_lots
    WHERE order_id = sale.order_id AND reconciliation_status = 'exact';
  ELSIF sale.role = 'city' THEN
    FOR item IN
      SELECT product_id, SUM(quantity)::integer AS quantity
      FROM public.order_items WHERE order_id = sale.order_id
        AND binary_eligible_snapshot AND pu_value_snapshot > 0
      GROUP BY product_id ORDER BY product_id
    LOOP
      units_needed := item.quantity;
      FOR stock IN
        SELECT source_order_item_id, remaining_units FROM public.product_binary_inventory_reserves
        WHERE distributor_id = sale.seller_id AND product_id = item.product_id AND remaining_units > 0
        ORDER BY created_at, source_order_item_id FOR UPDATE
      LOOP
        units_taken := LEAST(units_needed, stock.remaining_units);
        UPDATE public.product_binary_inventory_reserves SET remaining_units = remaining_units - units_taken
        WHERE source_order_item_id = stock.source_order_item_id;
        INSERT INTO public.product_binary_inventory_reserve_transfers VALUES
          (NEW.order_event_id, stock.source_order_item_id, units_taken);
        funded := funded + units_taken;
        units_needed := units_needed - units_taken;
        EXIT WHEN units_needed = 0;
      END LOOP;
    END LOOP;
  END IF;
  NEW.funded_units := funded;
  RETURN NEW;
END;
$$;


--
-- Name: allocate_rank_bonus_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_rank_bonus_payout() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  available numeric;
  remaining numeric;
  lot record;
  consumed numeric;
BEGIN
  IF NEW.status <> 'approved' OR (TG_OP = 'UPDATE' AND OLD.status = NEW.status) THEN RETURN NEW; END IF;

  SELECT COALESCE(SUM(amount), 0) INTO available FROM (
    SELECT amount FROM direct_referral_payout_consumptions WHERE payout_id = NEW.id
    UNION ALL SELECT amount FROM binary_payout_consumptions WHERE payout_id = NEW.id
    UNION ALL SELECT amount FROM product_binary_payout_consumptions WHERE payout_id = NEW.id
    UNION ALL SELECT amount FROM rank_bonus_payout_consumptions WHERE payout_id = NEW.id
  ) existing;

  remaining := NEW.amount - available;
  IF remaining <= 0 THEN RETURN NEW; END IF;

  FOR lot IN
    SELECT award.id, award.remaining_amount FROM rank_bonus_awards award
    WHERE award.user_id = NEW.user_id AND award.remaining_amount > 0
    ORDER BY award.allocated_at, award.id
    FOR UPDATE
  LOOP
    consumed := LEAST(remaining, lot.remaining_amount);
    INSERT INTO rank_bonus_payout_consumptions (payout_id, award_id, amount) VALUES (NEW.id, lot.id, consumed);
    UPDATE rank_bonus_awards SET remaining_amount = remaining_amount - consumed WHERE id = lot.id;
    remaining := remaining - consumed;
    EXIT WHEN remaining = 0;
  END LOOP;
  RETURN NEW;
END;
$$;


--
-- Name: allocate_unilevel_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_unilevel_payout() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE allocated numeric; needed numeric; lot record; consumed numeric;
BEGIN
  IF NEW.status <> 'approved' OR (TG_OP='UPDATE' AND OLD.status=NEW.status) THEN RETURN NEW; END IF;
  SELECT COALESCE(SUM(amount),0) INTO allocated FROM (
    SELECT amount FROM direct_referral_payout_consumptions WHERE payout_id=NEW.id
    UNION ALL SELECT amount FROM binary_payout_consumptions WHERE payout_id=NEW.id
    UNION ALL SELECT amount FROM product_binary_payout_consumptions WHERE payout_id=NEW.id
    UNION ALL SELECT amount FROM rank_bonus_payout_consumptions WHERE payout_id=NEW.id
    UNION ALL SELECT amount FROM unilevel_payout_consumptions WHERE payout_id=NEW.id
  ) sources;
  needed:=NEW.amount-allocated;
  IF needed<=0 THEN RETURN NEW; END IF;
  FOR lot IN SELECT id,remaining_amount FROM public.unilevel_payable_lots
    WHERE user_id=NEW.user_id AND remaining_amount>0 ORDER BY allocated_at,id FOR UPDATE
  LOOP
    consumed:=LEAST(needed,lot.remaining_amount);
    INSERT INTO public.unilevel_payout_consumptions(payout_id,lot_id,amount) VALUES(NEW.id,lot.id,consumed);
    UPDATE public.unilevel_payable_lots SET remaining_amount=remaining_amount-consumed WHERE id=lot.id;
    needed:=needed-consumed;
    EXIT WHEN needed=0;
  END LOOP;
  RETURN NEW;
END;
$$;


--
-- Name: apply_commission_wallet_credit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_commission_wallet_credit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."is_pair_overflow" = false THEN
    INSERT INTO "wallet_ledger_entries" (
      "event_key", "user_id", "entry_type", "balance_delta", "reserved_delta",
      "total_earned_delta", "total_withdrawn_delta", "commission_id",
      "source_kind", "source_event_id", "metadata", "created_at"
    ) VALUES (
      'commission-credit:' || NEW."event_key", NEW."user_id", 'commission_credit',
      NEW."amount", 0, NEW."amount", 0, NEW."id",
      NEW."source_event_kind", NEW."source_event_id",
      jsonb_build_object('commission_type', NEW."type"::text, 'rule_version', NEW."rule_version"),
      NEW."created_at"
    );
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: apply_product_binary_expired_window(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_product_binary_expired_window(target_week date, recipient text) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  allocation public.product_binary_pool_allocations;
  surviving_pairs numeric;
  payable numeric;
BEGIN
  SELECT * INTO STRICT allocation FROM public.product_binary_pool_allocations a
  WHERE a.week_start = target_week AND a.recipient_user_id = recipient;
  IF allocation.retained_at IS NOT NULL THEN RETURN 0; END IF;

  surviving_pairs := public.product_binary_surviving_pairs(target_week, recipient);
  IF surviving_pairs IS NULL THEN RETURN allocation.amount_centavos; END IF;
  IF surviving_pairs = allocation.payable_pairs THEN RETURN allocation.amount_centavos; END IF;

  SELECT div(surviving_pairs * LEAST(w.pool_centavos::numeric, w.total_pairs::numeric * w.max_rate_centavos), w.total_pairs)
  INTO STRICT payable FROM public.product_binary_pool_weeks w WHERE w.week_start = target_week;
  IF payable >= allocation.amount_centavos THEN RETURN allocation.amount_centavos; END IF;
  IF payable = 0 THEN
    UPDATE public.product_binary_pool_allocations a
    SET retained_at = clock_timestamp(), retained_reason = '72-hour deactivation window expired.'
    WHERE a.week_start = target_week AND a.recipient_user_id = recipient;
  ELSE
    UPDATE public.product_binary_pool_allocations a
    SET partial_retained_centavos = allocation.amount_centavos - payable,
      retained_reason = 'Part of this bonus expired after the 72-hour deactivation window.'
    WHERE a.week_start = target_week AND a.recipient_user_id = recipient;
    UPDATE public.product_binary_week_funding f
    SET retained_centavos = f.retained_centavos + allocation.amount_centavos - payable
    WHERE f.week_start = target_week;
  END IF;
  RETURN payable::bigint;
END;
$$;


--
-- Name: apply_wallet_ledger_entry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_wallet_ledger_entry() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  commission_row "commissions"%ROWTYPE;
  payout_row "payouts"%ROWTYPE;
  recipient_role TEXT;
  recipient_status TEXT;
  funded_amount DECIMAL(12,2) := 0;
  unfunded_amount DECIMAL(12,2) := 0;
  source_available DECIMAL(12,2) := 0;
  earlier_pending DECIMAL(12,2) := 0;
  deactivation_amount DECIMAL(12,2) := 0;
  changed INTEGER := 0;
  reservation_exists BOOLEAN := false;
  reservation_release_exists BOOLEAN := false;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('financial-user:' || NEW."user_id"));

  SELECT u."role"::text, u."status"::text
  INTO recipient_role, recipient_status
  FROM "users" u
  WHERE u."id" = NEW."user_id"
  FOR SHARE;

  IF recipient_role IS NULL THEN
    RAISE EXCEPTION 'Wallet ledger recipient does not exist.' USING ERRCODE = '23503';
  END IF;

  IF NEW."entry_type" = 'commission_credit' THEN
    IF NEW."commission_id" IS NULL OR NEW."payout_id" IS NOT NULL THEN
      RAISE EXCEPTION 'Commission credit requires one commission and no payout.' USING ERRCODE = '23514';
    END IF;
    SELECT * INTO commission_row FROM "commissions" WHERE "id" = NEW."commission_id" FOR SHARE;
    IF NOT FOUND OR commission_row."user_id" <> NEW."user_id"
       OR commission_row."is_pair_overflow" = true
       OR recipient_role <> 'reseller' OR recipient_status <> 'active'
       OR NEW."balance_delta" <> commission_row."amount"
       OR NEW."total_earned_delta" <> commission_row."amount"
       OR NEW."reserved_delta" <> 0 OR NEW."total_withdrawn_delta" <> 0
       OR NEW."source_kind" <> commission_row."source_event_kind"
       OR NEW."source_event_id" <> commission_row."source_event_id" THEN
      RAISE EXCEPTION 'Commission wallet credit does not match an active reseller commission.' USING ERRCODE = '23514';
    END IF;

    IF commission_row."type" = 'direct_referral'::"CommissionType" THEN
      SELECT rf."direct_referral_allocation" INTO funded_amount
      FROM "registration_financials" rf
      WHERE rf."pin_id" = commission_row."source_event_id"
        AND rf."payment_status" = 'paid'
      FOR SHARE;
      IF funded_amount IS NULL OR commission_row."source_event_kind" <> 'registration'
         OR commission_row."amount" > funded_amount THEN
        RAISE EXCEPTION 'Direct referral commission is not funded by its registration snapshot.' USING ERRCODE = '23514';
      END IF;
    ELSIF commission_row."type" = 'binary_pairing'::"CommissionType" THEN
      SELECT
        COALESCE(SUM(c."amount") FILTER (WHERE c."is_unfunded" = false), 0),
        COALESCE(SUM(c."amount") FILTER (WHERE c."is_unfunded" = true), 0)
      INTO funded_amount, unfunded_amount
      FROM "binary_reserve_consumptions" c
      WHERE c."commission_id" = commission_row."id";
      IF funded_amount + unfunded_amount <> commission_row."amount" THEN
        RAISE EXCEPTION 'Package Binary funding position is not fully accounted.' USING ERRCODE = '23514';
      END IF;
    ELSIF commission_row."type" = 'sponsor_point'::"CommissionType" THEN
      SELECT
        COALESCE(SUM(c."amount") FILTER (WHERE c."is_unfunded" = false), 0),
        COALESCE(SUM(c."amount") FILTER (WHERE c."is_unfunded" = true), 0)
      INTO funded_amount, unfunded_amount
      FROM "product_binary_funding_consumptions" c
      WHERE c."commission_id" = commission_row."id";
      IF funded_amount <> commission_row."amount" OR unfunded_amount <> 0 THEN
        RAISE EXCEPTION 'Product Binary commission is not fully funded.' USING ERRCODE = '23514';
      END IF;
    ELSIF commission_row."type" = 'multilevel'::"CommissionType" THEN
      IF NOT EXISTS (
        SELECT 1 FROM public.unilevel_payable_lots lot
        JOIN public.unilevel_order_allocations allocation ON allocation.order_event_id=lot.order_event_id AND allocation.level=lot.level
        JOIN public.unilevel_order_funding funding ON funding.order_event_id=lot.order_event_id
        WHERE lot.commission_id=commission_row.id AND lot.original_amount=commission_row.amount
          AND lot.remaining_amount=lot.original_amount AND allocation.user_id=lot.user_id
          AND allocation.disposition='qualified'
          AND lot.original_amount=LEAST(allocation.bottle_count::numeric,trunc(funding.funded_amount /
            (SELECT COUNT(*) FROM public.unilevel_order_allocations slots WHERE slots.order_event_id=lot.order_event_id),2))
      ) THEN RAISE EXCEPTION 'Unilevel wallet credit requires its funded payable lot.' USING ERRCODE='23514'; END IF;
    ELSIF commission_row."type" = 'rank_bonus'::"CommissionType" THEN
      IF NOT EXISTS (
        SELECT 1 FROM public.rank_bonus_awards award
        WHERE award.commission_id = commission_row."id"
          AND award.original_amount = commission_row."amount"
          AND award.remaining_amount = commission_row."amount"
      ) THEN
        RAISE EXCEPTION 'Rank bonus wallet credit requires its funded award.' USING ERRCODE = '23514';
      END IF;
    ELSE
      RAISE EXCEPTION 'Unsupported commission cannot be credited.' USING ERRCODE = '23514';
    END IF;

  ELSIF NEW."entry_type" IN ('payout_reservation', 'payout_reservation_release', 'payout_disbursement') THEN
    IF NEW."payout_id" IS NULL OR NEW."commission_id" IS NOT NULL OR recipient_role <> 'reseller'
       OR NEW."source_kind" <> 'payout' OR NEW."source_event_id" <> NEW."payout_id" THEN
      RAISE EXCEPTION 'Payout ledger entry is invalid.' USING ERRCODE = '23514';
    END IF;
    SELECT * INTO payout_row FROM "payouts" WHERE "id" = NEW."payout_id" FOR SHARE;
    IF NOT FOUND OR payout_row."user_id" <> NEW."user_id" THEN
      RAISE EXCEPTION 'Payout ledger entry does not match its payout.' USING ERRCODE = '23514';
    END IF;

    IF NEW."entry_type" = 'payout_reservation' THEN
      SELECT
        COALESCE((SELECT SUM("remaining_amount") FROM "direct_referral_reserve_lots" WHERE "user_id" = NEW."user_id"), 0)
        + COALESCE((SELECT SUM("remaining_amount") FROM "binary_payable_lots" WHERE "user_id" = NEW."user_id"), 0)
        + COALESCE((SELECT SUM("remaining_amount") FROM "product_binary_payable_lots" WHERE "user_id" = NEW."user_id"), 0)
        + COALESCE((SELECT SUM("remaining_amount") FROM "rank_bonus_awards" WHERE "user_id" = NEW."user_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "unilevel_payable_lots" WHERE "user_id" = NEW."user_id"), 0)
      INTO source_available;
      SELECT COALESCE(SUM("amount"), 0) INTO earlier_pending
      FROM "payouts"
      WHERE "user_id" = NEW."user_id" AND "status" = 'pending'::"PayoutStatus" AND "id" <> NEW."payout_id";
      IF payout_row."status" <> 'pending'::"PayoutStatus"
         OR NEW."reserved_delta" <> payout_row."amount"
         OR NEW."balance_delta" <> 0 OR NEW."total_earned_delta" <> 0 OR NEW."total_withdrawn_delta" <> 0
         OR source_available - earlier_pending < payout_row."amount" THEN
        RAISE EXCEPTION 'Payout reservation exceeds source-backed withdrawable funds.' USING ERRCODE = '23514';
      END IF;
    ELSIF NEW."entry_type" = 'payout_reservation_release' THEN
      SELECT EXISTS (
        SELECT 1 FROM "wallet_ledger_entries"
        WHERE "payout_id" = NEW."payout_id" AND "entry_type" = 'payout_reservation'
      ) INTO reservation_exists;
      IF payout_row."status" <> 'rejected'::"PayoutStatus"
         OR reservation_exists = false
         OR NEW."reserved_delta" <> -payout_row."amount"
         OR NEW."balance_delta" <> 0 OR NEW."total_earned_delta" <> 0 OR NEW."total_withdrawn_delta" <> 0 THEN
        RAISE EXCEPTION 'Payout reservation release is invalid.' USING ERRCODE = '23514';
      END IF;
    ELSE
      SELECT EXISTS (
        SELECT 1 FROM "wallet_ledger_entries"
        WHERE "payout_id" = NEW."payout_id" AND "entry_type" = 'payout_reservation'
      ), EXISTS (
        SELECT 1 FROM "wallet_ledger_entries"
        WHERE "payout_id" = NEW."payout_id" AND "entry_type" = 'payout_reservation_release'
      ) INTO reservation_exists, reservation_release_exists;
      IF payout_row."status" <> 'released'::"PayoutStatus"
         OR reservation_exists = false OR reservation_release_exists = true
         OR NEW."balance_delta" <> -payout_row."amount"
         OR NEW."reserved_delta" <> -payout_row."amount"
         OR NEW."total_earned_delta" <> 0
         OR NEW."total_withdrawn_delta" <> payout_row."amount" THEN
        RAISE EXCEPTION 'Payout disbursement is invalid.' USING ERRCODE = '23514';
      END IF;
    END IF;

  ELSIF NEW."entry_type" = 'deactivation_forfeit' THEN
    SELECT e."wallet_value" INTO deactivation_amount
    FROM "reseller_deactivation_events" e
    WHERE e."id" = NEW."source_event_id" AND e."reseller_id" = NEW."user_id"
    FOR SHARE;
    IF deactivation_amount IS NULL OR recipient_role <> 'reseller' OR recipient_status <> 'inactive'
       OR NEW."balance_delta" <> -deactivation_amount
       OR NEW."reserved_delta" <> 0 OR NEW."total_earned_delta" <> 0 OR NEW."total_withdrawn_delta" <> 0 THEN
      RAISE EXCEPTION 'Deactivation wallet forfeiture is invalid.' USING ERRCODE = '23514';
    END IF;
  ELSE
    RAISE EXCEPTION 'Unsupported wallet ledger entry type.' USING ERRCODE = '23514';
  END IF;

  UPDATE "wallets"
  SET "balance" = "balance" + NEW."balance_delta",
      "reserved_balance" = "reserved_balance" + NEW."reserved_delta",
      "total_earned" = "total_earned" + NEW."total_earned_delta",
      "total_withdrawn" = "total_withdrawn" + NEW."total_withdrawn_delta",
      "updated_at" = CURRENT_TIMESTAMP
  WHERE "user_id" = NEW."user_id"
    AND "balance" + NEW."balance_delta" >= 0
    AND "reserved_balance" + NEW."reserved_delta" >= 0
    AND "balance" + NEW."balance_delta" >= "reserved_balance" + NEW."reserved_delta"
    AND "total_earned" + NEW."total_earned_delta" >= 0
    AND "total_withdrawn" + NEW."total_withdrawn_delta" >= 0;
  GET DIAGNOSTICS changed = ROW_COUNT;

  IF changed <> 1 THEN
    RAISE EXCEPTION 'Wallet ledger delta violates wallet balance invariants.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: author_wallet_ledger_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.author_wallet_ledger_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."created_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: can_supply_reward_stock(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.can_supply_reward_stock(supplier text, recipient text, replacement_kind text) RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
 SELECT supplier<>recipient AND EXISTS(
   SELECT 1 FROM users s JOIN users r ON r.id=recipient
   JOIN distributor_profiles buyer ON buyer.user_id=r.id
   LEFT JOIN distributor_profiles source ON source.user_id=s.id
   WHERE s.id=supplier AND s.status::text='active' AND r.status::text='active' AND buyer.is_active
    AND ((r.role::text='city' AND buyer.dist_level::text IN ('city','branch')) OR r.role::text=buyer.dist_level::text)
    AND buyer.dist_level::text IN ('city','branch','provincial','regional')
    AND ((s.role::text='admin' AND replacement_kind IN ('internal_replenishment','distributor_replacement'))
     OR (replacement_kind='distributor_replacement' AND buyer.dist_level::text<>'branch'
       AND source.is_active AND source.dist_level::text=s.role::text AND
         ((s.role::text='provincial' AND buyer.dist_level::text='city'
           AND NULLIF(btrim(source.province_code),'')=NULLIF(btrim(buyer.province_code),'')
           AND NULLIF(btrim(source.region_code),'')=NULLIF(btrim(buyer.region_code),''))
          OR (s.role::text='regional' AND buyer.dist_level::text IN ('city','provincial')
           AND NULLIF(btrim(source.region_code),'')=NULLIF(btrim(buyer.region_code),'')))))
 );
$$;


--
-- Name: capture_unilevel_qualification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.capture_unilevel_qualification() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  configured_levels integer := public.unilevel_level_count();
  month_start timestamptz;
BEGIN
  IF NEW.qualification_status <> 'qualified_paid_delivery'
     OR NEW.qualified_at IS NULL OR COALESCE(NEW.eligible_units_snapshot,0) <= 0 THEN RETURN NEW; END IF;
  INSERT INTO public.unilevel_qualified_orders(settlement_job_id,levels,qualified_at)
  VALUES(NEW.id,configured_levels,NEW.qualified_at) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RETURN NEW; END IF;
  month_start := date_trunc('month', NEW.qualified_at AT TIME ZONE 'Asia/Manila') AT TIME ZONE 'Asia/Manila';
  INSERT INTO public.unilevel_qualified_recipients(settlement_job_id,level,user_id,disposition)
  WITH RECURSIVE sponsors AS (
    SELECT 1 AS level,node.sponsor_id AS user_id,ARRAY[NEW.buyer_user_id,node.sponsor_id] AS visited
    FROM public.binary_tree_nodes node
    WHERE node.user_id=NEW.buyer_user_id AND node.sponsor_id <> NEW.buyer_user_id
    UNION ALL
    SELECT sponsor.level+1,node.sponsor_id,sponsor.visited||node.sponsor_id
    FROM sponsors sponsor JOIN public.binary_tree_nodes node ON node.user_id=sponsor.user_id
    WHERE sponsor.level < configured_levels AND node.sponsor_id <> ALL(sponsor.visited)
  )
  SELECT NEW.id,slot.level,sponsor.user_id,
    CASE WHEN sponsor.user_id IS NULL THEN 'no_sponsor'
      WHEN member.role IS DISTINCT FROM 'reseller' OR member.status IS DISTINCT FROM 'active'
        OR profile.is_active IS DISTINCT FROM true THEN 'inactive_account'
      WHEN NOT EXISTS (
        SELECT 1 FROM public.product_binary_settlement_jobs job
        WHERE job.buyer_user_id=sponsor.user_id AND job.qualification_status='qualified_paid_delivery'
          AND job.eligible_units_snapshot>=1 AND job.qualified_at>=month_start AND job.qualified_at<=NEW.qualified_at
      ) THEN 'monthly_purchase_required'
      ELSE 'qualified' END
  FROM generate_series(1,configured_levels) slot(level)
  LEFT JOIN sponsors sponsor ON sponsor.level=slot.level
  LEFT JOIN public.users member ON member.id=sponsor.user_id
  LEFT JOIN public.reseller_profiles profile ON profile.user_id=sponsor.user_id;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: product_binary_pool_weeks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pool_weeks (
    week_start date NOT NULL,
    max_rate_centavos integer NOT NULL,
    closed_at timestamp with time zone,
    total_pairs bigint,
    pool_centavos bigint,
    allocated_centavos bigint,
    released_at timestamp with time zone,
    readiness_checked_at timestamp with time zone,
    readiness_blocker text,
    release_started_at timestamp with time zone,
    CONSTRAINT product_binary_pool_weeks_check CHECK ((((closed_at IS NULL) AND (total_pairs IS NULL) AND (pool_centavos IS NULL) AND (allocated_centavos IS NULL)) OR ((closed_at IS NOT NULL) AND (total_pairs IS NOT NULL) AND (pool_centavos IS NOT NULL) AND (allocated_centavos IS NOT NULL) AND (closed_at >= (((week_start + 7))::timestamp without time zone AT TIME ZONE 'Asia/Manila'::text)) AND (total_pairs >= 0) AND (pool_centavos >= 0) AND ((allocated_centavos >= 0) AND (allocated_centavos <= pool_centavos))))),
    CONSTRAINT product_binary_pool_weeks_max_rate_centavos_check CHECK (((max_rate_centavos >= 50) AND (max_rate_centavos <= 2000))),
    CONSTRAINT product_binary_pool_weeks_week_start_check CHECK ((EXTRACT(isodow FROM week_start) = (1)::numeric))
);


--
-- Name: close_product_binary_pool_week(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_product_binary_pool_week(target_week date) RETURNS public.product_binary_pool_weeks
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  w public.product_binary_pool_weeks;
  preparation public.product_binary_week_preparation;
  source record;
  last_id uuid;
  last_recipient text;
  batch_total bigint := 0;
  batch_pairs bigint := 0;
  batch_allocated bigint := 0;
BEGIN
  SELECT * INTO STRICT w FROM public.product_binary_pool_weeks WHERE week_start = target_week FOR UPDATE;
  IF w.closed_at IS NOT NULL THEN RETURN w; END IF;
  IF clock_timestamp() < ((target_week + 7)::timestamp AT TIME ZONE 'Asia/Manila') THEN
    RAISE EXCEPTION 'Product Binary pool week has not reached its Manila cutoff.';
  END IF;
  INSERT INTO public.product_binary_week_preparation(week_start) VALUES(target_week) ON CONFLICT DO NOTHING;
  SELECT * INTO STRICT preparation FROM public.product_binary_week_preparation WHERE week_start = target_week;
  IF preparation.stage = 'orders' THEN
    FOR source IN
      SELECT o.order_event_id, COALESCE(o.funded_units, e.eligible_units)::bigint AS units
      FROM public.product_binary_pool_orders o JOIN public.product_binary_order_events e ON e.id = o.order_event_id
      WHERE o.week_start = target_week
        AND o.order_event_id >= COALESCE(preparation.order_cursor, '00000000-0000-0000-0000-000000000000'::uuid)
        AND o.order_event_id IS DISTINCT FROM preparation.order_cursor
      ORDER BY o.order_event_id LIMIT 5000
    LOOP
      batch_total := batch_total + source.units * 500;
      last_id := source.order_event_id;
    END LOOP;
    UPDATE public.product_binary_week_preparation
    SET pool_centavos = pool_centavos + batch_total, order_cursor = COALESCE(last_id, order_cursor),
      stage = CASE WHEN last_id IS NULL THEN 'pairs' ELSE stage END
    WHERE week_start = target_week;
    RETURN w;
  END IF;
  IF preparation.stage = 'pairs' THEN
    FOR source IN
      SELECT e.* FROM public.product_binary_pool_pairs p
      JOIN public.product_binary_pair_events e ON e.id = p.pair_event_id
      WHERE p.week_start = target_week
        AND p.pair_event_id >= COALESCE(preparation.pair_cursor, '00000000-0000-0000-0000-000000000000'::uuid)
        AND p.pair_event_id IS DISTINCT FROM preparation.pair_cursor
      ORDER BY p.pair_event_id LIMIT 5000
    LOOP
      IF source.normal_commission_id IS NOT NULL THEN
        RAISE EXCEPTION 'A Product Binary pair in the pool already has a per-order commission.';
      END IF;
      IF source.payable_pairs > 0 THEN
        INSERT INTO public.product_binary_prepared_recipients(week_start, recipient_user_id, payable_pairs)
        VALUES(target_week, source.recipient_user_id, source.payable_pairs)
        ON CONFLICT (week_start, recipient_user_id) DO UPDATE
        SET payable_pairs = product_binary_prepared_recipients.payable_pairs + EXCLUDED.payable_pairs;
      END IF;
      batch_pairs := batch_pairs + source.payable_pairs;
      last_id := source.id;
    END LOOP;
    UPDATE public.product_binary_week_preparation
    SET total_pairs = total_pairs + batch_pairs, pair_cursor = COALESCE(last_id, pair_cursor),
      stage = CASE WHEN last_id IS NULL THEN 'allocations' ELSE stage END
    WHERE week_start = target_week;
    RETURN w;
  END IF;
  IF preparation.stage = 'allocations' THEN
    FOR source IN
      SELECT recipient_user_id, payable_pairs
      FROM public.product_binary_prepared_recipients
      WHERE week_start = target_week
        AND recipient_user_id >= COALESCE(preparation.recipient_cursor, '')
        AND recipient_user_id IS DISTINCT FROM preparation.recipient_cursor
      ORDER BY recipient_user_id LIMIT 1000
    LOOP
      batch_total := div(source.payable_pairs::numeric *
        LEAST(preparation.pool_centavos::numeric, preparation.total_pairs::numeric * w.max_rate_centavos),
        preparation.total_pairs)::bigint;
      INSERT INTO public.product_binary_pool_allocations(week_start, recipient_user_id, payable_pairs, amount_centavos)
      VALUES(target_week, source.recipient_user_id, source.payable_pairs, batch_total);
      batch_allocated := batch_allocated + batch_total;
      last_recipient := source.recipient_user_id;
    END LOOP;
    UPDATE public.product_binary_week_preparation
    SET allocated_centavos = allocated_centavos + batch_allocated,
      recipient_cursor = COALESCE(last_recipient, recipient_cursor)
    WHERE week_start = target_week;
    IF last_recipient IS NOT NULL THEN RETURN w; END IF;
    -- The funding reservation trigger runs only when the final batch closes.
    UPDATE public.product_binary_pool_weeks
    SET closed_at = clock_timestamp(), total_pairs = preparation.total_pairs,
      pool_centavos = preparation.pool_centavos, allocated_centavos = preparation.allocated_centavos
    WHERE week_start = target_week RETURNING * INTO w;
    UPDATE public.product_binary_week_preparation SET stage = 'complete' WHERE week_start = target_week;
  END IF;
  RETURN w;
END;
$$;


--
-- Name: configure_financial_runtime_role(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.configure_financial_runtime_role(runtime_name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
DECLARE
  owner_id oid;
  role_id oid;
  role_risk boolean;
  object_name text;
  signature text;
  procedure_id regprocedure;
  protected_function record;
BEGIN
  SELECT proowner INTO owner_id FROM pg_proc
  WHERE oid='public.configure_financial_runtime_role(text)'::regprocedure;
  IF NOT pg_has_role(session_user,owner_id,'MEMBER') THEN
    RAISE EXCEPTION 'Only the migration owner can configure the financial runtime role.' USING ERRCODE='42501';
  END IF;
  IF runtime_name !~ '^[a-z][a-z0-9_]{0,62}$' THEN
    RAISE EXCEPTION 'Invalid runtime role name.';
  END IF;
  SELECT oid INTO role_id FROM pg_roles WHERE rolname=runtime_name;
  IF role_id IS NULL THEN RAISE EXCEPTION 'Runtime role does not exist.'; END IF;
  WITH RECURSIVE reachable(id) AS (
    SELECT role_id
    UNION
    SELECT membership.roleid FROM pg_auth_members membership
    JOIN reachable ON reachable.id=membership.member
  )
  SELECT EXISTS(
    SELECT 1 FROM reachable JOIN pg_roles role ON role.oid=reachable.id
    WHERE role.rolsuper OR role.rolcreaterole OR role.rolcreatedb
      OR role.rolreplication OR role.rolbypassrls
  ) INTO role_risk;
  IF role_risk OR pg_has_role(role_id,owner_id,'MEMBER') THEN
    RAISE EXCEPTION 'Runtime role has owner or administrative privileges.';
  END IF;
  IF EXISTS(SELECT 1 FROM pg_database WHERE datname=current_database() AND pg_has_role(role_id,datdba,'MEMBER'))
     OR EXISTS(SELECT 1 FROM pg_class class JOIN pg_namespace namespace ON namespace.oid=class.relnamespace
       WHERE namespace.nspname='public' AND pg_has_role(role_id,class.relowner,'MEMBER')) THEN
    RAISE EXCEPTION 'Runtime role owns application objects.';
  END IF;

  EXECUTE format('GRANT CONNECT ON DATABASE %I TO %I',current_database(),runtime_name);
  EXECUTE format('REVOKE CREATE, TEMP ON DATABASE %I FROM %I',current_database(),runtime_name);
  EXECUTE format('GRANT USAGE ON SCHEMA public TO %I',runtime_name);
  EXECUTE format('REVOKE CREATE ON SCHEMA public FROM %I',runtime_name);
  EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA public FROM %I',runtime_name);
  EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO %I',runtime_name);
  EXECUTE format('REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM %I',runtime_name);
  EXECUTE format('GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO %I',runtime_name);

  FOREACH object_name IN ARRAY ARRAY[
      'person_account_totals',
      'person_account_memberships',
      'person_account_documents',
      'binary_daily_cap_usage',
      'binary_reserve_lots',
      'binary_reserve_consumptions',
      'binary_payable_lots',
      'binary_payout_consumptions',
      'direct_referral_reserve_lots',
      'direct_referral_payout_consumptions',
      'product_binary_funding_lots',
      'product_binary_funding_consumptions',
      'product_binary_payable_lots',
      'product_binary_payout_consumptions',
      'product_binary_inventory_reserves',
      'product_binary_inventory_reserve_transfers',
      'product_binary_non_member_reserve_releases',
      'product_binary_non_member_reserve_restorations',
      'product_binary_replacement_reserve_releases',
      'product_binary_package_reserve_releases',
      'product_binary_pool_weeks',
      'product_binary_pool_orders',
      'product_binary_pool_pairs',
      'product_binary_pool_allocations',
      'product_binary_week_preparation',
      'product_binary_account_holds',
      'product_binary_prepared_recipients',
      'rank_bonus_awards',
      'rank_bonus_payout_consumptions',
      'payable_lot_forfeitures',
      'unilevel_inventory_earmarks',
      'unilevel_order_allocations',
      'unilevel_qualified_orders',
      'unilevel_qualified_recipients',
      'unilevel_order_settlements',
      'unilevel_payable_lots',
      'unilevel_retention_entries',
      'unilevel_payout_consumptions',
      '_prisma_migrations'
  ] LOOP
    IF to_regclass('public.'||object_name) IS NOT NULL THEN
      EXECUTE format('REVOKE INSERT, UPDATE, DELETE ON TABLE public.%I FROM %I',object_name,runtime_name);
    END IF;
  END LOOP;
  FOREACH object_name IN ARRAY ARRAY[
      'commissions',
      'wallet_ledger_entries',
      'wallets',
      'audit_logs',
      'registration_financials',
      'upgrade_financials',
      'direct_referral_settlement_events',
      'binary_settlement_events',
      'binary_pair_events',
      'product_binary_order_events',
      'product_binary_pair_events',
      'binary_point_consumptions',
      'binary_point_expirations',
      'financial_operation_receipts',
      'request_receipts',
      'rank_bonus_programs',
      'rank_bonus_funding'
  ] LOOP
    EXECUTE format('REVOKE UPDATE, DELETE ON TABLE public.%I FROM %I',object_name,runtime_name);
  END LOOP;
  REVOKE ALL ON FUNCTION public.configure_financial_runtime_role(text) FROM PUBLIC;
  EXECUTE format('REVOKE INSERT, DELETE ON TABLE public.product_binary_settlement_jobs FROM %I',runtime_name);
  EXECUTE format('REVOKE DELETE ON TABLE public.product_binary_positions,public.product_binary_pu_lots,public.binary_point_lots FROM %I',runtime_name);

  -- Trigger functions cannot be attached to a shadow table. SECURITY DEFINER
  -- helpers use explicit grants, including the synchronized release functions.
  EXECUTE format('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM %I',runtime_name);
  FOR protected_function IN
    SELECT procedure.oid::regprocedure AS signature
    FROM pg_proc procedure JOIN pg_namespace namespace ON namespace.oid=procedure.pronamespace
    WHERE namespace.nspname='public'
      AND (procedure.prosecdef OR procedure.prorettype='trigger'::regtype)
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC',protected_function.signature);
  END LOOP;
  FOREACH signature IN ARRAY ARRAY[
      'public.close_product_binary_pool_week(date)',
      'public.expire_deferred_product_binary_credits()',
      'public.process_rank_bonus_awards(timestamp with time zone,integer)',
      'public.product_binary_surviving_pairs(date,text)',
      'public.product_binary_weekly_pair_eligible(text)',
      'public.queue_product_binary_pool_order(uuid,timestamp with time zone,integer)',
      'public.release_product_binary_pool_week(date)',
      'public.retry_deferred_product_binary_credit(date,text)',
      'public.verify_product_binary_week_readiness(date)',
      'public.rank_bonus_progress(text,timestamp with time zone,timestamp with time zone)'
  ] LOOP
    procedure_id:=to_regprocedure(signature);
    IF procedure_id IS NULL THEN RAISE EXCEPTION 'Required runtime entry point is missing: %',signature; END IF;
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO %I',procedure_id,runtime_name);
  END LOOP;
END;
$_$;


--
-- Name: consume_binary_reserve(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.consume_binary_reserve() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  remaining DECIMAL(12,2);
  lot RECORD;
  consumed DECIMAL(12,2);
BEGIN
  IF NEW."type" <> 'binary_pairing' OR NEW."amount" <= 0 THEN
    RETURN NEW;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('binary-reserve-funding'));

  IF EXISTS (
    SELECT 1 FROM "binary_reserve_consumptions"
    WHERE "commission_id" = NEW."id"
  ) THEN
    RETURN NEW;
  END IF;

  remaining := NEW."amount";
  WHILE remaining > 0 LOOP
    SELECT "id", "remaining_amount"
    INTO lot
    FROM "binary_reserve_lots"
    WHERE "remaining_amount" > 0
    ORDER BY "allocated_at" ASC, "id" ASC
    FOR UPDATE
    LIMIT 1;

    EXIT WHEN NOT FOUND;

    consumed := LEAST(remaining, lot."remaining_amount");
    UPDATE "binary_reserve_lots"
    SET "remaining_amount" = "remaining_amount" - consumed
    WHERE "id" = lot."id";

    INSERT INTO "binary_reserve_consumptions" (
      "reserve_lot_id", "commission_id", "amount", "is_unfunded", "consumed_at"
    ) VALUES (lot."id", NEW."id", consumed, false, NEW."created_at");

    remaining := remaining - consumed;
  END LOOP;

  IF remaining > 0 THEN
    INSERT INTO "binary_reserve_consumptions" (
      "reserve_lot_id", "commission_id", "amount", "is_unfunded", "consumed_at"
    ) VALUES (NULL, NEW."id", remaining, true, NEW."created_at");
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: consume_product_binary_funding(text, numeric, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.consume_product_binary_funding(target_commission_id text, target_amount numeric, at_time timestamp with time zone) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  remaining DECIMAL(12,2);
  available DECIMAL(12,2);
  lot RECORD;
  used DECIMAL(12,2);
BEGIN
  IF target_amount <= 0 THEN
    RETURN;
  END IF;

  -- The pool is global, so serialize the complete availability check and FIFO
  -- consumption instead of locking only one commission ID.
  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));

  IF EXISTS (
    SELECT 1
    FROM "product_binary_funding_consumptions"
    WHERE "commission_id" = target_commission_id
  ) THEN
    RETURN;
  END IF;

  SELECT COALESCE(SUM(GREATEST(0, "remaining_amount" - public.product_binary_inventory_earmark("order_id"))), 0)
  INTO available
  FROM "product_binary_funding_lots"
  WHERE "remaining_amount" > public.product_binary_inventory_earmark("order_id")
    AND "allocated_at" <= at_time;


  available := available - public.product_binary_week_funding_held((
    SELECT CASE WHEN source_event_kind = 'product_binary_week' THEN source_event_id::date END
    FROM public.commissions WHERE id = target_commission_id
  ));
  IF available < target_amount THEN
    RAISE EXCEPTION USING
      ERRCODE = 'P0001',
      MESSAGE = 'Product Binary commission reserve is insufficient.',
      DETAIL = format(
        'commission_id=%s required=%s available=%s',
        target_commission_id,
        target_amount,
        available
      );
  END IF;

  remaining := target_amount;
  WHILE remaining > 0 LOOP
    SELECT "id", ("remaining_amount" - public.product_binary_inventory_earmark("order_id")) AS remaining_amount
    INTO lot
    FROM "product_binary_funding_lots"
    WHERE "remaining_amount" > public.product_binary_inventory_earmark("order_id")
      AND "allocated_at" <= at_time
    ORDER BY "allocated_at" ASC, "id" ASC
    FOR UPDATE
    LIMIT 1;

    IF NOT FOUND THEN
      RAISE EXCEPTION USING
        ERRCODE = 'P0001',
        MESSAGE = 'Product Binary reserve changed during consumption.',
        DETAIL = format(
          'commission_id=%s remaining_required=%s',
          target_commission_id,
          remaining
        );
    END IF;

    used := LEAST(remaining, lot."remaining_amount");
    UPDATE "product_binary_funding_lots"
    SET "remaining_amount" = "remaining_amount" - used
    WHERE "id" = lot."id";

    INSERT INTO "product_binary_funding_consumptions" (
      "funding_lot_id",
      "commission_id",
      "amount",
      "is_unfunded",
      "consumed_at"
    )
    VALUES (
      lot."id",
      target_commission_id,
      used,
      false,
      at_time
    );

    remaining := remaining - used;
  END LOOP;
END;
$$;


--
-- Name: create_binary_payable_lot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_binary_payable_lot() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW."type" = 'binary_pairing' AND NEW."is_pair_overflow" = false AND NEW."amount" > 0 THEN
    INSERT INTO "binary_payable_lots" ("commission_id", "user_id", "original_amount", "remaining_amount", "allocated_at")
    VALUES (NEW."id", NEW."user_id", NEW."amount", NEW."amount", NEW."created_at")
    ON CONFLICT ("commission_id") DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: create_binary_reserve_lot_for_registration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_binary_reserve_lot_for_registration() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO "binary_reserve_lots" (
    "registration_financial_id",
    "original_amount",
    "remaining_amount",
    "snapshot_source",
    "allocated_at"
  ) VALUES (
    NEW."id",
    NEW."binary_commission_allocation",
    NEW."binary_commission_allocation",
    NEW."allocation_snapshot_source",
    NEW."created_at"
  )
  ON CONFLICT ("registration_financial_id") DO NOTHING;

  RETURN NEW;
END;
$$;


--
-- Name: create_binary_reserve_lot_for_upgrade(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_binary_reserve_lot_for_upgrade() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO "binary_reserve_lots" (
    "upgrade_financial_id", "original_amount", "remaining_amount",
    "snapshot_source", "allocated_at"
  ) VALUES (
    NEW."id", NEW."binary_commission_allocation", NEW."binary_commission_allocation",
    NEW."allocation_snapshot_source", COALESCE(NEW."paid_at", NEW."created_at")
  )
  ON CONFLICT ("upgrade_financial_id") DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: create_direct_referral_reserve_lot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_direct_referral_reserve_lot() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW."type" = 'direct_referral'
    AND NEW."is_pair_overflow" = false
    AND NEW."amount" > 0 THEN
    INSERT INTO "direct_referral_reserve_lots" (
      "commission_id", "user_id", "original_amount", "remaining_amount", "snapshot_source", "allocated_at"
    ) VALUES (
      NEW."id", NEW."user_id", NEW."amount", NEW."amount", 'commission_credit', NEW."created_at"
    ) ON CONFLICT ("commission_id") DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: create_product_binary_payable_lot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_product_binary_payable_lot() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$ BEGIN
 IF NEW.type='sponsor_point' AND NEW.is_pair_overflow=false AND NEW.amount>0 THEN
  INSERT INTO product_binary_payable_lots(commission_id,user_id,original_amount,remaining_amount,allocated_at)
  VALUES(NEW.id,NEW.user_id,NEW.amount,NEW.amount,NEW.created_at) ON CONFLICT DO NOTHING;
 END IF; RETURN NEW; END; $$;


--
-- Name: credit_package_binary_product_reward(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.credit_package_binary_product_reward() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.product_reward_pairs > 0 THEN
    INSERT INTO public.package_binary_product_rewards
      (pair_event_id,user_id,product_id,product_name_snapshot,unit_cost_snapshot,quantity)
    SELECT NEW.id,NEW.recipient_user_id,p.id,p.name,p.cost_price,NEW.product_reward_pairs
    FROM public.products p WHERE p.id=NEW.reward_product_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'Reward bottle is unavailable.'; END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: credit_product_binary_pool_allocation(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.credit_product_binary_pool_allocation(target_week date, member_id text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  allocation public.product_binary_pool_allocations;
  credit_id text;
  credit_amount numeric;
  week_key text := to_char(target_week, 'YYYY-MM-DD');
BEGIN
  SELECT a.* INTO STRICT allocation
  FROM product_binary_pool_allocations a JOIN product_binary_pool_weeks w USING (week_start)
  WHERE a.week_start = target_week AND a.recipient_user_id = member_id AND w.closed_at IS NOT NULL
  FOR UPDATE OF a;

  IF allocation.commission_id IS NOT NULL OR allocation.amount_centavos = 0 THEN
    RETURN false;
  END IF;

  credit_id := gen_random_uuid()::text;
  credit_amount := public.apply_product_binary_expired_window(target_week, member_id)::numeric / 100;
  IF credit_amount = 0 THEN RETURN false; END IF;

  INSERT INTO commissions (
    id, event_key, source_event_kind, source_event_id, rule_version,
    user_id, type, amount, is_pair_overflow, created_at
  ) VALUES (
    credit_id, 'product-binary-week:' || week_key || ':' || member_id,
    'product_binary_week', week_key, 'product-binary-weekly-v1',
    member_id, 'sponsor_point', credit_amount, false, CURRENT_TIMESTAMP
  );

  UPDATE product_binary_pool_allocations SET commission_id = credit_id
  WHERE week_start = target_week AND recipient_user_id = member_id;

  IF NOT EXISTS (
    SELECT 1 FROM wallet_ledger_entries
    WHERE commission_id = credit_id AND entry_type = 'commission_credit'
      AND balance_delta = credit_amount AND total_earned_delta = credit_amount
  ) THEN
    RAISE EXCEPTION 'Weekly Product Binary allocation did not create an exact wallet credit.';
  END IF;

  RETURN true;
END;
$$;


--
-- Name: earmark_product_binary_branch_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.earmark_product_binary_branch_receipt() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  units_to_fund bigint;
  available numeric;
BEGIN
  IF OLD.status <> 'receiving' OR NEW.status NOT IN ('received_full','received_discrepancy')
     OR NOT EXISTS (
       SELECT 1 FROM public.distributor_profiles p
       WHERE p.user_id = NEW.recipient_id AND p.dist_level::text = 'branch'
     )
     OR NOT EXISTS (SELECT 1 FROM public.users WHERE id = NEW.admin_id AND role = 'admin') THEN
    RETURN NEW;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  SELECT COALESCE(SUM(m.accepted_quantity),0) INTO units_to_fund
  FROM public.inventory_movements m JOIN public.products p ON p.id = m.product_id::text
  WHERE m.transfer_id = NEW.id AND m.recipient_id::text = NEW.recipient_id AND m.admin_id::text = NEW.admin_id
    AND NOT m.is_sale AND m.accepted_quantity > 0 AND m.received_at IS NOT NULL
    AND p.binary_eligible AND p.pu_value > 0;
  IF units_to_fund = 0 THEN RETURN NEW; END IF;

  SELECT COALESCE(SUM(GREATEST(0, remaining_amount-public.product_binary_inventory_earmark(order_id))),0)
  INTO available FROM public.product_binary_funding_lots
  WHERE allocated_at <= CURRENT_TIMESTAMP AND remaining_amount > 0;
  IF units_to_fund * 5 > available - public.product_binary_week_funding_held() THEN
    RAISE EXCEPTION 'Branch receipt requires PHP 5 of available Product Binary funding per eligible bottle.' USING ERRCODE = '23514';
  END IF;

  INSERT INTO public.product_binary_inventory_reserves
    (source_order_item_id, source_movement_id, distributor_id, product_id, funded_units, remaining_units)
  SELECT 'branch:' || m.id::text, m.id, NEW.recipient_id, m.product_id::text, m.accepted_quantity, m.accepted_quantity
  FROM public.inventory_movements m JOIN public.products p ON p.id = m.product_id::text
  WHERE m.transfer_id = NEW.id AND m.recipient_id::text = NEW.recipient_id AND m.admin_id::text = NEW.admin_id
    AND NOT m.is_sale AND m.accepted_quantity > 0 AND m.received_at IS NOT NULL
    AND p.binary_eligible AND p.pu_value > 0;
  RETURN NEW;
END;
$$;


--
-- Name: earmark_product_binary_inventory_funding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.earmark_product_binary_inventory_funding() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  city_buyer text;
BEGIN
  IF NEW.reconciliation_status <> 'exact' OR NEW.order_id IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT o.buyer_id INTO city_buyer
  FROM public.orders o JOIN public.users u ON u.id = o.buyer_id
  WHERE o.id = NEW.order_id AND u.role = 'city';
  IF city_buyer IS NULL THEN RETURN NEW; END IF;

  IF NEW.remaining_amount < NEW.eligible_units_snapshot::numeric * 5 THEN
    RAISE EXCEPTION 'Qualified City Distributor stock requires PHP 5 Product Binary funding per unit.';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  INSERT INTO public.product_binary_inventory_reserves
    (source_order_item_id, distributor_id, product_id, funded_units, remaining_units)
  SELECT i.id, city_buyer, i.product_id, i.quantity, i.quantity
  FROM public.order_items i
  WHERE i.order_id = NEW.order_id AND i.binary_eligible_snapshot AND i.pu_value_snapshot > 0;
  RETURN NEW;
END;
$$;


--
-- Name: earmark_unilevel_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.earmark_unilevel_stock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
 INSERT INTO public.unilevel_inventory_earmarks(source_order_item_id,funded_units,levels)
 VALUES(NEW.source_order_item_id,NEW.funded_units,public.unilevel_level_count());
 RETURN NEW;
END;
$$;


--
-- Name: enforce_exclusive_distributor_territory(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_exclusive_distributor_territory() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  territory_scope TEXT;
  territory_code TEXT;
BEGIN
  IF NOT NEW.is_active THEN
    RETURN NEW;
  END IF;

  IF NEW.dist_level::text = 'regional' THEN
    territory_scope := 'regional';
    territory_code := NEW.region_code;
  ELSIF NEW.dist_level::text = 'provincial' THEN
    territory_scope := 'provincial';
    territory_code := NEW.province_code;
  ELSIF NEW.dist_level::text IN ('city', 'branch') THEN
    territory_scope := 'city_or_branch';
    territory_code := NEW.city_muni_code;
  ELSE
    RETURN NEW;
  END IF;

  IF territory_code IS NULL OR btrim(territory_code) = '' THEN
    RAISE EXCEPTION 'TERRITORY_CODE_REQUIRED' USING ERRCODE = '23514';
  END IF;

  -- Ordinary profile edits on a grandfathered assignment remain possible.
  IF TG_OP = 'UPDATE'
     AND OLD.is_active = NEW.is_active
     AND OLD.dist_level = NEW.dist_level
     AND (CASE territory_scope
       WHEN 'regional' THEN OLD.region_code IS NOT DISTINCT FROM NEW.region_code
       WHEN 'provincial' THEN OLD.province_code IS NOT DISTINCT FROM NEW.province_code
       ELSE OLD.city_muni_code IS NOT DISTINCT FROM NEW.city_muni_code
     END)
  THEN
    RETURN NEW;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtextextended('hiroma_territory:' || territory_scope || ':' || territory_code, 0));

  IF EXISTS (
    SELECT 1
    FROM distributor_profiles existing
    WHERE existing.id <> NEW.id
      AND existing.is_active
      AND (CASE territory_scope
        WHEN 'regional' THEN existing.dist_level::text = 'regional' AND existing.region_code = territory_code
        WHEN 'provincial' THEN existing.dist_level::text = 'provincial' AND existing.province_code = territory_code
        ELSE existing.dist_level::text IN ('city', 'branch') AND existing.city_muni_code = territory_code
      END)
  ) THEN
    RAISE EXCEPTION 'TERRITORY_ALREADY_ASSIGNED:%:%', territory_scope, territory_code USING ERRCODE = '23505';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: enforce_fixed_product_binary_package_plan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_fixed_product_binary_package_plan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."point_php_value" := 10;
  NEW."product_binary_cap_enabled" := true;
  NEW."daily_product_pairing_cap" := CASE LOWER(TRIM(NEW."name"))
    WHEN 'gold' THEN 100
    WHEN 'silver' THEN 40
    ELSE 20
  END;
  RETURN NEW;
END;
$$;


--
-- Name: enforce_fixed_product_binary_rank_rate(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_fixed_product_binary_rank_rate() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."pair_income" := 10;
  RETURN NEW;
END;
$$;


--
-- Name: enforce_lifetime_person_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_lifetime_person_accounts() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE member users%ROWTYPE; key TEXT; previous_key TEXT; document_key TEXT; changed INTEGER;
BEGIN
 SELECT * INTO member FROM users WHERE id=NEW.id;
 SELECT person_key INTO previous_key FROM person_account_memberships WHERE user_id=NEW.id;
 IF NOT FOUND AND member.role::text<>'reseller' THEN RETURN NULL; END IF;
 IF member.role::text<>'reseller' THEN
   RAISE EXCEPTION 'A registered reseller identity cannot be removed by changing its role.' USING ERRCODE='23514';
 END IF;
 IF member.birthday IS NULL OR member.identity_document_hash IS NULL OR length(trim(member.full_name))=0 THEN
   RAISE EXCEPTION 'Complete legal name, birthday and verified ID are required for the lifetime account limit.' USING ERRCODE='23514';
 END IF;
 key:=person_account_key(member.full_name,member.birthday);
 IF previous_key IS NOT NULL AND previous_key<>key THEN
   RAISE EXCEPTION 'Registered legal name and birthday require identity review and cannot be reassigned.' USING ERRCODE='23514';
 END IF;
 IF previous_key IS NULL THEN
   INSERT INTO person_account_totals(person_key,account_count) VALUES(key,1)
   ON CONFLICT(person_key) DO UPDATE SET account_count=person_account_totals.account_count+1
   WHERE person_account_totals.account_count<7;
   GET DIAGNOSTICS changed=ROW_COUNT;
   IF changed<>1 THEN RAISE EXCEPTION 'Maximum accounts (7) reached for this person, including inactive and suspended accounts.' USING ERRCODE='23514'; END IF;
   INSERT INTO person_account_memberships(user_id,person_key) VALUES(member.id,key);
 END IF;
 INSERT INTO person_account_documents(document_hash,person_key) VALUES(member.identity_document_hash,key)
 ON CONFLICT(document_hash) DO NOTHING;
 SELECT person_key INTO document_key FROM person_account_documents WHERE document_hash=member.identity_document_hash;
 IF document_key IS DISTINCT FROM key THEN
   RAISE EXCEPTION 'This ID belongs to an existing identity with different legal details. Identity review is required.' USING ERRCODE='23514';
 END IF;
 RETURN NULL;
END $$;


--
-- Name: enforce_order_message_participants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_order_message_participants() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE source_order "orders"%ROWTYPE;
BEGIN
  SELECT * INTO source_order FROM "orders" WHERE "id" = NEW."order_id" FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Order does not exist'; END IF;
  IF source_order."status" IN ('delivered', 'cancelled') THEN RAISE EXCEPTION 'Order conversation is closed'; END IF;
  IF NEW."sender_id" <> source_order."buyer_id" AND NEW."sender_id" <> source_order."seller_id"
     AND NOT EXISTS (SELECT 1 FROM "staff_profiles" WHERE "user_id" = NEW."sender_id" AND "owner_id" IN (source_order."buyer_id", source_order."seller_id") AND "is_active" = TRUE)
  THEN RAISE EXCEPTION 'Sender is not an order participant'; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: enforce_payout_identity_and_status_transition(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_payout_identity_and_status_transition() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  approver_role TEXT;
  approver_status TEXT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    NEW."requested_at" := (transaction_timestamp() AT TIME ZONE 'UTC')::TIMESTAMP(3);

    IF NEW."status" <> 'pending'::"PayoutStatus" THEN
      RAISE EXCEPTION 'Payouts must be created in pending status.' USING ERRCODE = 'P0001';
    END IF;
    IF NEW."amount" <= 0
       OR NEW."payment_method" IS NULL OR length(btrim(NEW."payment_method")) = 0
       OR NEW."cutoff_date" IS NULL OR NEW."payout_date" IS NULL THEN
      RAISE EXCEPTION 'A payout request requires a positive amount, payment method, cutoff, and release date.' USING ERRCODE = '23514';
    END IF;
    IF NEW."approved_by" IS NOT NULL OR NEW."processed_at" IS NOT NULL
       OR NEW."released_at" IS NOT NULL OR NEW."transaction_number" IS NOT NULL THEN
      RAISE EXCEPTION 'A pending payout cannot be pre-approved or pre-released.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW."id" IS DISTINCT FROM OLD."id" THEN
    RAISE EXCEPTION 'Payout identity is immutable after creation.' USING ERRCODE = 'P0001';
  END IF;
  IF NEW."user_id" IS DISTINCT FROM OLD."user_id" THEN
    RAISE EXCEPTION 'Payout recipient is immutable after creation.' USING ERRCODE = 'P0001';
  END IF;
  IF NEW."amount" IS DISTINCT FROM OLD."amount" THEN
    RAISE EXCEPTION 'Payout amount is immutable after creation.' USING ERRCODE = 'P0001';
  END IF;
  IF NEW."payment_method" IS DISTINCT FROM OLD."payment_method"
     OR NEW."payment_reference" IS DISTINCT FROM OLD."payment_reference"
     OR NEW."cutoff_date" IS DISTINCT FROM OLD."cutoff_date"
     OR NEW."payout_date" IS DISTINCT FROM OLD."payout_date"
     OR NEW."requested_at" IS DISTINCT FROM OLD."requested_at" THEN
    RAISE EXCEPTION 'Payout destination and schedule are immutable after request.' USING ERRCODE = '55000';
  END IF;

  IF NEW."status" IS NOT DISTINCT FROM OLD."status" THEN
    IF NEW."transaction_number" IS DISTINCT FROM OLD."transaction_number"
       OR NEW."approved_by" IS DISTINCT FROM OLD."approved_by"
       OR NEW."processed_at" IS DISTINCT FROM OLD."processed_at"
       OR NEW."released_at" IS DISTINCT FROM OLD."released_at"
       OR NEW."notes" IS DISTINCT FROM OLD."notes" THEN
      RAISE EXCEPTION 'Payout processing evidence may change only during a legal status transition.' USING ERRCODE = '55000';
    END IF;
    RETURN NEW;
  END IF;

  IF OLD."status" = 'pending'::"PayoutStatus"
     AND NEW."status" IN ('approved'::"PayoutStatus", 'rejected'::"PayoutStatus") THEN
    NEW."processed_at" := (transaction_timestamp() AT TIME ZONE 'UTC')::TIMESTAMP(3);

    IF NEW."approved_by" IS NULL OR NEW."released_at" IS NOT NULL THEN
      RAISE EXCEPTION 'Payout approval or rejection requires complete reviewer evidence.' USING ERRCODE = '23514';
    END IF;
    SELECT user_row."role"::text, user_row."status"::text
    INTO approver_role, approver_status
    FROM "public"."users" user_row
    WHERE user_row."id" = NEW."approved_by"
    FOR SHARE;
    IF approver_role <> 'admin' OR approver_status <> 'active' THEN
      RAISE EXCEPTION 'Payout reviewer must be an active administrator.' USING ERRCODE = '23514';
    END IF;
    IF NEW."status" = 'approved'::"PayoutStatus"
       AND (NEW."transaction_number" IS NULL OR length(btrim(NEW."transaction_number")) = 0) THEN
      RAISE EXCEPTION 'An approved payout requires an immutable transaction number.' USING ERRCODE = '23514';
    END IF;
    IF NEW."status" = 'rejected'::"PayoutStatus" AND NEW."transaction_number" IS NOT NULL THEN
      RAISE EXCEPTION 'A rejected payout cannot carry a release transaction number.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  IF OLD."status" = 'approved'::"PayoutStatus"
     AND NEW."status" = 'released'::"PayoutStatus" THEN
    NEW."released_at" := transaction_timestamp();

    IF NEW."approved_by" IS DISTINCT FROM OLD."approved_by"
       OR NEW."processed_at" IS DISTINCT FROM OLD."processed_at"
       OR NEW."transaction_number" IS DISTINCT FROM OLD."transaction_number"
       OR NEW."notes" IS DISTINCT FROM OLD."notes" THEN
      RAISE EXCEPTION 'Payout release must preserve approval evidence and record its release time.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  RAISE EXCEPTION 'Illegal payout status transition.' USING ERRCODE = 'P0001';
END;
$$;


--
-- Name: enforce_reseller_payout_destination_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_reseller_payout_destination_owner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  account_role TEXT;
  owner_identity_hash VARCHAR(64);
  destination_hash_value VARCHAR(64);
  changed_count INTEGER;
BEGIN
  SELECT usr."role"::TEXT, usr."identity_document_hash"
  INTO account_role, owner_identity_hash
  FROM "users" usr WHERE usr."id" = NEW."user_id" FOR SHARE;
  IF account_role IS DISTINCT FROM 'reseller' THEN RETURN NEW; END IF;
  IF owner_identity_hash IS NULL OR length(owner_identity_hash) <> 64 THEN
    RAISE EXCEPTION 'A reseller needs a verified identity before registering a payout destination.' USING ERRCODE = '23514';
  END IF;
  destination_hash_value := encode(digest(
    lower(btrim(NEW."type")) || '|' || lower(btrim(COALESCE(NEW."bank_name", ''))) || '|' ||
    upper(regexp_replace(NEW."account_number", '[^A-Za-z0-9]', '', 'g')), 'sha256'
  ), 'hex');
  INSERT INTO "payout_destination_owners" ("destination_hash", "identity_hash", "first_registered_by")
  VALUES (destination_hash_value, owner_identity_hash, NEW."user_id")
  ON CONFLICT ("destination_hash") DO UPDATE SET "updated_at" = CURRENT_TIMESTAMP
  WHERE "payout_destination_owners"."identity_hash" = EXCLUDED."identity_hash";
  GET DIAGNOSTICS changed_count = ROW_COUNT;
  IF changed_count <> 1 THEN
    RAISE EXCEPTION 'This payout destination is permanently registered to another verified person.' USING ERRCODE = '23505';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: enforce_reseller_payout_recipient(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_reseller_payout_recipient() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  recipient_role "Role";
BEGIN
  SELECT "role"
  INTO recipient_role
  FROM "users"
  WHERE "id" = NEW."user_id"
  FOR SHARE;

  IF recipient_role IS NULL OR recipient_role <> 'reseller'::"Role" THEN
    RAISE EXCEPTION USING
      ERRCODE = 'P0001',
      MESSAGE = 'Payout recipient must be a reseller.',
      DETAIL = format('payout_id=%s user_id=%s', NEW."id", NEW."user_id");
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: enforce_reseller_pickup_schedule(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_reseller_pickup_schedule() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND (
    NEW.pickup_scheduled_at IS DISTINCT FROM OLD.pickup_scheduled_at OR
    NEW.pickup_schedule_timezone IS DISTINCT FROM OLD.pickup_schedule_timezone
  ) THEN
    RAISE EXCEPTION 'PICKUP_SCHEDULE_IS_IMMUTABLE' USING ERRCODE = '55000';
  END IF;

  IF TG_OP = 'INSERT'
     AND NEW.fulfillment_method = 'partner_pickup'
     AND EXISTS (SELECT 1 FROM users WHERE id = NEW.buyer_id AND role::text = 'reseller')
  THEN
    IF NEW.pickup_scheduled_at IS NULL OR NEW.pickup_schedule_timezone <> 'Asia/Manila' THEN
      RAISE EXCEPTION 'RESELLER_PICKUP_SCHEDULE_REQUIRED' USING ERRCODE = '23514';
    END IF;
    IF NEW.pickup_scheduled_at < CURRENT_TIMESTAMP + INTERVAL '15 minutes'
       OR NEW.pickup_scheduled_at > CURRENT_TIMESTAMP + INTERVAL '30 days' THEN
      RAISE EXCEPTION 'RESELLER_PICKUP_SCHEDULE_OUT_OF_RANGE' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: expire_deferred_product_binary_credits(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_deferred_product_binary_credits() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE expired integer;
BEGIN
  WITH expired_accounts AS (
    SELECT u.id, u.status
    FROM public.users u LEFT JOIN public.product_binary_account_holds h ON h.user_id = u.id
    WHERE (u.status = 'suspended' OR (
      u.status = 'inactive' AND clock_timestamp() >= h.inactive_since + interval '72 hours'
    )) AND EXISTS (
      SELECT 1 FROM public.product_binary_pool_allocations pending
      WHERE pending.recipient_user_id = u.id AND pending.amount_centavos > 0
        AND pending.commission_id IS NULL AND pending.retained_at IS NULL
    )
    FOR SHARE OF u
  )
  UPDATE public.product_binary_pool_allocations a
  SET retained_at = clock_timestamp(), retained_reason = CASE WHEN u.status = 'suspended'
    THEN 'Account permanently suspended.' ELSE '72-hour deactivation window expired.' END
  FROM expired_accounts u
  WHERE a.recipient_user_id = u.id AND a.amount_centavos > 0
    AND a.commission_id IS NULL AND a.retained_at IS NULL;
  GET DIAGNOSTICS expired = ROW_COUNT;
  RETURN expired;
END;
$$;


--
-- Name: expire_product_binary_pu(text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_product_binary_pu(target_user text, as_of timestamp with time zone DEFAULT CURRENT_TIMESTAMP) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE lost INTEGER; lost_left INTEGER; lost_right INTEGER;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('product-binary-user:' || target_user));
  PERFORM 1 FROM product_binary_positions WHERE user_id=target_user FOR UPDATE;
  WITH expired AS (
    UPDATE product_binary_pu_lots SET expired_pu=expired_pu+remaining_pu,
      remaining_pu=0,expired_at=as_of
    WHERE recipient_user_id=target_user AND remaining_pu>0 AND expires_at<=as_of
    RETURNING leg,expired_pu
  ) SELECT COALESCE(SUM(expired_pu),0),COALESCE(SUM(expired_pu) FILTER(WHERE leg='left'),0),
    COALESCE(SUM(expired_pu) FILTER(WHERE leg='right'),0) INTO lost,lost_left,lost_right FROM expired;
  UPDATE product_binary_positions SET left_carryover_pu=left_carryover_pu-lost_left,
    right_carryover_pu=right_carryover_pu-lost_right,updated_at=CURRENT_TIMESTAMP
    WHERE user_id=target_user AND lost>0;
  RETURN lost;
END $$;


--
-- Name: fulfill_product_reward_claim(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fulfill_product_reward_claim() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE credit RECORD; remaining INTEGER:=NEW.quantity; closing INTEGER; receiving_before INTEGER; receiving_after INTEGER;
BEGIN
  FOR credit IN
    SELECT r.id,unit.number FROM package_binary_product_rewards r
    CROSS JOIN LATERAL generate_series(1,r.quantity) unit(number)
    WHERE r.user_id=NEW.reseller_id AND r.product_id=NEW.product_id
      AND NOT EXISTS(SELECT 1 FROM product_reward_claim_allocations a WHERE a.reward_id=r.id AND a.unit_number=unit.number)
    ORDER BY r.created_at,r.id,unit.number LIMIT NEW.quantity
  LOOP
    INSERT INTO product_reward_claim_allocations(claim_id,reward_id,unit_number) VALUES(NEW.id,credit.id,credit.number);
    remaining:=remaining-1;
  END LOOP;
  IF remaining<>0 THEN RAISE EXCEPTION 'Not enough unclaimed reward bottles.' USING ERRCODE='23514'; END IF;
  UPDATE inventory SET quantity=quantity-NEW.quantity,updated_at=clock_timestamp()
    WHERE owner_id=NEW.owner_id AND product_id=NEW.product_id AND quantity-reserved_quantity>=NEW.quantity
    RETURNING quantity INTO closing;
  IF NOT FOUND THEN RAISE EXCEPTION 'Not enough available outlet stock.' USING ERRCODE='23514'; END IF;
  IF closing IS DISTINCT FROM NEW.stock_after THEN RAISE EXCEPTION 'Claim stock snapshot mismatch.' USING ERRCODE='23514'; END IF;
  UPDATE product_reward_claim_proofs SET used_at=NEW.released_at WHERE id=NEW.proof_id;
  INSERT INTO inventory(id,owner_id,product_id,quantity,reserved_quantity,low_stock_threshold,updated_at)
    VALUES(gen_random_uuid(),NEW.reseller_id,NEW.product_id,NEW.quantity,0,10,clock_timestamp())
    ON CONFLICT(owner_id,product_id) DO UPDATE SET quantity=inventory.quantity+NEW.quantity,updated_at=clock_timestamp()
    RETURNING quantity INTO receiving_after;
  receiving_before:=receiving_after-NEW.quantity;
  INSERT INTO inventory_audit_events(id,owner_id,product_id,actor_id,actor_name_snapshot,event_type,
    quantity_delta,quantity_before,quantity_after,unit_cost_snapshot,total_value,reference_type,reference_id,reason,metadata,created_at)
  VALUES
    (gen_random_uuid(),NEW.owner_id,NEW.product_id,NEW.actor_id,NEW.actor_name_snapshot,'product_reward_claim_out',
      -NEW.quantity,closing+NEW.quantity,closing,NEW.unit_cost_snapshot,NEW.quantity*NEW.unit_cost_snapshot,
      'product_reward_claim',NEW.id::text,'Released earned Product Rewards bottle(s)',
      jsonb_build_object('reseller_id',NEW.reseller_id,'shift_id',NEW.shift_id,'terminal_id',NEW.terminal_id),NEW.released_at),
    (gen_random_uuid(),NEW.reseller_id,NEW.product_id,NEW.actor_id,NEW.actor_name_snapshot,'product_reward_claim_in',
      NEW.quantity,receiving_before,receiving_after,0,0,'product_reward_claim',NEW.id::text,
      'Received earned Product Rewards bottle(s)',jsonb_build_object('outlet_id',NEW.owner_id),NEW.released_at);
  RETURN NEW;
END $$;


--
-- Name: fulfill_reward_stock_dispatch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fulfill_reward_stock_dispatch() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE unit RECORD; remaining INTEGER:=NEW.quantity;
BEGIN
  FOR unit IN SELECT * FROM reward_stock_units WHERE holder_id=NEW.recipient_id AND product_id=NEW.product_id
      AND kind=NEW.kind AND current_dispatch_id IS NULL AND settled_at IS NULL AND (
        (EXISTS(SELECT 1 FROM order_replacement_requests r WHERE r.id=NEW.id)
         AND EXISTS(SELECT 1 FROM order_replacement_units a WHERE a.request_id=NEW.id AND a.unit_id=reward_stock_units.id))
        OR (NOT EXISTS(SELECT 1 FROM order_replacement_requests r WHERE r.id=NEW.id)
         AND NOT EXISTS(SELECT 1 FROM order_replacement_units a JOIN order_replacement_requests r ON r.id=a.request_id
           WHERE a.unit_id=reward_stock_units.id AND r.state='pending'))
      ) ORDER BY created_at,id LIMIT NEW.quantity FOR UPDATE
  LOOP
    INSERT INTO reward_stock_dispatch_items(dispatch_id,unit_id,cycle) VALUES(NEW.id,unit.id,unit.cycle);
    UPDATE reward_stock_units SET current_dispatch_id=NEW.id WHERE id=unit.id;
    remaining:=remaining-1;
  END LOOP;
  IF remaining<>0 THEN RAISE EXCEPTION 'Not enough pending replacement bottles.' USING ERRCODE='23514'; END IF;
  UPDATE inventory SET quantity=quantity-NEW.quantity,updated_at=clock_timestamp()
    WHERE owner_id=NEW.supplier_id AND product_id=NEW.product_id AND quantity-reserved_quantity>=NEW.quantity;
  IF NOT FOUND THEN RAISE EXCEPTION 'Not enough available supplier stock.' USING ERRCODE='23514'; END IF;
  INSERT INTO inventory_audit_events(id,owner_id,product_id,actor_id,actor_name_snapshot,event_type,quantity_delta,quantity_before,quantity_after,
    unit_cost_snapshot,total_value,reference_type,reference_id,reason,metadata,created_at)
  VALUES(gen_random_uuid(),NEW.supplier_id,NEW.product_id,NEW.actor_id,NEW.actor_name,'reward_replacement_dispatch',-NEW.quantity,NEW.stock_before,NEW.stock_after,
    NEW.unit_cost_snapshot,NEW.quantity*NEW.unit_cost_snapshot,'reward_stock_dispatch',NEW.id::text,'Reward replacement stock dispatched; awaiting receipt',
    jsonb_build_object('recipient_id',NEW.recipient_id,'kind',NEW.kind),NEW.dispatched_at);
  RETURN NEW;
END $$;


--
-- Name: fund_product_binary_commission(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fund_product_binary_commission() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW."type" = 'sponsor_point'
    AND NEW."is_pair_overflow" = false
    AND NEW."amount" > 0
  THEN
    PERFORM public.consume_product_binary_funding(
      NEW."id",
      NEW."amount",
      NEW."created_at"
    );
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: generate_order_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_order_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.order_number := 'HRM-' || TO_CHAR(NOW(), 'YYYY') || '-' || UPPER(SUBSTRING(MD5(NEW.id::text), 1, 6));
  RETURN NEW;
END;
$$;


--
-- Name: initialize_package_binary_carryover(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.initialize_package_binary_carryover() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE version_id UUID;
BEGIN
 PERFORM pg_advisory_xact_lock(hashtext('package-binary-product-reward-policy'));
 INSERT INTO package_binary_carryover_policies(package_id,effective_day,enabled,max_points)
 VALUES(NEW.id,(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date,true,180000) RETURNING id INTO version_id;
 INSERT INTO audit_logs(id,user_name,user_role,activity_type,category,description,metadata,risk_level,status)
 VALUES(gen_random_uuid()::text,'Database trigger','system','package_binary_carryover_cap_initialized','commission','New package starts with 180000 unmatched points per leg.',
 jsonb_build_object('package_id',NEW.id,'carryover_policy_id',version_id::text,'enabled',true,'max_points',180000),'high','completed');
 RETURN NEW;
END $$;


--
-- Name: liquidate_deactivation_payable_lots(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.liquidate_deactivation_payable_lots() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  reseller_role TEXT;
  reseller_status TEXT;
  processor_role TEXT;
  processor_status TEXT;
  wallet_balance DECIMAL(12,2);
  wallet_reserved DECIMAL(12,2);
  payable_total DECIMAL(12,2) := 0;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('financial-user:' || NEW."reseller_id"));

  SELECT u."role"::text, u."status"::text
  INTO reseller_role, reseller_status
  FROM "users" u
  WHERE u."id" = NEW."reseller_id"
  FOR SHARE;

  SELECT u."role"::text, u."status"::text
  INTO processor_role, processor_status
  FROM "users" u
  WHERE u."id" = NEW."processed_by"
  FOR SHARE;

  IF reseller_role <> 'reseller' OR reseller_status <> 'inactive'
     OR processor_role <> 'admin' OR processor_status <> 'active' THEN
    RAISE EXCEPTION 'A sealed deactivation requires an inactive reseller and an active Admin processor.' USING ERRCODE = '23514';
  END IF;

  SELECT w."balance", w."reserved_balance"
  INTO wallet_balance, wallet_reserved
  FROM "wallets" w
  WHERE w."user_id" = NEW."reseller_id"
  FOR UPDATE;

  IF wallet_balance IS NULL OR wallet_reserved <> 0
     OR wallet_balance <> NEW."wallet_value" OR NEW."points_value" <> 0
     OR NEW."total_flushed" <> NEW."wallet_value" + NEW."points_value" THEN
    RAISE EXCEPTION 'Deactivation values do not match the unlocked member wallet and zero-value carryover policy.' USING ERRCODE = '23514';
  END IF;

  IF EXISTS (
    SELECT 1 FROM "payouts" p
    WHERE p."user_id" = NEW."reseller_id"
      AND p."status" IN ('pending'::"PayoutStatus", 'approved'::"PayoutStatus")
  ) THEN
    RAISE EXCEPTION 'Resolve pending or approved payouts before deactivation.' USING ERRCODE = '23514';
  END IF;

  PERFORM l."id" FROM "direct_referral_reserve_lots" l
    WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0 FOR UPDATE;
  PERFORM l."id" FROM "binary_payable_lots" l
    WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0 FOR UPDATE;
  PERFORM l."id" FROM "product_binary_payable_lots" l
    WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0 FOR UPDATE;

  SELECT
    COALESCE((SELECT SUM("remaining_amount") FROM "direct_referral_reserve_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "binary_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "product_binary_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "rank_bonus_awards" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "unilevel_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
  INTO payable_total;

  IF payable_total <> NEW."wallet_value" THEN
    RAISE EXCEPTION 'Wallet and payable liabilities do not reconcile; deactivation is blocked.' USING ERRCODE = '23514';
  END IF;

  INSERT INTO "payable_lot_forfeitures" (
    "deactivation_event_id", "source_type", "direct_lot_id", "amount", "created_at"
  )
  SELECT NEW."id", 'direct_referral', l."id", l."remaining_amount", NEW."created_at"
  FROM "direct_referral_reserve_lots" l
  WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0;

  INSERT INTO "payable_lot_forfeitures" (
    "deactivation_event_id", "source_type", "binary_lot_id", "amount", "created_at"
  )
  SELECT NEW."id", 'binary', l."id", l."remaining_amount", NEW."created_at"
  FROM "binary_payable_lots" l
  WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0;

  INSERT INTO "payable_lot_forfeitures" (
    "deactivation_event_id", "source_type", "product_binary_lot_id", "amount", "created_at"
  )
  SELECT NEW."id", 'product_binary', l."id", l."remaining_amount", NEW."created_at"
  FROM "product_binary_payable_lots" l
  WHERE l."user_id" = NEW."reseller_id" AND l."remaining_amount" > 0;

  INSERT INTO "payable_lot_forfeitures" (
    "deactivation_event_id", "source_type", "rank_bonus_lot_id", "amount", "created_at"
  )
  SELECT NEW."id", 'rank_bonus', award.id, award.remaining_amount, NEW."created_at"
  FROM public.rank_bonus_awards award
  WHERE award.user_id = NEW."reseller_id" AND award.remaining_amount > 0;

  UPDATE public.rank_bonus_awards SET remaining_amount = 0
  WHERE user_id = NEW."reseller_id" AND remaining_amount > 0;

  UPDATE "direct_referral_reserve_lots"
  SET "remaining_amount" = 0
  WHERE "user_id" = NEW."reseller_id" AND "remaining_amount" > 0;

  UPDATE "binary_payable_lots"
  SET "remaining_amount" = 0
  WHERE "user_id" = NEW."reseller_id" AND "remaining_amount" > 0;

  UPDATE "product_binary_payable_lots"
  SET "remaining_amount" = 0
  WHERE "user_id" = NEW."reseller_id" AND "remaining_amount" > 0;

  INSERT INTO public.payable_lot_forfeitures(deactivation_event_id,source_type,unilevel_lot_id,amount,created_at)
  SELECT NEW.id,'unilevel',lot.id,lot.remaining_amount,NEW.created_at FROM public.unilevel_payable_lots lot
  WHERE lot.user_id=NEW.reseller_id AND lot.remaining_amount>0;
  UPDATE public.unilevel_payable_lots SET remaining_amount=0 WHERE user_id=NEW.reseller_id AND remaining_amount>0;
  RETURN NEW;
END;
$$;


--
-- Name: lock_pos_registration_intake_identity_write(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.lock_pos_registration_intake_identity_write() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.identity_document_hash IS NOT NULL THEN
    PERFORM pg_advisory_xact_lock(
      hashtextextended(
        'hiroma:pos-registration:' || lower(NEW.identity_document_hash),
        0
      )
    );
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: maintain_binary_tree_ancestor_counts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.maintain_binary_tree_ancestor_counts() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  ancestor_row RECORD;
  previous_maintenance_setting text;
  parent_was_updated boolean := false;
BEGIN
  IF NEW."parent_id" IS NULL THEN
    RETURN NEW;
  END IF;

  previous_maintenance_setting := current_setting(
    'hiroma.binary_tree_count_maintenance',
    true
  );
  PERFORM set_config('hiroma.binary_tree_count_maintenance', 'on', true);

  BEGIN
    FOR ancestor_row IN
      WITH RECURSIVE ancestor_chain AS (
        SELECT parent."id",
               parent."parent_id",
               parent."position",
               NEW."position"::text AS source_leg,
               0 AS depth
          FROM "binary_tree_nodes" parent
         WHERE parent."id" = NEW."parent_id"
        UNION ALL
        SELECT parent."id",
               parent."parent_id",
               parent."position",
               child."position"::text AS source_leg,
               child.depth + 1
          FROM ancestor_chain child
          JOIN "binary_tree_nodes" parent
            ON parent."id" = child."parent_id"
      )
      SELECT "id", source_leg
        FROM ancestor_chain
       ORDER BY depth DESC
    LOOP
      parent_was_updated := true;
      IF ancestor_row.source_leg = 'left' THEN
        UPDATE "binary_tree_nodes"
           SET "left_count" = "left_count" + 1
         WHERE "id" = ancestor_row."id";
      ELSIF ancestor_row.source_leg = 'right' THEN
        UPDATE "binary_tree_nodes"
           SET "right_count" = "right_count" + 1
         WHERE "id" = ancestor_row."id";
      ELSE
        RAISE EXCEPTION 'Binary-tree ancestor leg is missing during descendant-count maintenance.'
          USING ERRCODE = '23514';
      END IF;
    END LOOP;

    IF NOT parent_was_updated THEN
      RAISE EXCEPTION 'Binary-tree parent is unavailable during descendant-count maintenance.'
        USING ERRCODE = '23503';
    END IF;
  EXCEPTION WHEN OTHERS THEN
    PERFORM set_config(
      'hiroma.binary_tree_count_maintenance',
      COALESCE(NULLIF(previous_maintenance_setting, ''), 'off'),
      true
    );
    RAISE;
  END;

  PERFORM set_config(
    'hiroma.binary_tree_count_maintenance',
    COALESCE(NULLIF(previous_maintenance_setting, ''), 'off'),
    true
  );
  RETURN NEW;
END;
$$;


--
-- Name: notification_order_route(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notification_order_route(target_user_id text) RETURNS text
    LANGUAGE sql STABLE
    AS $$
  SELECT CASE role::text
    WHEN 'admin' THEN '/dashboard/admin/orders'
    WHEN 'regional' THEN '/dashboard/regional/orders'
    WHEN 'provincial' THEN '/dashboard/provincial/orders'
    WHEN 'city' THEN '/dashboard/city/orders'
    WHEN 'reseller' THEN '/dashboard/reseller/orders'
    ELSE NULL
  END
  FROM users
  WHERE id::text = target_user_id
  LIMIT 1;
$$;


--
-- Name: notification_payment_method_route(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notification_payment_method_route(target_user_id text) RETURNS text
    LANGUAGE sql STABLE
    AS $$
  SELECT CASE role::text
    WHEN 'admin' THEN '/dashboard/admin/payment-methods'
    WHEN 'regional' THEN '/dashboard/regional/payment-methods'
    WHEN 'provincial' THEN '/dashboard/provincial/payment-methods'
    WHEN 'city' THEN '/dashboard/city/payment-methods'
    WHEN 'reseller' THEN '/dashboard/reseller/payment-methods'
    ELSE NULL
  END
  FROM users
  WHERE id::text = target_user_id
  LIMIT 1;
$$;


--
-- Name: notify_all_account_commission(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_all_account_commission() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
  action_url TEXT;
BEGIN
  notification_title := CASE NEW.type::text
    WHEN 'direct_referral' THEN 'Direct referral earned'
    WHEN 'binary_pairing' THEN 'Binary pairing earned'
    WHEN 'sponsor_point' THEN 'Product binary earned'
    ELSE 'Commission earned'
  END;
  notification_message := notification_title || ': ₱' ||
    TO_CHAR(NEW.amount, 'FM999,999,990.00') ||
    CASE WHEN COALESCE(NEW.points, 0) > 0
      THEN ' (' || NEW.points || ' points)' ELSE '' END;

  SELECT CASE role::text
    WHEN 'admin' THEN '/dashboard/admin/commissions'
    WHEN 'regional' THEN '/dashboard/regional'
    WHEN 'provincial' THEN '/dashboard/provincial'
    WHEN 'city' THEN '/dashboard/city/reports'
    WHEN 'reseller' THEN '/dashboard/reseller/wallet'
    ELSE NULL
  END INTO action_url
  FROM users WHERE id::text = NEW.user_id::text;

  INSERT INTO notifications (
    user_id, type, title, message, amount, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, NEW.type::text, notification_title, notification_message,
    NEW.amount, 'commission', NEW.id, action_url
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_all_account_payment_method(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_all_account_payment_method() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
BEGIN
  IF NEW.status IS NOT DISTINCT FROM OLD.status THEN
    RETURN NEW;
  END IF;

  notification_title := CASE NEW.status
    WHEN 'approved' THEN 'Payout account approved'
    WHEN 'rejected' THEN 'Payout account rejected'
    ELSE 'Payout account updated'
  END;
  INSERT INTO notifications (
    user_id, type, title, message, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, 'payment_method_' || NEW.status, notification_title,
    'Your ' || REPLACE(NEW.type, '_', ' ') || ' payout account is now ' || NEW.status || '.',
    'payment_method', NEW.id, notification_payment_method_route(NEW.user_id::text)
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_all_account_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_all_account_payout() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
  action_url TEXT;
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status IS NOT DISTINCT FROM OLD.status THEN
    RETURN NEW;
  END IF;

  notification_title := CASE NEW.status::text
    WHEN 'approved' THEN 'Payout approved'
    WHEN 'rejected' THEN 'Payout rejected'
    WHEN 'released' THEN 'Payout released'
    ELSE 'Payout updated'
  END;
  notification_message := 'Your payout of ₱' ||
    TO_CHAR(NEW.amount, 'FM999,999,990.00') || ' is now ' || NEW.status::text || '.';

  SELECT CASE role::text
    WHEN 'admin' THEN '/dashboard/admin/payouts'
    WHEN 'reseller' THEN '/dashboard/reseller/payouts'
    ELSE NULL
  END INTO action_url
  FROM users WHERE id::text = NEW.user_id::text;

  INSERT INTO notifications (
    user_id, type, title, message, amount, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, 'payout_' || NEW.status::text, notification_title,
    notification_message, NEW.amount, 'payout', NEW.id, action_url
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_all_order_parties(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_all_order_parties() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.seller_id <> NEW.buyer_id THEN
      INSERT INTO notifications (user_id, type, title, message, amount, entity_type, entity_id, action_url)
      VALUES (
        NEW.seller_id, 'order_placed', 'New order received',
        'A new order' || COALESCE(' ' || NEW.order_number, '') ||
        ' worth ₱' || TO_CHAR(NEW.total_amount, 'FM999,999,990.00') ||
        CASE WHEN NEW.pickup_scheduled_at IS NOT NULL
          THEN ' is scheduled for pickup on ' || TO_CHAR(NEW.pickup_scheduled_at AT TIME ZONE 'Asia/Manila', 'Mon DD, YYYY FMHH12:MI AM') || '.'
          ELSE ' was placed.' END,
        NEW.total_amount, 'order', NEW.id, notification_order_route(NEW.seller_id::text)
      );
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.buyer_id = NEW.seller_id THEN RETURN NEW; END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    notification_title := CASE NEW.status::text
      WHEN 'processing' THEN 'Order is processing'
      WHEN 'ready_for_pickup' THEN 'Order ready for pickup'
      WHEN 'delivered' THEN 'Order delivered'
      WHEN 'cancelled' THEN 'Order cancelled'
      ELSE 'Order updated' END;
    notification_message := 'Your order' || COALESCE(' ' || NEW.order_number, '') || ' is now ' || REPLACE(NEW.status::text, '_', ' ') || '.';
    INSERT INTO notifications (user_id, type, title, message, amount, entity_type, entity_id, action_url)
    VALUES (NEW.buyer_id, 'order_' || NEW.status::text, notification_title, notification_message, NEW.total_amount, 'order', NEW.id, notification_order_route(NEW.buyer_id::text));
  ELSIF NEW.payment_status IS DISTINCT FROM OLD.payment_status THEN
    notification_title := CASE WHEN NEW.payment_status = 'paid' THEN 'Order payment confirmed' ELSE 'Order payment updated' END;
    notification_message := 'Payment for your order' || COALESCE(' ' || NEW.order_number, '') || ' is now ' || REPLACE(NEW.payment_status, '_', ' ') || '.';
    INSERT INTO notifications (user_id, type, title, message, amount, entity_type, entity_id, action_url)
    VALUES (NEW.buyer_id, 'order_payment_' || NEW.payment_status, notification_title, notification_message, NEW.total_amount, 'order', NEW.id, notification_order_route(NEW.buyer_id::text));
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: notify_reseller_commission(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_reseller_commission() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM users WHERE id = NEW.user_id AND role = 'reseller') THEN
    RETURN NEW;
  END IF;

  notification_title := CASE NEW.type::text
    WHEN 'direct_referral' THEN 'Direct referral earned'
    WHEN 'binary_pairing' THEN 'Binary pairing earned'
    WHEN 'sponsor_point' THEN 'Product binary earned'
    ELSE 'Commission earned'
  END;
  notification_message := notification_title || ': ₱' ||
    TO_CHAR(NEW.amount, 'FM999,999,990.00') ||
    CASE WHEN COALESCE(NEW.points, 0) > 0
      THEN ' (' || NEW.points || ' points)' ELSE '' END;

  INSERT INTO notifications (
    user_id, type, title, message, amount, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, NEW.type::text, notification_title, notification_message,
    NEW.amount, 'commission', NEW.id, '/dashboard/reseller/wallet'
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_reseller_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_reseller_order() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  IF TG_OP = 'INSERT' AND NEW.seller_id <> NEW.buyer_id THEN
    INSERT INTO notifications (
      user_id, type, title, message, amount, entity_type, entity_id, action_url
    ) VALUES (
      NEW.seller_id, 'new_order', 'New order received',
      'A new order' || COALESCE(' ' || NEW.order_number, '') ||
      ' worth ₱' || TO_CHAR(NEW.total_amount, 'FM999,999,990.00') ||
      ' was received.',
      NEW.total_amount, 'order', NEW.id,
      CASE (SELECT role::text FROM users WHERE id = NEW.seller_id)
        WHEN 'admin' THEN '/dashboard/admin/orders'
        WHEN 'regional' THEN '/dashboard/regional/orders'
        WHEN 'provincial' THEN '/dashboard/provincial/orders'
        WHEN 'city' THEN '/dashboard/city/orders'
        ELSE '/dashboard/reseller/orders'
      END
    );
  END IF;

  -- Creating the order is the reseller's own action. The seller is notified
  -- above, while the reseller is notified only on later status changes.
  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM users WHERE id = NEW.buyer_id AND role = 'reseller') THEN
    RETURN NEW;
  END IF;

  IF NEW.status IS NOT DISTINCT FROM OLD.status THEN
    RETURN NEW;
  ELSE
    notification_title := CASE NEW.status::text
      WHEN 'processing' THEN 'Order is processing'
      WHEN 'delivered' THEN 'Order delivered'
      WHEN 'cancelled' THEN 'Order cancelled'
      ELSE 'Order updated'
    END;
    notification_message := 'Your order' ||
      COALESCE(' ' || NEW.order_number, '') || ' is now ' ||
      NEW.status::text || '.';
  END IF;

  INSERT INTO notifications (
    user_id, type, title, message, amount, entity_type, entity_id, action_url
  ) VALUES (
    NEW.buyer_id, 'order_' || NEW.status::text, notification_title,
    notification_message, NEW.total_amount, 'order', NEW.id,
    '/dashboard/reseller/orders'
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_reseller_payment_method(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_reseller_payment_method() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
BEGIN
  IF NEW.status IS NOT DISTINCT FROM OLD.status OR
     NOT EXISTS (SELECT 1 FROM users WHERE id = NEW.user_id AND role = 'reseller') THEN
    RETURN NEW;
  END IF;

  notification_title := CASE NEW.status
    WHEN 'approved' THEN 'Payout account approved'
    WHEN 'rejected' THEN 'Payout account rejected'
    ELSE 'Payout account updated'
  END;
  INSERT INTO notifications (
    user_id, type, title, message, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, 'payment_method_' || NEW.status, notification_title,
    'Your ' || REPLACE(NEW.type, '_', ' ') || ' payout account is now ' ||
    NEW.status || '.', 'payment_method', NEW.id,
    '/dashboard/reseller/payment-methods'
  );
  RETURN NEW;
END;
$$;


--
-- Name: notify_reseller_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_reseller_payout() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM users WHERE id = NEW.user_id AND role = 'reseller') THEN
    RETURN NEW;
  END IF;

  -- The reseller already receives an immediate success response after submitting
  -- a payout request. Notify only when Admin changes its status.
  IF TG_OP = 'INSERT' OR NEW.status IS NOT DISTINCT FROM OLD.status THEN
    RETURN NEW;
  ELSE
    notification_title := CASE NEW.status::text
      WHEN 'approved' THEN 'Payout approved'
      WHEN 'rejected' THEN 'Payout rejected'
      WHEN 'released' THEN 'Payout released'
      ELSE 'Payout updated'
    END;
    notification_message := 'Your payout of ₱' ||
      TO_CHAR(NEW.amount, 'FM999,999,990.00') || ' is now ' ||
      NEW.status::text || '.';
  END IF;

  INSERT INTO notifications (
    user_id, type, title, message, amount, entity_type, entity_id, action_url
  ) VALUES (
    NEW.user_id, 'payout_' || NEW.status::text, notification_title,
    notification_message, NEW.amount, 'payout', NEW.id,
    '/dashboard/reseller/payouts'
  );
  RETURN NEW;
END;
$$;


--
-- Name: package_binary_cap_state(text, text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.package_binary_cap_state(package_key text, member_key text, at_time timestamp with time zone) RETURNS TABLE(enabled boolean, cap integer, mode text, policy_id text, cutoff text, session integer, session_cap integer, used_today bigint, used_session bigint)
    LANGUAGE plpgsql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE chosen RECORD; pairing_date DATE; minute_now INTEGER; first_cap INTEGER; cutoff_at INTEGER; total_recorded BIGINT; session_recorded BIGINT;
BEGIN
 package_key:=COALESCE(package_binary_shared_policy_package(),package_key);
 pairing_date:=(at_time AT TIME ZONE 'Asia/Manila')::date;
 SELECT p.* INTO chosen FROM package_binary_cap_policies p WHERE p.package_id=package_key AND p.effective_day<=pairing_date ORDER BY p.effective_day DESC,p.revision DESC LIMIT 1;
 IF FOUND THEN
  enabled:=chosen.enabled;cap:=chosen.daily_limit;mode:=chosen.mode;policy_id:=chosen.id::text;first_cap:=chosen.first_limit;cutoff_at:=chosen.cutoff_minute;
 ELSE
  SELECT COALESCE(p.binary_pair_cap_enabled,true),GREATEST(1,COALESCE(p.daily_binary_pair_cap,10)) INTO enabled,cap FROM packages p WHERE p.id=package_key;
  mode:='two_sessions';first_cap:=GREATEST(1,cap/2);cutoff_at:=780;policy_id:=NULL;
 END IF;
 IF cap IS NULL THEN RAISE EXCEPTION 'Package Binary cap package is missing.'; END IF;
 SELECT COALESCE((SELECT d.used_pairs FROM binary_daily_cap_usage d WHERE d.user_id=member_key AND d.pairing_day=pairing_date),0) INTO used_today;
 IF mode='daily_anytime' THEN session:=0;session_cap:=cap;used_session:=used_today;cutoff:=NULL;
 ELSE
  minute_now:=extract(hour FROM at_time AT TIME ZONE 'Asia/Manila')::int*60+extract(minute FROM at_time AT TIME ZONE 'Asia/Manila')::int;
  session:=CASE WHEN minute_now<cutoff_at THEN 1 ELSE 2 END;
  session_cap:=CASE WHEN session=1 THEN first_cap ELSE GREATEST(1,cap-first_cap) END;
  cutoff:=lpad((cutoff_at/60)::text,2,'0')||':'||lpad((cutoff_at%60)::text,2,'0');
  SELECT COALESCE(SUM(e.payable_pairs+e.inactive_flashout_pairs),0),
   COALESCE(SUM(e.payable_pairs+e.inactive_flashout_pairs) FILTER(WHERE COALESCE(e.cap_session,
    CASE WHEN extract(hour FROM e.created_at AT TIME ZONE 'Asia/Manila')*60+extract(minute FROM e.created_at AT TIME ZONE 'Asia/Manila')<cutoff_at THEN 1 ELSE 2 END)=session),0)
  INTO total_recorded,session_recorded FROM binary_pair_events e WHERE e.recipient_user_id=member_key AND e.pairing_day=pairing_date;
  used_session:=session_recorded+GREATEST(0,used_today-total_recorded);
 END IF;
 RETURN NEXT;
END $$;


--
-- Name: package_binary_cap_state_v2(text, text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.package_binary_cap_state_v2(package_key text, member_key text, at_time timestamp with time zone) RETURNS TABLE(enabled boolean, cap integer, mode text, policy_id text, cutoff text, session integer, session_cap integer, used_today bigint, used_session bigint, carryover_enabled boolean, carryover_limit integer, carryover_policy_id text)
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
 SELECT s.*,true,COALESCE(c.max_points,180000),c.id::text
 FROM package_binary_cap_state(package_key,member_key,at_time) s
 LEFT JOIN LATERAL (
   SELECT p.id,p.max_points FROM package_binary_carryover_policies p
   WHERE p.package_id=package_binary_shared_policy_package()
     AND p.cap_policy_id::text=s.policy_id
   LIMIT 1
 ) c ON true
$$;


--
-- Name: package_binary_shared_policy_package(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.package_binary_shared_policy_package() RETURNS text
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
 SELECT id FROM packages WHERE lower(btrim(name))='starter' ORDER BY created_at,id LIMIT 1
$$;


--
-- Name: person_account_key(text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.person_account_key(legal_name text, born date) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
 SELECT encode(sha256(convert_to(
   regexp_replace(lower(normalize(regexp_replace(trim(legal_name), '\s+(jr\.?|sr\.?|ii|iii|iv|v)$', '', 'i'), NFKC)), '[[:space:]''’.-]+', '', 'g')
   || '|' || to_char(born,'YYYY-MM-DD'), 'UTF8')), 'hex')
$_$;


--
-- Name: pin_has_exact_paid_source(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pin_has_exact_paid_source(target_pin_id text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
  source_order RECORD;
  source_request RECORD;
  source_transfer RECORD;
  linked_count INTEGER;
  linked_total DECIMAL(12,2);
BEGIN
  SELECT * INTO issued FROM "pins" WHERE "id" = target_pin_id FOR SHARE;
  IF NOT FOUND OR num_nonnulls(
       issued."funding_order_id",
       issued."funding_pin_request_id",
       issued."funding_pin_transfer_id"
     ) <> 1 THEN
    RETURN false;
  END IF;

  IF issued."funding_order_id" IS NOT NULL THEN
    SELECT * INTO source_order FROM "orders" WHERE "id" = issued."funding_order_id" FOR UPDATE;
    SELECT COUNT(*)::INTEGER, COALESCE(SUM("pin_allocation_snapshot"), 0)::DECIMAL(12,2)
    INTO linked_count, linked_total
    FROM "pins" WHERE "funding_order_id" = issued."funding_order_id";
    RETURN COALESCE(source_order."id" IS NOT NULL
      AND source_order."buyer_id" = issued."city_dist_id"
      AND source_order."seller_id" = issued."generated_by"
      AND source_order."financial_purpose" = 'pin_sale'
      AND source_order."status" = 'delivered'::"OrderStatus"
      AND source_order."payment_status" = 'paid'
      AND source_order."paid_at" IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM "order_items" WHERE "order_id" = source_order."id")
      AND NOT EXISTS (SELECT 1 FROM "pos_transactions" WHERE "order_id" = source_order."id")
      AND linked_count > 0
      AND linked_total = source_order."total_amount", false);
  END IF;

  IF issued."funding_pin_request_id" IS NOT NULL THEN
    SELECT * INTO source_request FROM "pin_requests"
    WHERE "id" = issued."funding_pin_request_id" FOR UPDATE;
    SELECT COUNT(*)::INTEGER, COALESCE(SUM("pin_allocation_snapshot"), 0)::DECIMAL(12,2)
    INTO linked_count, linked_total
    FROM "pins" WHERE "funding_pin_request_id" = issued."funding_pin_request_id";
    RETURN COALESCE(source_request."id" IS NOT NULL
      AND source_request."city_dist_id" = issued."city_dist_id"
      AND source_request."package_id" = issued."package_id"
      AND source_request."status" = 'approved'
      AND source_request."payment_status" = 'paid'
      AND linked_count = source_request."quantity"
      AND linked_total = source_request."total_amount"
      AND "registration_snapshot_matches_pin"(source_request."registration_snapshot", issued."id"), false);
  END IF;

  SELECT * INTO source_transfer FROM "pin_transfers"
  WHERE "id" = issued."funding_pin_transfer_id" FOR UPDATE;
  SELECT COUNT(*)::INTEGER, COALESCE(SUM("pin_allocation_snapshot"), 0)::DECIMAL(12,2)
  INTO linked_count, linked_total
  FROM "pins" WHERE "funding_pin_transfer_id" = issued."funding_pin_transfer_id";
  RETURN COALESCE(source_transfer."id" IS NOT NULL
    AND source_transfer."admin_id" = issued."generated_by"
    AND source_transfer."recipient_id" = issued."city_dist_id"
    AND source_transfer."package_id" = issued."package_id"
    AND source_transfer."pin_type" = issued."pin_type"
    AND source_transfer."upgrade_from_package_id" IS NOT DISTINCT FROM issued."upgrade_from_package_id"
    AND source_transfer."sale_value" = 0
    AND linked_count = source_transfer."quantity"
    AND linked_total = source_transfer."reference_value"
    AND (
      (issued."status" = 'in_transit'::"PinStatus" AND source_transfer."status" = 'in_transit')
      OR
      (issued."status" IN ('unused'::"PinStatus", 'used'::"PinStatus") AND source_transfer."status" = 'received')
    ), false);
END;
$$;


--
-- Name: prevent_inventory_audit_event_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_inventory_audit_event_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'inventory_audit_events is append-only';
END;
$$;


--
-- Name: prevent_payout_recipient_role_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_payout_recipient_role_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."role" = 'reseller'::"Role"
     AND NEW."role" <> 'reseller'::"Role"
     AND EXISTS (
       SELECT 1
       FROM "payouts"
       WHERE "user_id" = OLD."id"
     ) THEN
    RAISE EXCEPTION USING
      ERRCODE = 'P0001',
      MESSAGE = 'A reseller with payout records cannot change to a non-reseller role.',
      DETAIL = format('user_id=%s requested_role=%s', OLD."id", NEW."role");
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: process_rank_bonus_awards(timestamp with time zone, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.process_rank_bonus_awards(target_quarter timestamp with time zone, batch_size integer DEFAULT 50) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  program rank_bonus_programs;
  available numeric;
  candidate record;
  award_id uuid;
  credit_id text;
  credited integer := 0;
BEGIN
  SELECT * INTO program FROM rank_bonus_programs
  WHERE quarter_start = target_quarter AND quarter_start <= transaction_timestamp()
  FOR UPDATE;
  IF NOT FOUND THEN RETURN 0; END IF;

  SELECT COALESCE((SELECT SUM(amount) FROM rank_bonus_funding WHERE quarter_start = target_quarter), 0)
       - COALESCE((SELECT SUM(original_amount) FROM rank_bonus_awards WHERE quarter_start = target_quarter), 0)
  INTO available;

  FOR candidate IN
    WITH buyers AS (
      SELECT DISTINCT job.buyer_user_id AS user_id
      FROM product_binary_settlement_jobs job
      WHERE job.qualification_status = 'qualified_paid_delivery'
        AND job.qualified_at >= program.quarter_start AND job.qualified_at < program.quarter_end
    )
    SELECT buyer.user_id, milestone.name, milestone.amount, progress.bottles, progress.referrals
    FROM buyers buyer
    JOIN users member ON member.id = buyer.user_id AND member.status = 'active' AND member.role = 'reseller'
    JOIN reseller_profiles profile ON profile.user_id = member.id AND profile.is_active
    CROSS JOIN LATERAL rank_bonus_progress(buyer.user_id, program.quarter_start, program.quarter_end) progress
    CROSS JOIN jsonb_to_recordset(program.milestones) AS milestone(name text, bottles int, referrals int, amount numeric(12,2))
    WHERE progress.bottles >= milestone.bottles AND progress.referrals >= milestone.referrals
      AND milestone.amount > 0 AND milestone.amount <= available
      AND NOT EXISTS (
        SELECT 1 FROM rank_bonus_awards award
        WHERE award.quarter_start = target_quarter AND award.user_id = buyer.user_id AND award.milestone = milestone.name
      )
    ORDER BY buyer.user_id, milestone.bottles, milestone.referrals, milestone.name
    LIMIT LEAST(GREATEST(batch_size, 1), 100)
  LOOP
    EXIT WHEN candidate.amount > available;
    PERFORM pg_advisory_xact_lock(hashtext('financial-user:' || candidate.user_id));
    PERFORM 1 FROM users WHERE id = candidate.user_id AND status = 'active' AND role = 'reseller' FOR SHARE;
    IF NOT FOUND THEN CONTINUE; END IF;

    award_id := gen_random_uuid();
    credit_id := gen_random_uuid()::text;
    INSERT INTO rank_bonus_awards (
      id, quarter_start, user_id, milestone, bottles, referrals, original_amount, remaining_amount, commission_id
    ) VALUES (
      award_id, target_quarter, candidate.user_id, candidate.name, candidate.bottles,
      candidate.referrals, candidate.amount, candidate.amount, credit_id
    );

    INSERT INTO commissions (id, event_key, source_event_kind, source_event_id, rule_version, user_id, type, amount)
    VALUES (credit_id, 'rank-bonus:' || award_id, 'rank_bonus', award_id::text, 'rank-bonus-v1',
      candidate.user_id, 'rank_bonus', candidate.amount);

    available := available - candidate.amount;
    credited := credited + 1;
  END LOOP;
  RETURN credited;
END;
$$;


--
-- Name: product_binary_inventory_earmark(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_binary_inventory_earmark(source_order text) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT COALESCE(SUM(r.remaining_units), 0)::numeric * 5
  FROM public.product_binary_inventory_reserves r
  JOIN public.order_items i ON i.id = r.source_order_item_id
  WHERE i.order_id = source_order
$$;


--
-- Name: product_binary_pair_amount(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_binary_pair_amount() RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
 SELECT COALESCE((SELECT value::numeric FROM system_settings WHERE key='product_binary_pair_amount'),5)
$$;


--
-- Name: product_binary_surviving_pairs(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_binary_surviving_pairs(target_week date, recipient text) RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT (
    SELECT COALESCE(SUM(e.payable_pairs), 0)
    FROM public.product_binary_pair_events e
    JOIN public.product_binary_pool_pairs p ON p.pair_event_id = e.id
    WHERE p.week_start = target_week AND e.recipient_user_id = recipient
      AND e.created_at >= h.forfeited_before
  )
  FROM public.product_binary_account_holds h
  WHERE h.user_id = recipient
    AND h.forfeited_before >= (target_week::timestamp AT TIME ZONE 'Asia/Manila')
$$;


--
-- Name: product_binary_week_funding_held(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_binary_week_funding_held(exclude_allocations_for date DEFAULT NULL::date) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT COALESCE((SELECT SUM(retained_centavos) FROM public.product_binary_week_funding), 0) / 100
    + COALESCE((
      SELECT SUM(held.amount_centavos)
      FROM (
        SELECT a.week_start, a.amount_centavos FROM public.product_binary_pool_allocations a
        WHERE exclude_allocations_for IS NULL AND a.commission_id IS NULL
        UNION ALL
        SELECT a.week_start, a.amount_centavos FROM public.product_binary_pool_allocations a
        WHERE a.week_start < exclude_allocations_for AND a.commission_id IS NULL
        UNION ALL
        SELECT a.week_start, a.amount_centavos FROM public.product_binary_pool_allocations a
        WHERE a.week_start > exclude_allocations_for AND a.commission_id IS NULL
        UNION ALL
        SELECT a.week_start, a.amount_centavos FROM public.product_binary_pool_allocations a
        WHERE a.week_start = exclude_allocations_for AND a.commission_id IS NULL AND a.retained_at IS NOT NULL
      ) held JOIN public.product_binary_pool_weeks w USING (week_start)
      WHERE w.closed_at IS NOT NULL
    ), 0) / 100
    + 5 * (SELECT COALESCE(SUM(remaining_units), 0)::numeric
      FROM public.product_binary_inventory_reserves WHERE source_movement_id IS NOT NULL)
    + 5 * ((SELECT COALESCE(SUM(units), 0)::numeric FROM public.product_binary_non_member_reserve_releases)
         - (SELECT COALESCE(SUM(units), 0)::numeric FROM public.product_binary_non_member_reserve_restorations)
         + (SELECT COALESCE(SUM(units), 0)::numeric FROM public.product_binary_replacement_reserve_releases)
         + (SELECT COALESCE(SUM(released_units), 0)::numeric FROM public.product_binary_package_reserve_releases))
$$;


--
-- Name: product_binary_weekly_pair_eligible(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_binary_weekly_pair_eligible(recipient text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT COALESCE((
    SELECT u.status = 'active' OR (
      u.status = 'inactive' AND transaction_timestamp() < h.inactive_since + interval '72 hours'
    )
    FROM public.users u LEFT JOIN public.product_binary_account_holds h ON h.user_id = u.id
    WHERE u.id = recipient AND u.role = 'reseller'
  ), false)
$$;


--
-- Name: protect_admin_stock_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_admin_stock_receipt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'Admin stock receipt evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF NEW."source_type" NOT IN ('production', 'supplier_purchase', 'approved_adjustment')
     OR LENGTH(TRIM(NEW."source_reference")) < 3
     OR NEW."source_reference_key" <> UPPER(REGEXP_REPLACE(TRIM(NEW."source_reference"), '\s+', ' ', 'g'))
     OR NEW."total_units" <= 0
     OR NEW."received_by_actor_id" IS NULL THEN
    RAISE EXCEPTION 'Admin stock receipt requires valid source, reference, actor, and quantity.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_admin_stock_receipt_item(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_admin_stock_receipt_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'Admin stock receipt item evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF NEW."quantity" <= 0 OR NEW."unit_cost" < 0
     OR NEW."stock_after" <> NEW."stock_before" + NEW."quantity" THEN
    RAISE EXCEPTION 'Admin stock receipt item has inconsistent stock evidence.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_binary_daily_cap_usage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_binary_daily_cap_usage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF pg_trigger_depth()>1 THEN
   IF TG_OP='INSERT' THEN RETURN NEW; END IF;
   IF TG_OP='UPDATE' AND NEW.user_id=OLD.user_id AND NEW.pairing_day=OLD.pairing_day
     AND NEW.used_pairs>=OLD.used_pairs THEN RETURN NEW; END IF;
 END IF;
 RAISE EXCEPTION 'Daily cap usage can change only through a recorded pair event.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_binary_point_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_binary_point_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Binary point consumption and expiration evidence is append-only.' USING ERRCODE='23514';
END;
$$;


--
-- Name: protect_binary_point_lot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_binary_point_lot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Binary point lots are append-only.' USING ERRCODE='23514';
  END IF;
  IF OLD."recipient_user_id" IS DISTINCT FROM NEW."recipient_user_id"
     OR OLD."source_user_id" IS DISTINCT FROM NEW."source_user_id"
     OR OLD."source_kind" IS DISTINCT FROM NEW."source_kind"
     OR OLD."source_event_id" IS DISTINCT FROM NEW."source_event_id"
     OR OLD."leg" IS DISTINCT FROM NEW."leg"
     OR OLD."original_points" IS DISTINCT FROM NEW."original_points"
     OR OLD."generated_at" IS DISTINCT FROM NEW."generated_at"
     OR OLD."created_at" IS DISTINCT FROM NEW."created_at"
     OR NEW."remaining_points" > OLD."remaining_points" THEN
    RAISE EXCEPTION 'Binary point lot identity or consumed balance is immutable.' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_binary_tree_placement_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_binary_tree_placement_identity() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public'
    AS $$
BEGIN
  IF TG_OP IN ('DELETE', 'TRUNCATE') THEN
    RAISE EXCEPTION 'Binary-tree placement records cannot be deleted or truncated.'
      USING ERRCODE = '55000';
  END IF;

  IF NEW."id" IS DISTINCT FROM OLD."id"
     OR NEW."user_id" IS DISTINCT FROM OLD."user_id"
     OR NEW."parent_id" IS DISTINCT FROM OLD."parent_id"
     OR NEW."position" IS DISTINCT FROM OLD."position"
     OR NEW."sponsor_id" IS DISTINCT FROM OLD."sponsor_id"
     OR NEW."is_overflow" IS DISTINCT FROM OLD."is_overflow"
     OR NEW."created_at" IS DISTINCT FROM OLD."created_at" THEN
    RAISE EXCEPTION 'Binary-tree placement identity is immutable after insertion.'
      USING ERRCODE = '55000';
  END IF;

  IF (
       NEW."left_count" IS DISTINCT FROM OLD."left_count"
       OR NEW."right_count" IS DISTINCT FROM OLD."right_count"
     )
     AND NOT (
       pg_trigger_depth() > 1
       AND current_setting('hiroma.binary_tree_count_maintenance', true) = 'on'
     ) THEN
    RAISE EXCEPTION 'Binary-tree descendant counts are maintained only by placement insertion.'
      USING ERRCODE = '55000';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: protect_combined_order_replacement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_combined_order_replacement() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='UPDATE' AND pg_trigger_depth()>1 AND (to_jsonb(OLD)-'state')=(to_jsonb(NEW)-'state')
   AND OLD.state='pending' AND NEW.state IN ('cancelled','dispatched') THEN RETURN NEW; END IF;
 IF TG_OP='INSERT' AND NEW.state='pending' THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'Combined replacement history is protected.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_combined_order_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_combined_order_unit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' AND pg_trigger_depth()>1 THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'Combined replacement allocation is protected.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_inventory_transfer_custody(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_inventory_transfer_custody() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Inventory transfer evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW."status" <> 'in_transit' OR NEW."dispatched_by_actor_id" IS NULL
       OR NEW."reference_value" <= 0 OR NEW."admin_id" = NEW."recipient_id" THEN
      RAISE EXCEPTION 'New inventory transfer requires an actual dispatch actor and positive reference value.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;
  IF ROW(OLD."reference_number", OLD."admin_id", OLD."dispatched_by_actor_id",
         OLD."recipient_id", OLD."reference_value", OLD."notes",
         OLD."dispatched_at", OLD."created_at")
     IS DISTINCT FROM
     ROW(NEW."reference_number", NEW."admin_id", NEW."dispatched_by_actor_id",
         NEW."recipient_id", NEW."reference_value", NEW."notes",
         NEW."dispatched_at", NEW."created_at") THEN
    RAISE EXCEPTION 'Inventory transfer dispatch identity is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" IS DISTINCT FROM NEW."status" AND NOT (
       (OLD."status" = 'in_transit' AND NEW."status" = 'receiving')
       OR (OLD."status" = 'receiving' AND NEW."status" IN ('received_full', 'received_discrepancy', 'rejected'))
     ) THEN
    RAISE EXCEPTION 'Inventory transfer status transition is not monotonic.' USING ERRCODE = '55000';
  END IF;
  IF NEW."status" IN ('received_full', 'received_discrepancy', 'rejected') AND (
       NEW."received_at" IS NULL OR NEW."received_by" IS NULL OR NEW."received_by_actor_id" IS NULL
     ) THEN
    RAISE EXCEPTION 'Resolved inventory transfer requires Branch owner, actual receiving actor, and time.' USING ERRCODE = '23514';
  END IF;
  IF OLD."received_at" IS NOT NULL AND ROW(
       OLD."status", OLD."received_at", OLD."received_by", OLD."received_by_actor_id", OLD."receiving_notes"
     ) IS DISTINCT FROM ROW(
       NEW."status", NEW."received_at", NEW."received_by", NEW."received_by_actor_id", NEW."receiving_notes"
     ) THEN
    RAISE EXCEPTION 'Resolved inventory transfer evidence is immutable.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_order_cancellation_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_order_cancellation_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."status" = 'cancelled'::"OrderStatus" AND (
    NEW."cancelled_at" IS DISTINCT FROM OLD."cancelled_at" OR
    NEW."cancelled_by_actor_id" IS DISTINCT FROM OLD."cancelled_by_actor_id" OR
    NEW."cancelled_by_name" IS DISTINCT FROM OLD."cancelled_by_name" OR
    NEW."cancelled_by_role" IS DISTINCT FROM OLD."cancelled_by_role" OR
    NEW."cancellation_reason" IS DISTINCT FROM OLD."cancellation_reason"
  ) THEN
    RAISE EXCEPTION 'Order cancellation evidence is immutable';
  END IF;

  IF NEW."status" = 'cancelled'::"OrderStatus"
     AND OLD."status" IS DISTINCT FROM 'cancelled'::"OrderStatus"
     AND (
       NEW."cancelled_at" IS NULL OR
       NULLIF(BTRIM(NEW."cancelled_by_actor_id"), '') IS NULL OR
       NULLIF(BTRIM(NEW."cancelled_by_name"), '') IS NULL OR
       NULLIF(BTRIM(NEW."cancelled_by_role"), '') IS NULL OR
       NULLIF(BTRIM(NEW."cancellation_reason"), '') IS NULL
     ) THEN
    RAISE EXCEPTION 'Cancelled orders require complete cancellation evidence';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: protect_package_binary_cap_policy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_package_binary_cap_policy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'Cap policy versions are immutable.' USING ERRCODE='23514'; END IF;
 PERFORM pg_advisory_xact_lock(hashtext('package-binary-product-reward-policy'));
 IF NEW.effective_day<=(clock_timestamp() AT TIME ZONE 'Asia/Manila')::date THEN
  RAISE EXCEPTION 'Cap policy must start at a future Philippine midnight.' USING ERRCODE='23514'; END IF;
 IF NEW.created_by IS NULL OR NOT EXISTS(SELECT 1 FROM users u WHERE u.id=NEW.created_by AND u.role::text='admin' AND u.status::text='active'
  AND COALESCE((to_jsonb(u)->>'is_staff')::boolean,false)=false) THEN
  RAISE EXCEPTION 'An active owner administrator is required.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: protect_package_binary_carryover_policy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_package_binary_carryover_policy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'Carryover policy versions are immutable.' USING ERRCODE='23514'; END IF;
 PERFORM pg_advisory_xact_lock(hashtext('package-binary-product-reward-policy'));
 IF pg_trigger_depth()>1 AND NEW.created_by IS NULL AND NEW.cap_policy_id IS NULL AND NEW.enabled AND NEW.max_points=180000
  AND NEW.effective_day=(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date
  AND NOT EXISTS(SELECT 1 FROM package_binary_carryover_policies WHERE package_id=NEW.package_id) THEN RETURN NEW; END IF;
 IF NEW.effective_day<=(clock_timestamp() AT TIME ZONE 'Asia/Manila')::date THEN RAISE EXCEPTION 'Carryover policy must start at a future Philippine midnight.' USING ERRCODE='23514'; END IF;
 IF NEW.created_by IS NULL OR NOT EXISTS(SELECT 1 FROM users u WHERE u.id=NEW.created_by AND u.role::text='admin' AND u.status::text='active' AND COALESCE((to_jsonb(u)->>'is_staff')::boolean,false)=false) THEN RAISE EXCEPTION 'An active owner administrator is required.' USING ERRCODE='23514'; END IF;
 IF NEW.enabled AND NEW.max_points<(SELECT ROUND(pairing_bonus_value)::integer FROM packages WHERE id=NEW.package_id) THEN RAISE EXCEPTION 'Unmatched point limit must allow at least one pair.' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS(SELECT 1 FROM package_binary_cap_policies p WHERE p.id=NEW.cap_policy_id AND p.package_id=NEW.package_id AND p.effective_day=NEW.effective_day AND p.created_by=NEW.created_by) THEN RAISE EXCEPTION 'Carryover policy requires its matching scheduled cap version.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: protect_paid_pin_sale_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_paid_pin_sale_order() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW."financial_purpose" = 'pin_sale' AND (
         NEW."status" <> 'delivered'::"OrderStatus"
         OR NEW."payment_status" <> 'paid'
         OR NEW."paid_at" IS NULL
         OR NEW."delivered_at" IS NULL
         OR LENGTH(TRIM(COALESCE(NEW."payment_method", ''))) < 2
         OR LENGTH(TRIM(COALESCE(NEW."payment_reference", ''))) < 3
         OR LENGTH(TRIM(COALESCE(NEW."payment_sender_name", ''))) < 2
         OR NEW."payment_evidence_at" IS NULL
         OR NEW."payment_recorded_by_actor_id" IS NULL
         OR NEW."payment_verified_by_actor_id" IS NULL
       ) THEN
      RAISE EXCEPTION 'A new PIN sale requires complete paid receipt evidence.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;
  IF OLD."financial_purpose" IS DISTINCT FROM NEW."financial_purpose" THEN
    RAISE EXCEPTION 'Order financial purpose is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."financial_purpose" = 'pin_sale' AND (
       OLD."buyer_id" IS DISTINCT FROM NEW."buyer_id"
       OR OLD."seller_id" IS DISTINCT FROM NEW."seller_id"
       OR OLD."total_amount" IS DISTINCT FROM NEW."total_amount"
       OR OLD."status" IS DISTINCT FROM NEW."status"
       OR OLD."payment_method" IS DISTINCT FROM NEW."payment_method"
       OR OLD."payment_reference" IS DISTINCT FROM NEW."payment_reference"
       OR OLD."payment_status" IS DISTINCT FROM NEW."payment_status"
       OR OLD."payment_sender_name" IS DISTINCT FROM NEW."payment_sender_name"
       OR OLD."payment_evidence_at" IS DISTINCT FROM NEW."payment_evidence_at"
       OR OLD."payment_recorded_by_actor_id" IS DISTINCT FROM NEW."payment_recorded_by_actor_id"
       OR OLD."payment_verified_by_actor_id" IS DISTINCT FROM NEW."payment_verified_by_actor_id"
       OR OLD."paid_at" IS DISTINCT FROM NEW."paid_at"
       OR OLD."delivered_at" IS DISTINCT FROM NEW."delivered_at"
     ) THEN
    RAISE EXCEPTION 'A PIN funding order and its payment evidence are immutable after issuance.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_payout_batch_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_payout_batch_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' AND (NEW."batch_id" IS NULL OR length(btrim(NEW."batch_id")) = 0) THEN
    RAISE EXCEPTION 'A payout requires an immutable batch identifier.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'UPDATE' AND NEW."batch_id" IS DISTINCT FROM OLD."batch_id" THEN
    RAISE EXCEPTION 'Payout batch identity is immutable.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_payout_disbursement_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_payout_disbursement_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  releaser_role TEXT;
  releaser_status TEXT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW."disbursement_provider" IS NOT NULL OR NEW."external_reference" IS NOT NULL
       OR NEW."disbursed_amount" IS NOT NULL OR NEW."disbursed_at" IS NOT NULL
       OR NEW."released_by" IS NOT NULL THEN
      RAISE EXCEPTION 'A new payout cannot contain premature disbursement evidence.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  IF OLD."status" = 'approved'::"PayoutStatus" AND NEW."status" = 'released'::"PayoutStatus" THEN
    IF NEW."disbursement_provider" IS NULL OR length(btrim(NEW."disbursement_provider")) = 0
       OR NEW."external_reference" IS NULL OR length(btrim(NEW."external_reference")) = 0
       OR NEW."disbursed_amount" IS DISTINCT FROM NEW."amount"
       OR NEW."disbursed_at" IS NULL OR NEW."disbursed_at" > transaction_timestamp()
       OR NEW."released_by" IS NULL THEN
      RAISE EXCEPTION 'Payout release requires complete matching external disbursement evidence.' USING ERRCODE = '23514';
    END IF;
    SELECT "role"::TEXT, "status"::TEXT INTO releaser_role, releaser_status
    FROM "users" WHERE "id" = NEW."released_by" FOR SHARE;
    IF releaser_role <> 'admin' OR releaser_status <> 'active' THEN
      RAISE EXCEPTION 'Payout releaser must be an active administrator.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW."disbursement_provider" IS DISTINCT FROM OLD."disbursement_provider"
     OR NEW."external_reference" IS DISTINCT FROM OLD."external_reference"
     OR NEW."disbursed_amount" IS DISTINCT FROM OLD."disbursed_amount"
     OR NEW."disbursed_at" IS DISTINCT FROM OLD."disbursed_at"
     OR NEW."released_by" IS DISTINCT FROM OLD."released_by" THEN
    RAISE EXCEPTION 'Disbursement evidence is immutable and may be recorded only during release.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_person_account_registry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_person_account_registry() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
 IF pg_trigger_depth()>1 AND TG_OP='INSERT' THEN RETURN NEW; END IF;
 IF pg_trigger_depth()>1 AND TG_TABLE_NAME='person_account_totals' AND TG_OP='UPDATE' THEN
   IF NEW.person_key=OLD.person_key AND NEW.account_count=OLD.account_count+1 THEN RETURN NEW; END IF;
 END IF;
 RAISE EXCEPTION 'Lifetime identity records cannot be edited, deleted or reset.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_pin_request_payment_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_pin_request_payment_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'PIN request payment evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF NEW."pin_request_id" IS DISTINCT FROM OLD."pin_request_id"
     OR NEW."payment_method_id" IS DISTINCT FROM OLD."payment_method_id"
     OR NEW."provider_snapshot" IS DISTINCT FROM OLD."provider_snapshot"
     OR NEW."account_name_snapshot" IS DISTINCT FROM OLD."account_name_snapshot"
     OR NEW."account_number_snapshot" IS DISTINCT FROM OLD."account_number_snapshot"
     OR NEW."bank_name_snapshot" IS DISTINCT FROM OLD."bank_name_snapshot"
     OR NEW."sender_name" IS DISTINCT FROM OLD."sender_name"
     OR NEW."reference_number" IS DISTINCT FROM OLD."reference_number"
     OR NEW."paid_at" IS DISTINCT FROM OLD."paid_at"
     OR NEW."proof_path" IS DISTINCT FROM OLD."proof_path"
     OR NEW."created_at" IS DISTINCT FROM OLD."created_at" THEN
    RAISE EXCEPTION 'Submitted PIN payment facts are immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" <> 'submitted' AND ROW(NEW."status", NEW."reviewed_by_actor_id", NEW."reviewed_at", NEW."review_notes")
     IS DISTINCT FROM ROW(OLD."status", OLD."reviewed_by_actor_id", OLD."reviewed_at", OLD."review_notes") THEN
    RAISE EXCEPTION 'Reviewed PIN payment evidence is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" = 'submitted' AND NEW."status" NOT IN ('verified', 'rejected') THEN
    RAISE EXCEPTION 'Payment evidence may only be verified or rejected.' USING ERRCODE = '23514';
  END IF;
  IF OLD."status" = 'submitted' AND (NEW."reviewed_by_actor_id" IS NULL OR NEW."reviewed_at" IS NULL OR LENGTH(TRIM(COALESCE(NEW."review_notes", ''))) < 5) THEN
    RAISE EXCEPTION 'Payment evidence review requires an actor, time, and notes.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_pin_request_registration_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_pin_request_registration_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."registration_snapshot" IS NOT NULL
     AND OLD."registration_snapshot" IS DISTINCT FROM NEW."registration_snapshot" THEN
    RAISE EXCEPTION 'PIN request financial snapshot is immutable.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_pin_transfer(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_pin_transfer() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  admin_role TEXT;
  recipient_role TEXT;
  recipient_level TEXT;
  recipient_status TEXT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'PIN transfer evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF TG_OP = 'INSERT' THEN
    SELECT "role"::text INTO admin_role FROM "users" WHERE "id" = NEW."admin_id" FOR SHARE;
    SELECT users."role"::text, profiles."dist_level"::text, users."status"::text
    INTO recipient_role, recipient_level, recipient_status
    FROM "users" users
    LEFT JOIN "distributor_profiles" profiles ON profiles."user_id" = users."id"
    WHERE users."id" = NEW."recipient_id" FOR SHARE OF users;
    IF admin_role <> 'admin'
       OR recipient_role <> 'city'
       OR recipient_level <> 'branch'
       OR recipient_status <> 'active'
       OR NEW."recipient_id" = NEW."admin_id"
       OR NEW."quantity" <= 0 OR NEW."quantity" > 50
       OR NEW."unit_allocation" <= 0
       OR NEW."reference_value" <> ROUND(NEW."unit_allocation" * NEW."quantity", 2)
       OR NEW."sale_value" <> 0
       OR NEW."status" <> 'in_transit'
       OR NEW."pin_type" NOT IN ('registration', 'upgrade')
       OR (NEW."pin_type" = 'upgrade' AND NEW."upgrade_from_package_id" IS NULL) THEN
      RAISE EXCEPTION 'PIN transfer must be a zero-revenue Admin-to-Branch custody movement with exact economics.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;
  IF ROW(OLD."reference_number", OLD."admin_id", OLD."recipient_id", OLD."initiated_by_actor_id",
         OLD."package_id", OLD."pin_type", OLD."upgrade_from_package_id", OLD."quantity",
         OLD."unit_allocation", OLD."reference_value", OLD."sale_value", OLD."notes",
         OLD."dispatched_at", OLD."created_at")
     IS DISTINCT FROM
     ROW(NEW."reference_number", NEW."admin_id", NEW."recipient_id", NEW."initiated_by_actor_id",
         NEW."package_id", NEW."pin_type", NEW."upgrade_from_package_id", NEW."quantity",
         NEW."unit_allocation", NEW."reference_value", NEW."sale_value", NEW."notes",
         NEW."dispatched_at", NEW."created_at") THEN
    RAISE EXCEPTION 'PIN transfer financial and custody identity is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" IS DISTINCT FROM NEW."status" AND NOT (
       OLD."status" = 'in_transit' AND NEW."status" IN ('received', 'rejected')
     ) THEN
    RAISE EXCEPTION 'PIN transfer status transition is not monotonic.' USING ERRCODE = '55000';
  END IF;
  IF NEW."status" = 'received' AND (NEW."received_at" IS NULL OR NEW."received_by_actor_id" IS NULL) THEN
    RAISE EXCEPTION 'Received PIN transfer requires receiving actor and time.' USING ERRCODE = '23514';
  END IF;
  IF NEW."status" = 'rejected' AND (
       NEW."rejected_at" IS NULL OR NEW."rejected_by_actor_id" IS NULL
       OR LENGTH(TRIM(COALESCE(NEW."rejection_reason", ''))) < 3
     ) THEN
    RAISE EXCEPTION 'Rejected PIN transfer requires actor, time, and reason.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_product_binary_job_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_product_binary_job_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Product Binary settlement obligations cannot be deleted.' USING ERRCODE = '55000';
  END IF;
  IF NEW."id" IS DISTINCT FROM OLD."id" OR NEW."order_id" IS DISTINCT FROM OLD."order_id"
     OR NEW."created_at" IS DISTINCT FROM OLD."created_at" THEN
    RAISE EXCEPTION 'Product Binary settlement obligation identity is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" = 'completed' AND NEW."status" <> 'completed' THEN
    RAISE EXCEPTION 'Completed Product Binary settlement cannot be reopened.' USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_product_reward_claim_data(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_product_reward_claim_data() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP='INSERT' AND TG_TABLE_NAME='product_reward_claim_allocations' AND pg_trigger_depth()>1 THEN
    IF EXISTS(SELECT 1 FROM package_binary_product_rewards r JOIN product_reward_claims c ON c.id=NEW.claim_id
      WHERE r.id=NEW.reward_id AND r.user_id=c.reseller_id AND r.product_id=c.product_id AND NEW.unit_number BETWEEN 1 AND r.quantity)
    THEN RETURN NEW; END IF;
  END IF;
  IF TG_OP='UPDATE' AND TG_TABLE_NAME='product_reward_claim_proofs' AND pg_trigger_depth()>1 THEN
    IF OLD.used_at IS NULL AND NEW.used_at IS NOT NULL
      AND (to_jsonb(OLD)-'used_at')=(to_jsonb(NEW)-'used_at') THEN RETURN NEW; END IF;
  END IF;
  RAISE EXCEPTION 'Product reward claim history is protected.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_registration_snapshot_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_registration_snapshot_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."pin_code" IS DISTINCT FROM NEW."pin_code"
     OR OLD."created_at" IS DISTINCT FROM NEW."created_at"
     OR OLD."pin_allocation_snapshot" IS DISTINCT FROM NEW."pin_allocation_snapshot"
     OR OLD."registration_package_name_snapshot" IS DISTINCT FROM NEW."registration_package_name_snapshot"
     OR OLD."registration_customer_payment_snapshot" IS DISTINCT FROM NEW."registration_customer_payment_snapshot"
     OR OLD."registration_reseller_value_snapshot" IS DISTINCT FROM NEW."registration_reseller_value_snapshot"
     OR OLD."registration_acquisition_cost_snapshot" IS DISTINCT FROM NEW."registration_acquisition_cost_snapshot"
     OR OLD."registration_acquisition_tier_snapshot" IS DISTINCT FROM NEW."registration_acquisition_tier_snapshot"
     OR OLD."registration_direct_allocation_snapshot" IS DISTINCT FROM NEW."registration_direct_allocation_snapshot"
     OR OLD."registration_binary_allocation_snapshot" IS DISTINCT FROM NEW."registration_binary_allocation_snapshot"
     OR OLD."registration_points_snapshot" IS DISTINCT FROM NEW."registration_points_snapshot"
     OR OLD."registration_product_line_count_snapshot" IS DISTINCT FROM NEW."registration_product_line_count_snapshot"
     OR OLD."registration_units_snapshot" IS DISTINCT FROM NEW."registration_units_snapshot" THEN
    RAISE EXCEPTION 'Issued PIN financial snapshots are immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."pin_allocation_snapshot" IS NOT NULL AND (
       OLD."package_id" IS DISTINCT FROM NEW."package_id"
       OR OLD."city_dist_id" IS DISTINCT FROM NEW."city_dist_id"
       OR OLD."generated_by" IS DISTINCT FROM NEW."generated_by"
       OR OLD."generated_by_actor_id" IS DISTINCT FROM NEW."generated_by_actor_id"
       OR OLD."funding_order_id" IS DISTINCT FROM NEW."funding_order_id"
       OR OLD."funding_pin_request_id" IS DISTINCT FROM NEW."funding_pin_request_id"
       OR OLD."funding_pin_transfer_id" IS DISTINCT FROM NEW."funding_pin_transfer_id"
       OR OLD."pin_type" IS DISTINCT FROM NEW."pin_type"
       OR OLD."upgrade_from_package_id" IS DISTINCT FROM NEW."upgrade_from_package_id"
     ) THEN
    RAISE EXCEPTION 'Issued PIN ownership, source, generator, package, and type are immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" IS DISTINCT FROM NEW."status" AND NOT (
       (OLD."status" = 'in_transit'::"PinStatus" AND NEW."status" IN ('unused'::"PinStatus", 'cancelled'::"PinStatus"))
       OR
       (OLD."status" = 'unused'::"PinStatus" AND NEW."status" IN ('used'::"PinStatus", 'cancelled'::"PinStatus", 'expired'::"PinStatus"))
     ) THEN
    RAISE EXCEPTION 'PIN status transition is not monotonic.' USING ERRCODE = '55000';
  END IF;
  IF OLD."used_by" IS NOT NULL AND (
       OLD."used_by" IS DISTINCT FROM NEW."used_by"
       OR OLD."used_at" IS DISTINCT FROM NEW."used_at"
     ) THEN
    RAISE EXCEPTION 'A redeemed PIN cannot be rebound or restamped.' USING ERRCODE = '55000';
  END IF;
  IF OLD."cancelled_at" IS NOT NULL AND (
       OLD."cancelled_at" IS DISTINCT FROM NEW."cancelled_at"
       OR OLD."cancelled_by" IS DISTINCT FROM NEW."cancelled_by"
       OR OLD."cancellation_reason" IS DISTINCT FROM NEW."cancellation_reason"
       OR OLD."cancellation_disposition" IS DISTINCT FROM NEW."cancellation_disposition"
       OR OLD."cancellation_reference" IS DISTINCT FROM NEW."cancellation_reference"
       OR OLD."cancellation_amount" IS DISTINCT FROM NEW."cancellation_amount"
     ) THEN
    RAISE EXCEPTION 'PIN cancellation evidence is immutable.' USING ERRCODE = '55000';
  END IF;
  IF NEW."status" = 'used'::"PinStatus" AND (NEW."used_by" IS NULL OR NEW."used_at" IS NULL) THEN
    RAISE EXCEPTION 'A used PIN must identify its member and redemption time.' USING ERRCODE = '23514';
  END IF;
  IF NEW."status" = 'cancelled'::"PinStatus" AND (
       NEW."cancelled_at" IS NULL
       OR NEW."cancelled_by" IS NULL
       OR LENGTH(TRIM(COALESCE(NEW."cancellation_reason", ''))) < 3
       OR NEW."cancellation_disposition" NOT IN ('refunded', 'credited', 'retained', 'internal_transfer_rejected', 'legacy_unclassified')
       OR NEW."cancellation_amount" IS NULL
       OR NEW."cancellation_amount" < 0
       OR (NEW."cancellation_disposition" IN ('refunded', 'credited')
           AND LENGTH(TRIM(COALESCE(NEW."cancellation_reference", ''))) < 3)
     ) THEN
    RAISE EXCEPTION 'A cancelled PIN requires complete immutable financial disposition evidence.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_reward_stock_dispatch_item(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_reward_stock_dispatch_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP='INSERT' AND pg_trigger_depth()>1 AND EXISTS(
    SELECT 1 FROM reward_stock_units u JOIN reward_stock_dispatches d ON d.id=NEW.dispatch_id
    WHERE u.id=NEW.unit_id AND u.holder_id=d.recipient_id AND u.product_id=d.product_id AND u.kind=d.kind AND u.cycle=NEW.cycle
      AND u.current_dispatch_id IS NULL AND u.settled_at IS NULL) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Replacement shipment allocations are protected.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_reward_stock_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_reward_stock_unit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF pg_trigger_depth()>1 THEN
    IF TG_OP='INSERT' THEN RETURN NEW; END IF;
    IF TG_OP='UPDATE' AND (to_jsonb(OLD)-ARRAY['holder_id','current_dispatch_id','cycle','settled_at'])=
      (to_jsonb(NEW)-ARRAY['holder_id','current_dispatch_id','cycle','settled_at']) THEN RETURN NEW; END IF;
  END IF;
  RAISE EXCEPTION 'Replacement obligations can change only through a recorded release or receipt.' USING ERRCODE='23514';
END $$;


--
-- Name: protect_upgrade_snapshot_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_upgrade_snapshot_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."pin_type" = 'upgrade' AND (
       OLD."pin_allocation_snapshot"
         IS DISTINCT FROM NEW."pin_allocation_snapshot"
       OR OLD."upgrade_customer_payment_snapshot"
         IS DISTINCT FROM NEW."upgrade_customer_payment_snapshot"
       OR OLD."upgrade_reseller_value_snapshot"
         IS DISTINCT FROM NEW."upgrade_reseller_value_snapshot"
       OR OLD."upgrade_acquisition_cost_snapshot"
         IS DISTINCT FROM NEW."upgrade_acquisition_cost_snapshot"
       OR OLD."upgrade_acquisition_tier_snapshot"
         IS DISTINCT FROM NEW."upgrade_acquisition_tier_snapshot"
       OR OLD."upgrade_direct_allocation_snapshot"
         IS DISTINCT FROM NEW."upgrade_direct_allocation_snapshot"
       OR OLD."upgrade_binary_allocation_snapshot"
         IS DISTINCT FROM NEW."upgrade_binary_allocation_snapshot"
       OR OLD."upgrade_points_difference_snapshot"
         IS DISTINCT FROM NEW."upgrade_points_difference_snapshot"
       OR OLD."upgrade_product_line_count_snapshot"
         IS DISTINCT FROM NEW."upgrade_product_line_count_snapshot"
       OR OLD."upgrade_units_snapshot"
         IS DISTINCT FROM NEW."upgrade_units_snapshot"
     ) THEN
    RAISE EXCEPTION 'Issued Upgrade PIN financial snapshots are immutable.'
      USING ERRCODE = '55000';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: protect_wallet_balances(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_wallet_balances() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Wallets cannot be deleted; use the immutable ledger.' USING ERRCODE = '55000';
  END IF;
  IF pg_trigger_depth() <= 1 THEN
    IF TG_OP = 'INSERT' AND (
      NEW."balance" <> 0 OR NEW."reserved_balance" <> 0
      OR NEW."total_earned" <> 0 OR NEW."total_withdrawn" <> 0
    ) THEN
      RAISE EXCEPTION 'Non-zero wallets must be created by the immutable ledger.' USING ERRCODE = '55000';
    ELSIF TG_OP = 'UPDATE' AND (
      NEW."balance" IS DISTINCT FROM OLD."balance"
      OR NEW."reserved_balance" IS DISTINCT FROM OLD."reserved_balance"
      OR NEW."total_earned" IS DISTINCT FROM OLD."total_earned"
      OR NEW."total_withdrawn" IS DISTINCT FROM OLD."total_withdrawn"
    ) THEN
      RAISE EXCEPTION 'Wallet balances may only be changed by the immutable ledger.' USING ERRCODE = '55000';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: qualify_product_binary_order(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qualify_product_binary_order(target_order_id text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  source_order RECORD;
  item_count INTEGER;
  exact_item_count INTEGER;
  eligible_units INTEGER;
  total_pu INTEGER;
  order_gross_margin DECIMAL(12,2);
  company_gross_margin DECIMAL(12,2);
  funding_amount DECIMAL(12,2);
  target_status TEXT;
  target_qualification TEXT;
  target_error TEXT;
BEGIN
  SELECT orders."id", orders."buyer_id", orders."seller_id", buyer."role"::text AS buyer_role,
         seller."role"::text AS seller_role, orders."status"::text AS order_status,
         orders."payment_status", orders."financial_purpose", orders."paid_at", orders."delivered_at"
  INTO source_order
  FROM "orders" orders
  JOIN "users" buyer ON buyer."id" = orders."buyer_id"
  JOIN "users" seller ON seller."id" = orders."seller_id"
  WHERE orders."id" = target_order_id
  FOR SHARE OF orders, buyer, seller;

  IF NOT FOUND OR source_order.order_status <> 'delivered'
     OR source_order.financial_purpose <> 'commerce' THEN
    RETURN;
  END IF;

  SELECT COUNT(*)::INTEGER,
         COUNT(*) FILTER (
           WHERE item."snapshot_source" = 'product-binary-order-v1'
             AND item."binary_eligible_snapshot" IS NOT NULL
             AND item."pu_value_snapshot" IS NOT NULL
             AND item."company_unit_cost_snapshot" IS NOT NULL
             AND item."company_unit_margin_snapshot" IS NOT NULL
             AND item."snapshotted_at" IS NOT NULL
         )::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" ELSE 0 END), 0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * item."pu_value_snapshot" ELSE 0 END), 0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * GREATEST(0, item."unit_price" - COALESCE(item."unit_acquisition_cost", item."company_unit_cost_snapshot"))
                           ELSE 0 END), 0)::DECIMAL(12,2),
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * item."company_unit_margin_snapshot" ELSE 0 END), 0)::DECIMAL(12,2)
  INTO item_count, exact_item_count, eligible_units, total_pu, order_gross_margin, company_gross_margin
  FROM "order_items" item
  WHERE item."order_id" = target_order_id;

  IF source_order.buyer_role = 'reseller' THEN
    IF source_order.payment_status IS DISTINCT FROM 'paid' OR source_order.paid_at IS NULL THEN
      target_status := 'waiting_payment';
      target_qualification := 'waiting_for_paid_delivery';
      target_error := 'Product Binary waits for seller-confirmed payment.';
    ELSIF item_count = 0 OR exact_item_count <> item_count THEN
      target_status := 'reconciliation_required';
      target_qualification := 'legacy_snapshot_reconciliation';
      target_error := 'Paid delivered legacy order has no complete database-authored Product Binary item snapshot.';
    ELSIF total_pu <= 0 THEN
      target_status := 'completed';
      target_qualification := 'ineligible_zero_pu';
      target_error := NULL;
    ELSE
      target_status := 'pending';
      target_qualification := 'qualified_paid_delivery';
      target_error := NULL;
    END IF;

    INSERT INTO "product_binary_settlement_jobs" (
      "id", "order_id", "status", "qualification_status", "buyer_user_id",
      "payment_status_snapshot", "paid_at_snapshot", "delivered_at_snapshot",
      "eligible_units_snapshot", "total_pu_snapshot", "gross_margin_snapshot",
      "snapshot_version", "qualified_at", "last_error", "completed_at", "next_attempt_at", "updated_at"
    ) VALUES (
      gen_random_uuid(), target_order_id, target_status, target_qualification, source_order.buyer_id,
      source_order.payment_status, source_order.paid_at, source_order.delivered_at,
      CASE WHEN source_order.payment_status = 'paid' AND exact_item_count = item_count AND item_count > 0 THEN eligible_units ELSE NULL END,
      CASE WHEN source_order.payment_status = 'paid' AND exact_item_count = item_count AND item_count > 0 THEN total_pu ELSE NULL END,
      CASE WHEN source_order.payment_status = 'paid' AND exact_item_count = item_count AND item_count > 0 THEN order_gross_margin ELSE NULL END,
      CASE WHEN source_order.payment_status = 'paid' AND exact_item_count = item_count AND item_count > 0 THEN 'product-binary-order-v1' ELSE NULL END,
      CASE WHEN source_order.payment_status = 'paid' THEN transaction_timestamp() ELSE NULL END,
      target_error,
      CASE WHEN target_status = 'completed' THEN transaction_timestamp() ELSE NULL END,
      transaction_timestamp(), transaction_timestamp()
    )
    ON CONFLICT ("order_id") DO UPDATE SET
      "status" = EXCLUDED."status",
      "qualification_status" = EXCLUDED."qualification_status",
      "buyer_user_id" = EXCLUDED."buyer_user_id",
      "payment_status_snapshot" = EXCLUDED."payment_status_snapshot",
      "paid_at_snapshot" = EXCLUDED."paid_at_snapshot",
      "delivered_at_snapshot" = EXCLUDED."delivered_at_snapshot",
      "eligible_units_snapshot" = EXCLUDED."eligible_units_snapshot",
      "total_pu_snapshot" = EXCLUDED."total_pu_snapshot",
      "gross_margin_snapshot" = EXCLUDED."gross_margin_snapshot",
      "snapshot_version" = EXCLUDED."snapshot_version",
      "qualified_at" = EXCLUDED."qualified_at",
      "last_error" = EXCLUDED."last_error",
      "completed_at" = EXCLUDED."completed_at",
      "next_attempt_at" = EXCLUDED."next_attempt_at",
      "updated_at" = transaction_timestamp()
    WHERE "product_binary_settlement_jobs"."status" <> 'completed';
  END IF;

  -- Only realized Hiroma/Admin commerce margin creates reserve. Distributor
  -- resale orders can create PU obligations, but never fabricate company funds.
  IF source_order.seller_role = 'admin'
     AND source_order.payment_status = 'paid'
     AND source_order.paid_at IS NOT NULL THEN
    IF item_count = 0 OR exact_item_count <> item_count THEN
      INSERT INTO "product_binary_funding_lots" (
        "id", "order_id", "original_amount", "remaining_amount", "snapshot_source",
        "payment_status_snapshot", "paid_at_snapshot", "delivered_at_snapshot",
        "snapshot_version", "reconciliation_status", "allocated_at"
      ) VALUES (
        gen_random_uuid(), target_order_id, 0, 0, 'legacy_order_reconciliation_required',
        'paid', source_order.paid_at, source_order.delivered_at,
        NULL, 'legacy_snapshot_reconciliation', GREATEST(source_order.paid_at, source_order.delivered_at)
      ) ON CONFLICT ("order_id") DO NOTHING;
    ELSE
      funding_amount := LEAST(GREATEST(0, company_gross_margin), eligible_units * 20.00);
      INSERT INTO "product_binary_funding_lots" (
        "id", "order_id", "original_amount", "remaining_amount", "snapshot_source",
        "payment_status_snapshot", "paid_at_snapshot", "delivered_at_snapshot",
        "eligible_units_snapshot", "total_pu_snapshot", "gross_margin_snapshot",
        "snapshot_version", "reconciliation_status", "allocated_at"
      ) VALUES (
        gen_random_uuid(), target_order_id, funding_amount, funding_amount, 'paid-delivered-admin-order',
        'paid', source_order.paid_at, source_order.delivered_at,
        eligible_units, total_pu, company_gross_margin,
        'product-binary-order-v1', 'exact', GREATEST(source_order.paid_at, source_order.delivered_at)
      ) ON CONFLICT ("order_id") DO NOTHING;
    END IF;
  END IF;
END;
$$;


--
-- Name: qualify_product_binary_order_trigger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.qualify_product_binary_order_trigger() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM "qualify_product_binary_order"(NEW."id");
  RETURN NEW;
END;
$$;


--
-- Name: queue_product_binary_pool_order(uuid, timestamp with time zone, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_product_binary_pool_order(order_key uuid, settlement_time timestamp with time zone, rate_centavos integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  cutoff date;
  target_week date;
BEGIN
  -- Require the protected payout path before accepting any pending obligations.
  IF to_regprocedure('public.credit_product_binary_pool_allocation(date,text)') IS NULL THEN
    RETURN false;
  END IF;
  SELECT value::date INTO cutoff FROM system_settings
  WHERE key = 'product_binary_weekly_cutover';
  target_week := date_trunc('week', settlement_time AT TIME ZONE 'Asia/Manila')::date;
  IF cutoff IS NULL OR target_week < cutoff THEN
    RETURN false;
  END IF;
  IF extract(isodow FROM cutoff) <> 1 THEN
    RAISE EXCEPTION 'Product Binary cutover must be a Manila Monday.';
  END IF;


  PERFORM 1 FROM public.system_settings WHERE key = 'product_binary_pair_amount' FOR SHARE;
  IF NOT EXISTS (
    SELECT 1 FROM public.product_binary_order_events e
    WHERE e.id = order_key AND e.processed_at = transaction_timestamp()
  ) OR target_week <> date_trunc('week', clock_timestamp() AT TIME ZONE 'Asia/Manila')::date
     OR rate_centavos <> public.product_binary_pair_amount() * 100 THEN
    RAISE EXCEPTION 'Invalid Product Binary weekly queue source.';
  END IF;
  INSERT INTO product_binary_pool_weeks (week_start, max_rate_centavos)
  VALUES (target_week, rate_centavos) ON CONFLICT (week_start) DO NOTHING;
  INSERT INTO product_binary_pool_orders (order_event_id, week_start)
  VALUES (order_key, target_week);
  RETURN true;
END;
$$;


--
-- Name: queue_product_binary_pool_pair(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_product_binary_pool_pair() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.payable_pairs > 0 THEN
    INSERT INTO product_binary_pool_pairs (pair_event_id, order_event_id, week_start)
    SELECT NEW.id, NEW.order_event_id, week_start
    FROM product_binary_pool_orders WHERE order_event_id = NEW.order_event_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: rank_bonus_progress(text, timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rank_bonus_progress(member_id text, starts_at timestamp with time zone, ends_at timestamp with time zone) RETURNS TABLE(bottles integer, referrals integer)
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT
    COALESCE((
      SELECT SUM(job.eligible_units_snapshot)
      FROM product_binary_settlement_jobs job
      JOIN orders ON orders.id = job.order_id
      WHERE job.buyer_user_id = member_id AND orders.buyer_id = member_id
        AND job.qualification_status = 'qualified_paid_delivery'
        AND orders.status = 'delivered' AND orders.payment_status = 'paid'
        AND orders.financial_purpose = 'commerce' AND NOT orders.is_non_member_sale
        AND job.qualified_at >= starts_at AND job.qualified_at < ends_at
    ), 0)::int,
    (
      SELECT COUNT(DISTINCT event.referred_user_id)
      FROM direct_referral_settlement_events event
      JOIN registration_financials registration ON registration.id = event.registration_financial_id
      WHERE event.sponsor_user_id = member_id AND event.referred_user_id <> member_id
        AND registration.payment_status = 'paid'
        AND (COALESCE(registration.paid_at, registration.created_at) AT TIME ZONE 'UTC') >= starts_at
        AND (COALESCE(registration.paid_at, registration.created_at) AT TIME ZONE 'UTC') < ends_at
    )::int;
$$;


--
-- Name: receive_reward_stock_dispatch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.receive_reward_stock_dispatch() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE shipment reward_stock_dispatches%ROWTYPE; supplier_role TEXT; receiving INTEGER; applied INTEGER;
BEGIN
  SELECT * INTO shipment FROM reward_stock_dispatches WHERE id=NEW.dispatch_id FOR UPDATE;
  IF NOT FOUND OR NOT reward_stock_actor_allowed(shipment.recipient_id,NEW.actor_id) THEN
    RAISE EXCEPTION 'Only the authorized recipient can confirm this delivery.' USING ERRCODE='23514'; END IF;
  IF EXISTS(SELECT 1 FROM reward_stock_receipts WHERE dispatch_id=NEW.dispatch_id) THEN
    RAISE EXCEPTION 'This replacement delivery was already received.' USING ERRCODE='23514'; END IF;
  supplier_role:=shipment.supplier_role;
  -- No new obligation is minted. Move the original unit to the supplying distributor,
  -- or close it when Hiroma supplied the replacement (including company branches).
  UPDATE reward_stock_units SET holder_id=CASE WHEN supplier_role='admin' THEN NULL ELSE shipment.supplier_id END,
      current_dispatch_id=NULL,settled_at=CASE WHEN supplier_role='admin' THEN clock_timestamp() ELSE NULL END,cycle=cycle+1
    WHERE current_dispatch_id=shipment.id AND holder_id=shipment.recipient_id AND settled_at IS NULL;
  GET DIAGNOSTICS applied=ROW_COUNT;
  IF applied<>shipment.quantity THEN RAISE EXCEPTION 'Replacement obligation allocation mismatch.' USING ERRCODE='23514'; END IF;
  INSERT INTO inventory(id,owner_id,product_id,quantity,reserved_quantity,low_stock_threshold,updated_at)
    VALUES(gen_random_uuid(),shipment.recipient_id,shipment.product_id,shipment.quantity,0,10,clock_timestamp())
    ON CONFLICT(owner_id,product_id) DO UPDATE SET quantity=inventory.quantity+shipment.quantity,updated_at=clock_timestamp()
    RETURNING quantity INTO receiving;
  SELECT full_name INTO NEW.actor_name FROM users WHERE id=NEW.actor_id;
  NEW.stock_before:=receiving-shipment.quantity;NEW.stock_after:=receiving;NEW.received_at:=clock_timestamp();
  INSERT INTO inventory_audit_events(id,owner_id,product_id,actor_id,actor_name_snapshot,event_type,quantity_delta,quantity_before,quantity_after,
    unit_cost_snapshot,total_value,reference_type,reference_id,reason,metadata,created_at)
  VALUES(gen_random_uuid(),shipment.recipient_id,shipment.product_id,NEW.actor_id,NEW.actor_name,'reward_replacement_received',shipment.quantity,NEW.stock_before,NEW.stock_after,
    shipment.unit_cost_snapshot,shipment.quantity*shipment.unit_cost_snapshot,'reward_stock_dispatch',shipment.id::text,
    'Reward replacement stock physically received',jsonb_build_object('supplier_id',shipment.supplier_id,'kind',shipment.kind),NEW.received_at);
  RETURN NEW;
END $$;


--
-- Name: registration_snapshot_is_valid(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.registration_snapshot_is_valid(snapshot jsonb, expected_package_id text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  item JSONB;
  seen_product_ids JSONB := '{}'::jsonb;
  product_id_value TEXT;
  quantity_value NUMERIC;
  srp_value NUMERIC;
  reseller_price_value NUMERIC;
  acquisition_price_value NUMERIC;
  customer_payment_value NUMERIC;
  reseller_value NUMERIC;
  acquisition_cost_value NUMERIC;
  pin_allocation_value NUMERIC;
  direct_allocation_value NUMERIC;
  binary_allocation_value NUMERIC;
  points_value NUMERIC;
  line_count_value NUMERIC;
  units_value NUMERIC;
  actual_line_count INTEGER := 0;
  actual_units NUMERIC := 0;
  actual_customer_payment NUMERIC := 0;
  actual_reseller_value NUMERIC := 0;
  actual_acquisition_cost NUMERIC := 0;
BEGIN
  IF snapshot IS NULL OR jsonb_typeof(snapshot) IS DISTINCT FROM 'object' THEN
    RETURN false;
  END IF;
  IF snapshot->>'version' IS DISTINCT FROM 'registration-pin-v1'
     OR snapshot->>'packageId' IS DISTINCT FROM expected_package_id
     OR COALESCE(length(btrim(snapshot->>'packageName')), 0) = 0
     OR snapshot->>'acquisitionTier' IS NULL
     OR snapshot->>'acquisitionTier' NOT IN ('admin', 'city', 'branch')
     OR jsonb_typeof(snapshot->'products') IS DISTINCT FROM 'array'
     OR jsonb_array_length(snapshot->'products') = 0 THEN
    RETURN false;
  END IF;
  IF jsonb_typeof(snapshot->'customerPayment') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'resellerValue') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'acquisitionCost') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'pinAllocation') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'directAllocation') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'binaryAllocation') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'points') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'productLineCount') IS DISTINCT FROM 'number'
     OR jsonb_typeof(snapshot->'units') IS DISTINCT FROM 'number' THEN
    RETURN false;
  END IF;

  customer_payment_value := (snapshot->>'customerPayment')::NUMERIC;
  reseller_value := (snapshot->>'resellerValue')::NUMERIC;
  acquisition_cost_value := (snapshot->>'acquisitionCost')::NUMERIC;
  pin_allocation_value := (snapshot->>'pinAllocation')::NUMERIC;
  direct_allocation_value := (snapshot->>'directAllocation')::NUMERIC;
  binary_allocation_value := (snapshot->>'binaryAllocation')::NUMERIC;
  points_value := (snapshot->>'points')::NUMERIC;
  line_count_value := (snapshot->>'productLineCount')::NUMERIC;
  units_value := (snapshot->>'units')::NUMERIC;

  IF customer_payment_value <= 0 OR reseller_value <= 0 OR acquisition_cost_value <= 0
     OR pin_allocation_value < 0 OR direct_allocation_value < 0 OR binary_allocation_value < 0
     OR points_value <= 0 OR points_value <> trunc(points_value)
     OR line_count_value <= 0 OR line_count_value <> trunc(line_count_value)
     OR units_value <= 0 OR units_value <> trunc(units_value)
     OR binary_allocation_value <> points_value * 0.5
     OR direct_allocation_value + binary_allocation_value > pin_allocation_value
     OR customer_payment_value <> reseller_value + pin_allocation_value
     OR reseller_value < acquisition_cost_value THEN
    RETURN false;
  END IF;

  FOR item IN SELECT value FROM jsonb_array_elements(snapshot->'products')
  LOOP
    IF jsonb_typeof(item) IS DISTINCT FROM 'object'
       OR jsonb_typeof(item->'product_id') IS DISTINCT FROM 'string'
       OR jsonb_typeof(item->'quantity') IS DISTINCT FROM 'number'
       OR jsonb_typeof(item->'srp_snapshot') IS DISTINCT FROM 'number'
       OR jsonb_typeof(item->'reseller_price_snapshot') IS DISTINCT FROM 'number'
       OR jsonb_typeof(item->'unit_acquisition_cost_snapshot') IS DISTINCT FROM 'number' THEN
      RETURN false;
    END IF;
    product_id_value := btrim(item->>'product_id');
    quantity_value := (item->>'quantity')::NUMERIC;
    srp_value := (item->>'srp_snapshot')::NUMERIC;
    reseller_price_value := (item->>'reseller_price_snapshot')::NUMERIC;
    acquisition_price_value := (item->>'unit_acquisition_cost_snapshot')::NUMERIC;
    IF length(product_id_value) = 0 OR seen_product_ids ? product_id_value
       OR quantity_value <= 0 OR quantity_value <> trunc(quantity_value)
       OR srp_value <= 0 OR reseller_price_value <= 0 OR acquisition_price_value <= 0 THEN
      RETURN false;
    END IF;
    seen_product_ids := seen_product_ids || jsonb_build_object(product_id_value, true);
    actual_line_count := actual_line_count + 1;
    actual_units := actual_units + quantity_value;
    actual_customer_payment := actual_customer_payment + (srp_value * quantity_value);
    actual_reseller_value := actual_reseller_value + (reseller_price_value * quantity_value);
    actual_acquisition_cost := actual_acquisition_cost + (acquisition_price_value * quantity_value);
  END LOOP;

  RETURN actual_line_count = line_count_value
    AND actual_units = units_value
    AND actual_customer_payment = customer_payment_value
    AND actual_reseller_value = reseller_value
    AND actual_acquisition_cost = acquisition_cost_value;
EXCEPTION WHEN OTHERS THEN
  RETURN false;
END;
$$;


--
-- Name: registration_snapshot_matches_pin(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.registration_snapshot_matches_pin(snapshot jsonb, target_pin_id text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
  item JSONB;
  sealed_count INTEGER;
BEGIN
  SELECT * INTO issued FROM "pins" WHERE "id" = target_pin_id FOR SHARE;
  IF NOT FOUND OR issued."pin_type" <> 'registration'
     OR NOT "registration_snapshot_is_valid"(snapshot, issued."package_id") THEN
    RETURN false;
  END IF;

  IF snapshot->>'packageName' IS DISTINCT FROM issued."registration_package_name_snapshot"
     OR snapshot->>'acquisitionTier' IS DISTINCT FROM issued."registration_acquisition_tier_snapshot"
     OR (snapshot->>'customerPayment')::DECIMAL(12,2) IS DISTINCT FROM issued."registration_customer_payment_snapshot"
     OR (snapshot->>'resellerValue')::DECIMAL(12,2) IS DISTINCT FROM issued."registration_reseller_value_snapshot"
     OR (snapshot->>'acquisitionCost')::DECIMAL(12,2) IS DISTINCT FROM issued."registration_acquisition_cost_snapshot"
     OR (snapshot->>'pinAllocation')::DECIMAL(12,2) IS DISTINCT FROM issued."pin_allocation_snapshot"
     OR (snapshot->>'directAllocation')::DECIMAL(12,2) IS DISTINCT FROM issued."registration_direct_allocation_snapshot"
     OR (snapshot->>'binaryAllocation')::DECIMAL(12,2) IS DISTINCT FROM issued."registration_binary_allocation_snapshot"
     OR (snapshot->>'points')::INTEGER IS DISTINCT FROM issued."registration_points_snapshot"
     OR (snapshot->>'productLineCount')::INTEGER IS DISTINCT FROM issued."registration_product_line_count_snapshot"
     OR (snapshot->>'units')::INTEGER IS DISTINCT FROM issued."registration_units_snapshot" THEN
    RETURN false;
  END IF;

  SELECT COUNT(*)::INTEGER INTO sealed_count
  FROM "pin_registration_product_snapshots"
  WHERE "pin_id" = issued."id";
  IF sealed_count <> issued."registration_product_line_count_snapshot" THEN
    RETURN false;
  END IF;

  FOR item IN SELECT value FROM jsonb_array_elements(snapshot->'products')
  LOOP
    IF NOT EXISTS (
      SELECT 1
      FROM "pin_registration_product_snapshots" sealed
      WHERE sealed."pin_id" = issued."id"
        AND sealed."product_id" = item->>'product_id'
        AND sealed."quantity" = (item->>'quantity')::INTEGER
        AND sealed."srp_snapshot" = (item->>'srp_snapshot')::DECIMAL(12,2)
        AND sealed."reseller_price_snapshot" = (item->>'reseller_price_snapshot')::DECIMAL(12,2)
        AND sealed."unit_acquisition_cost_snapshot" = (item->>'unit_acquisition_cost_snapshot')::DECIMAL(12,2)
    ) THEN
      RETURN false;
    END IF;
  END LOOP;
  RETURN true;
EXCEPTION WHEN OTHERS THEN
  RETURN false;
END;
$$;


--
-- Name: reject_commerce_link_to_pin_sale_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_commerce_link_to_pin_sale_order() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  purpose TEXT;
BEGIN
  IF NEW."order_id" IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT "financial_purpose" INTO purpose
  FROM "orders" WHERE "id" = NEW."order_id" FOR SHARE;
  IF purpose = 'pin_sale' THEN
    RAISE EXCEPTION 'A dedicated PIN-sale funding order cannot contain product or POS commerce.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: reject_financial_history_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_financial_history_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION '% is append-only financial history.', TG_TABLE_NAME USING ERRCODE = '55000';
END;
$$;


--
-- Name: reject_legacy_package_cap_edit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_legacy_package_cap_edit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' THEN NEW.daily_binary_pair_cap:=10;NEW.binary_pair_cap_enabled:=true;RETURN NEW;END IF;
 IF NEW.daily_binary_pair_cap IS DISTINCT FROM OLD.daily_binary_pair_cap OR NEW.binary_pair_cap_enabled IS DISTINCT FROM OLD.binary_pair_cap_enabled THEN
  RAISE EXCEPTION 'Schedule Package Binary cap changes in Admin Settings with Security PIN.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: reject_member_id_issuance_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_member_id_issuance_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Member ID issuance history is append-only.' USING ERRCODE = '55000';
END;
$$;


--
-- Name: reject_order_message_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_order_message_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Order message history is immutable';
END;
$$;


--
-- Name: release_product_binary_pool_week(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_product_binary_pool_week(target_week date) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  week_row public.product_binary_pool_weeks;
  member_id text;
  credited integer := 0;
  processed integer := 0;
BEGIN
  SELECT * INTO STRICT week_row FROM public.product_binary_pool_weeks
  WHERE week_start = target_week FOR UPDATE;
  IF week_row.released_at IS NOT NULL THEN RETURN 0; END IF;
  IF week_row.closed_at IS NULL OR clock_timestamp() <
     (((target_week + 9) + time '10:00') AT TIME ZONE 'Asia/Manila') THEN
    RAISE EXCEPTION 'Product Binary week is not ready for Wednesday release.';
  END IF;

  IF week_row.release_started_at IS NULL THEN
    IF public.verify_product_binary_week_readiness(target_week) IS NOT NULL THEN
      RETURN -1;
    END IF;
    UPDATE public.product_binary_pool_weeks SET release_started_at = clock_timestamp()
    WHERE week_start = target_week;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  FOR member_id IN
    SELECT a.recipient_user_id
    FROM public.product_binary_pool_allocations a
    JOIN public.users u ON u.id = a.recipient_user_id
    JOIN public.wallets wallet ON wallet.user_id = u.id
    WHERE a.week_start = target_week AND a.amount_centavos > 0
      AND a.commission_id IS NULL AND a.retained_at IS NULL
      AND u.role = 'reseller' AND u.status = 'active'
    ORDER BY a.recipient_user_id LIMIT 250 FOR SHARE OF u
  LOOP
    processed := processed + 1;
    IF public.credit_product_binary_pool_allocation(target_week, member_id) THEN
      credited := credited + 1;
    ELSIF NOT EXISTS (
      SELECT 1 FROM public.product_binary_pool_allocations a
      WHERE a.week_start = target_week AND a.recipient_user_id = member_id AND a.retained_at IS NOT NULL
    ) THEN
      RAISE EXCEPTION 'Product Binary allocation could not be credited or retained.';
    END IF;
  END LOOP;

  -- A zero-credit pass found no currently eligible recipients. Ineligible
  -- allocations stay reserved for the existing deferred-credit workflow.
  IF processed = 0 THEN
    UPDATE public.product_binary_pool_weeks SET released_at = clock_timestamp()
    WHERE week_start = target_week;
  END IF;
  RETURN credited;
END;
$$;


--
-- Name: release_product_reward_claim(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_product_reward_claim() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  bottle RECORD; proof RECORD; stock RECORD;
  owner_name TEXT; actor_name TEXT; outlet_level TEXT;
BEGIN
  -- Shared by all outlets: a reward can only be allocated once company-wide.
  PERFORM pg_advisory_xact_lock(hashtext('financial-user:' || NEW.reseller_id));
  SELECT * INTO proof FROM product_reward_claim_proofs WHERE id=NEW.proof_id FOR UPDATE;
  IF NOT FOUND OR proof.used_at IS NOT NULL OR proof.expires_at<=clock_timestamp()
    OR (proof.owner_id,proof.actor_id,proof.reseller_id,proof.terminal_id,proof.shift_id)
      IS DISTINCT FROM (NEW.owner_id,NEW.actor_id,NEW.reseller_id,NEW.terminal_id,NEW.shift_id)
  THEN RAISE EXCEPTION 'Scan the reseller Member ID again for this claim.' USING ERRCODE='23514'; END IF;
  SELECT COALESCE(NULLIF(dp.fulfillment_outlet_name,''),u.full_name),dp.dist_level::text
  INTO owner_name,outlet_level FROM users u JOIN distributor_profiles dp ON dp.user_id=u.id
  WHERE u.id=NEW.owner_id AND u.role::text='city' AND u.status::text='active' AND dp.is_active
    AND dp.dist_level::text IN ('city','branch') FOR SHARE OF u,dp;
  IF NOT FOUND THEN RAISE EXCEPTION 'An active branch or city outlet is required.' USING ERRCODE='23514'; END IF;
  SELECT full_name INTO actor_name FROM users WHERE id=NEW.actor_id AND status::text='active' FOR SHARE;
  IF NOT FOUND OR (NEW.actor_id<>NEW.owner_id AND NOT EXISTS (
    SELECT 1 FROM staff_profiles sp JOIN users staff ON staff.id=sp.user_id
    WHERE sp.user_id=NEW.actor_id AND sp.owner_id=NEW.owner_id AND sp.is_active
      AND staff.role::text='staff' AND sp.permissions::jsonb ? 'pos'
  )) THEN RAISE EXCEPTION 'An authorized POS cashier is required.' USING ERRCODE='23514'; END IF;
  PERFORM 1 FROM users WHERE id=NEW.reseller_id AND role::text='reseller' AND status::text='active' FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Active reseller not found.' USING ERRCODE='23514'; END IF;
  PERFORM 1 FROM pos_terminals WHERE id=NEW.terminal_id AND owner_id=NEW.owner_id AND is_active FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'POS terminal is unavailable.' USING ERRCODE='23514'; END IF;
  -- Holding the shift row prevents close-shift from crossing a stock release.
  PERFORM 1 FROM pos_shifts WHERE id=NEW.shift_id AND owner_id=NEW.owner_id
    AND terminal_id=NEW.terminal_id AND opened_by_id=NEW.actor_id AND status::text='open' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Open your own cashier shift before releasing rewards.' USING ERRCODE='23514'; END IF;
  SELECT p.name,CASE WHEN outlet_level='branch' THEN p.branch_price ELSE COALESCE(NULLIF(p.city_price,0),p.cost_price) END unit_cost
  INTO bottle FROM products p WHERE p.id=NEW.product_id FOR SHARE;
  IF NOT FOUND OR bottle.unit_cost<0 THEN RAISE EXCEPTION 'Reward product is unavailable.' USING ERRCODE='23514'; END IF;
  NEW.product_name_snapshot:=bottle.name; NEW.outlet_name_snapshot:=owner_name; NEW.actor_name_snapshot:=actor_name;
  NEW.unit_cost_snapshot:=COALESCE(bottle.unit_cost,0); NEW.released_at:=clock_timestamp();
  SELECT quantity,reserved_quantity INTO stock FROM inventory
    WHERE owner_id=NEW.owner_id AND product_id=NEW.product_id FOR UPDATE;
  IF NOT FOUND OR stock.quantity-stock.reserved_quantity<NEW.quantity THEN
    RAISE EXCEPTION 'Not enough available outlet stock.' USING ERRCODE='23514'; END IF;
  NEW.stock_before:=stock.quantity; NEW.stock_after:=stock.quantity-NEW.quantity;
  -- Stock is reserved/decremented only by the AFTER trigger, after the header exists.
  RETURN NEW;
END $$;


--
-- Name: require_complete_payout_audit_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_complete_payout_audit_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  request_count INTEGER;
  approval_count INTEGER;
  rejection_count INTEGER;
  release_count INTEGER;
  invalid_count INTEGER;
  current_action TEXT;
  current_action_count INTEGER;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW."status" IS NOT DISTINCT FROM OLD."status" THEN
    RETURN NEW;
  END IF;

  SELECT
    COUNT(audit."id") FILTER (
      WHERE audit."activity_type" = 'payout_requested'
    )::INTEGER,
    COUNT(audit."id") FILTER (
      WHERE audit."activity_type" = 'payout_approved'
    )::INTEGER,
    COUNT(audit."id") FILTER (
      WHERE audit."activity_type" = 'payout_rejected'
    )::INTEGER,
    COUNT(audit."id") FILTER (
      WHERE audit."activity_type" = 'payout_released'
    )::INTEGER,
    COUNT(audit."id") FILTER (
      WHERE audit."id" IS NOT NULL
        AND (
          audit."category" IS DISTINCT FROM 'payout'
          OR audit."status" IS DISTINCT FROM 'completed'
          OR CASE
            WHEN jsonb_typeof(audit."metadata"->'amount') = 'number'
              THEN (audit."metadata"->>'amount')::NUMERIC IS DISTINCT FROM NEW."amount"
            ELSE true
          END
          OR CASE audit."activity_type"
            WHEN 'payout_requested' THEN
              audit."user_id" IS DISTINCT FROM NEW."user_id"
              OR audit."user_role" IS DISTINCT FROM 'reseller'
              OR audit."metadata"->>'payment_method' IS DISTINCT FROM NEW."payment_method"
              OR (
                audit."metadata" ? 'reseller_id'
                AND audit."metadata"->>'reseller_id' IS DISTINCT FROM NEW."user_id"
              )
            WHEN 'payout_approved' THEN
              audit."user_id" IS DISTINCT FROM NEW."approved_by"
              OR audit."user_role" IS DISTINCT FROM 'admin'
              OR audit."metadata"->>'reseller_id' IS DISTINCT FROM NEW."user_id"
              OR audit."metadata"->>'transaction_number' IS DISTINCT FROM NEW."transaction_number"
            WHEN 'payout_rejected' THEN
              audit."user_id" IS DISTINCT FROM NEW."approved_by"
              OR audit."user_role" IS DISTINCT FROM 'admin'
              OR audit."metadata"->>'reseller_id' IS DISTINCT FROM NEW."user_id"
              OR audit."metadata"->>'notes' IS DISTINCT FROM NEW."notes"
            WHEN 'payout_released' THEN
              audit."user_id" IS DISTINCT FROM NEW."user_id"
              OR audit."user_role" IS DISTINCT FROM 'system'
              OR audit."metadata"->>'transaction_number' IS DISTINCT FROM NEW."transaction_number"
              OR (
                audit."metadata" ? 'reseller_id'
                AND audit."metadata"->>'reseller_id' IS DISTINCT FROM NEW."user_id"
              )
              OR (
                audit."metadata" ? 'actor_type'
                AND audit."metadata"->>'actor_type' IS DISTINCT FROM 'system'
              )
            ELSE true
          END
        )
    )::INTEGER
  INTO request_count, approval_count, rejection_count, release_count, invalid_count
  FROM "public"."audit_logs" audit
  WHERE audit."metadata"->>'payout_id' = NEW."id"
    AND audit."activity_type" = ANY (ARRAY[
      'payout_requested',
      'payout_approved',
      'payout_rejected',
      'payout_released'
    ]::TEXT[]);

  current_action := CASE NEW."status"
    WHEN 'pending'::"PayoutStatus" THEN 'payout_requested'
    WHEN 'approved'::"PayoutStatus" THEN 'payout_approved'
    WHEN 'rejected'::"PayoutStatus" THEN 'payout_rejected'
    WHEN 'released'::"PayoutStatus" THEN 'payout_released'
    ELSE NULL
  END;

  SELECT COUNT(*)::INTEGER
  INTO current_action_count
  FROM "public"."audit_logs" audit
  WHERE audit."metadata"->>'payout_id' = NEW."id"
    AND audit."activity_type" = current_action
    AND audit."created_at" = transaction_timestamp()
    AND CASE current_action
      WHEN 'payout_requested' THEN
        (audit."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS NOT DISTINCT FROM NEW."requested_at"
      WHEN 'payout_approved' THEN
        (audit."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS NOT DISTINCT FROM NEW."processed_at"
      WHEN 'payout_rejected' THEN
        (audit."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS NOT DISTINCT FROM NEW."processed_at"
      WHEN 'payout_released' THEN
        audit."created_at" IS NOT DISTINCT FROM NEW."released_at"
      ELSE false
    END;

  IF request_count <> 1 OR invalid_count <> 0 OR current_action_count <> 1 THEN
    RAISE EXCEPTION 'Payout transition lacks one fresh exact canonical audit event.' USING ERRCODE = '23514';
  END IF;

  IF NEW."status" = 'pending'::"PayoutStatus" THEN
    IF approval_count <> 0 OR rejection_count <> 0 OR release_count <> 0 THEN
      RAISE EXCEPTION 'Pending payout has a premature approval, rejection, or release audit event.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'approved'::"PayoutStatus" THEN
    IF approval_count <> 1 OR rejection_count <> 0 OR release_count <> 0 THEN
      RAISE EXCEPTION 'Approved payout lacks one exact approval audit chain.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'rejected'::"PayoutStatus" THEN
    IF approval_count <> 0 OR rejection_count <> 1 OR release_count <> 0 THEN
      RAISE EXCEPTION 'Rejected payout lacks one exact rejection audit chain.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'released'::"PayoutStatus" THEN
    IF approval_count <> 1 OR rejection_count <> 0 OR release_count <> 1 THEN
      RAISE EXCEPTION 'Released payout lacks one exact approval-and-release audit chain.' USING ERRCODE = '23514';
    END IF;
  ELSE
    RAISE EXCEPTION 'Payout has an unsupported audit lifecycle state.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: require_complete_payout_ledger_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_complete_payout_ledger_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  reservation_count INTEGER;
  reservation_amount DECIMAL(12,2);
  release_count INTEGER;
  release_amount DECIMAL(12,2);
  disbursement_count INTEGER;
  disbursement_amount DECIMAL(12,2);
  allocation_amount DECIMAL(12,2);
BEGIN
  SELECT
    COUNT(*) FILTER (WHERE "entry_type" = 'payout_reservation')::INTEGER,
    COALESCE(SUM("reserved_delta") FILTER (WHERE "entry_type" = 'payout_reservation'), 0),
    COUNT(*) FILTER (WHERE "entry_type" = 'payout_reservation_release')::INTEGER,
    COALESCE(SUM("reserved_delta") FILTER (WHERE "entry_type" = 'payout_reservation_release'), 0),
    COUNT(*) FILTER (WHERE "entry_type" = 'payout_disbursement')::INTEGER,
    COALESCE(SUM(-"balance_delta") FILTER (WHERE "entry_type" = 'payout_disbursement'), 0)
  INTO reservation_count, reservation_amount, release_count, release_amount,
       disbursement_count, disbursement_amount
  FROM "wallet_ledger_entries"
  WHERE "payout_id" = NEW."id";

  SELECT COALESCE(SUM(x."amount"), 0)
  INTO allocation_amount
  FROM (
    SELECT "amount" FROM "direct_referral_payout_consumptions" WHERE "payout_id" = NEW."id"
    UNION ALL
    SELECT "amount" FROM "binary_payout_consumptions" WHERE "payout_id" = NEW."id"
    UNION ALL
    SELECT "amount" FROM "product_binary_payout_consumptions" WHERE "payout_id" = NEW."id"
    UNION ALL
    SELECT "amount" FROM "rank_bonus_payout_consumptions" WHERE "payout_id" = NEW."id"
    UNION ALL
    SELECT "amount" FROM "unilevel_payout_consumptions" WHERE "payout_id" = NEW."id"
  ) x;

  IF reservation_count <> 1 OR reservation_amount <> NEW."amount" THEN
    RAISE EXCEPTION 'Payout does not have exactly one matching wallet reservation.' USING ERRCODE = '23514';
  END IF;

  IF NEW."status" = 'pending'::"PayoutStatus" THEN
    IF release_count <> 0 OR disbursement_count <> 0 OR allocation_amount <> 0 THEN
      RAISE EXCEPTION 'Pending payout has premature release, disbursement, or source allocation.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'rejected'::"PayoutStatus" THEN
    IF release_count <> 1 OR release_amount <> -NEW."amount"
       OR disbursement_count <> 0 OR allocation_amount <> 0 THEN
      RAISE EXCEPTION 'Rejected payout does not have one exact reservation release.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'approved'::"PayoutStatus" THEN
    IF release_count <> 0 OR disbursement_count <> 0 OR allocation_amount <> NEW."amount" THEN
      RAISE EXCEPTION 'Approved payout is not fully allocated and still reserved.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."status" = 'released'::"PayoutStatus" THEN
    IF release_count <> 0 OR disbursement_count <> 1
       OR disbursement_amount <> NEW."amount" OR allocation_amount <> NEW."amount" THEN
      RAISE EXCEPTION 'Released payout lacks one exact funded wallet disbursement.' USING ERRCODE = '23514';
    END IF;
  ELSE
    RAISE EXCEPTION 'Payout has an unsupported lifecycle state.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_direct_referral_commission_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_direct_referral_commission_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  event_count INTEGER;
BEGIN
  IF NEW."type" <> 'direct_referral'::"CommissionType"
     OR NEW."rule_version" <> 'registration-direct-v1' THEN
    RETURN NEW;
  END IF;

  SELECT COUNT(*)::INTEGER
  INTO event_count
  FROM "direct_referral_settlement_events" event
  WHERE event."source_event_id" = NEW."source_event_id"
    AND event."referred_user_id" = NEW."source_user_id"
    AND (
      (
        event."normal_commission_id" = NEW."id"
        AND event."sponsor_user_id" = NEW."user_id"
        AND event."payable_amount" = NEW."amount"
        AND NEW."is_pair_overflow" = false
        AND NEW."overflow_to" IS NULL
      )
      OR
      (
        event."retained_commission_id" = NEW."id"
        AND event."retained_amount" = NEW."amount"
        AND NEW."is_pair_overflow" = true
        AND NEW."overflow_to" = NEW."user_id"
      )
    );

  IF event_count IS DISTINCT FROM 1 THEN
    RAISE EXCEPTION 'Direct Referral commission has no exact immutable settlement event.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_direct_referral_settlement_for_registration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_direct_referral_settlement_for_registration() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  event_count INTEGER;
BEGIN
  IF NEW."payment_status" <> 'paid' THEN
    RETURN NEW;
  END IF;

  SELECT COUNT(*)::INTEGER
  INTO event_count
  FROM "direct_referral_settlement_events" event
  WHERE event."registration_financial_id" = NEW."id"
    AND event."source_event_id" = NEW."pin_id"
    AND event."referred_user_id" = NEW."reseller_id"
    AND event."source_allocation" = NEW."direct_referral_allocation";

  IF event_count IS DISTINCT FROM 1 THEN
    RAISE EXCEPTION 'Paid registration must commit with exactly one Direct Referral settlement event.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_fully_allocated_approved_payout(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_fully_allocated_approved_payout() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  allocated DECIMAL(12,2);
BEGIN
  IF NEW."status" IN ('approved', 'released')
     AND (
       TG_OP = 'INSERT'
       OR OLD."status" IS DISTINCT FROM NEW."status"
     ) THEN
    SELECT COALESCE(SUM(x."amount"), 0)
    INTO allocated
    FROM (
      SELECT c."amount"
      FROM "direct_referral_payout_consumptions" c
      WHERE c."payout_id" = NEW."id"
      UNION ALL
      SELECT c."amount"
      FROM "binary_payout_consumptions" c
      WHERE c."payout_id" = NEW."id"
      UNION ALL
      SELECT c."amount"
      FROM "product_binary_payout_consumptions" c
      WHERE c."payout_id" = NEW."id"
      UNION ALL
      SELECT c."amount" FROM "rank_bonus_payout_consumptions" c WHERE c."payout_id" = NEW."id"
    UNION ALL
    SELECT c."amount" FROM "unilevel_payout_consumptions" c WHERE c."payout_id" = NEW."id"
    ) x;

    IF allocated <> NEW."amount" THEN
      RAISE EXCEPTION USING
        ERRCODE = 'P0001',
        MESSAGE = 'Payout is not fully backed by payable commission lots.',
        DETAIL = format(
          'payout_id=%s required=%s allocated=%s',
          NEW."id",
          NEW."amount",
          allocated
        );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: require_fully_funded_product_binary_pool_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_fully_funded_product_binary_pool_order() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  eligible_units integer;
BEGIN
  SELECT e.eligible_units INTO STRICT eligible_units
  FROM public.product_binary_order_events e WHERE e.id = NEW.order_event_id;
  IF NEW.funded_units IS DISTINCT FROM eligible_units THEN
    RAISE EXCEPTION 'Product Binary settlement is waiting for reserve funding for all % eligible bottles (funded: %).',
      eligible_units, COALESCE(NEW.funded_units, 0) USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_internal_financial_ledger_write(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_internal_financial_ledger_write() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF pg_trigger_depth() <= 1 THEN
    RAISE EXCEPTION '% may only be changed by its protected source transaction.', TG_TABLE_NAME USING ERRCODE = '55000';
  END IF;
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_open_product_binary_pool_week(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_open_product_binary_pool_week() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE closed timestamptz;
BEGIN
  IF TG_OP <> 'INSERT' THEN RAISE EXCEPTION 'Product Binary pool sources are append-only.'; END IF;
  SELECT closed_at INTO STRICT closed FROM public.product_binary_pool_weeks
  WHERE week_start = NEW.week_start FOR UPDATE;
  IF closed IS NOT NULL OR EXISTS (
    SELECT 1 FROM public.product_binary_week_preparation WHERE week_start = NEW.week_start
  ) THEN RAISE EXCEPTION 'Cannot add sources to a frozen Product Binary pool week.'; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_pin_request_decision_actor(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_pin_request_decision_actor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."approved_at" IS NOT NULL AND (
       OLD."approved_at" IS DISTINCT FROM NEW."approved_at"
       OR OLD."approved_by_actor_id" IS DISTINCT FROM NEW."approved_by_actor_id"
     ) THEN
    RAISE EXCEPTION 'PIN request approval evidence is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."rejected_at" IS NOT NULL AND (
       OLD."rejected_at" IS DISTINCT FROM NEW."rejected_at"
       OR OLD."rejected_by_actor_id" IS DISTINCT FROM NEW."rejected_by_actor_id"
     ) THEN
    RAISE EXCEPTION 'PIN request rejection evidence is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."status" = 'pending' AND NEW."status" = 'approved'
     AND (NEW."approved_at" IS NULL OR NEW."approved_by_actor_id" IS NULL) THEN
    RAISE EXCEPTION 'PIN request approval requires the actual approving actor and time.' USING ERRCODE = '23514';
  END IF;
  IF OLD."status" = 'pending' AND NEW."status" = 'rejected'
     AND (NEW."rejected_at" IS NULL OR NEW."rejected_by_actor_id" IS NULL) THEN
    RAISE EXCEPTION 'PIN request rejection requires the actual rejecting actor and time.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: require_registration_binary_settlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_registration_binary_settlement() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  exact_settlement_count INTEGER;
BEGIN
  IF NEW."payment_status" = 'paid' AND NEW."binary_points_per_pair" > 0 THEN
    SELECT COUNT(*)::INTEGER
    INTO exact_settlement_count
    FROM "binary_settlement_events" event
    WHERE event."source_kind" = 'registration'
      AND event."source_event_id" = NEW."pin_id"
      AND event."source_user_id" = NEW."reseller_id"
      AND event."source_points" = NEW."binary_points_per_pair";

    IF exact_settlement_count IS DISTINCT FROM 1 THEN
      RAISE EXCEPTION 'Paid registration economics must commit with one exact Package Binary settlement.' USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: require_upgrade_binary_settlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_upgrade_binary_settlement() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  exact_settlement_count INTEGER;
BEGIN
  IF NEW."payment_status" = 'paid' AND NEW."binary_points_difference" > 0 THEN
    SELECT COUNT(*)::INTEGER
    INTO exact_settlement_count
    FROM "binary_settlement_events" event
    WHERE event."source_kind" = 'upgrade'
      AND event."source_event_id" = NEW."upgrade_pin_id"
      AND event."source_user_id" = NEW."reseller_id"
      AND event."source_points" = NEW."binary_points_difference";

    IF exact_settlement_count IS DISTINCT FROM 1 THEN
      RAISE EXCEPTION 'Paid upgrade economics must commit with one exact Package Binary settlement.' USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: require_valid_payout_audit_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_valid_payout_audit_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  payout_row RECORD;
BEGIN
  IF NOT (NEW."activity_type" = ANY (ARRAY[
    'payout_requested',
    'payout_approved',
    'payout_rejected',
    'payout_released'
  ]::TEXT[])) THEN
    RETURN NEW;
  END IF;

  SELECT
    payout."id",
    payout."user_id",
    payout."amount",
    payout."status",
    payout."payment_method",
    payout."transaction_number",
    payout."notes",
    payout."approved_by",
    payout."requested_at",
    payout."processed_at",
    payout."released_at"
  INTO payout_row
  FROM "public"."payouts" payout
  WHERE payout."id" = NEW."metadata"->>'payout_id';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Canonical payout audit event references no payout.' USING ERRCODE = '23503';
  END IF;

  IF NEW."created_at" IS DISTINCT FROM transaction_timestamp()
     OR NEW."category" IS DISTINCT FROM 'payout'
     OR NEW."status" IS DISTINCT FROM 'completed'
     OR jsonb_typeof(NEW."metadata"->'amount') IS DISTINCT FROM 'number' THEN
    RAISE EXCEPTION 'Canonical payout audit event is not fresh and complete.' USING ERRCODE = '23514';
  END IF;

  IF (NEW."metadata"->>'amount')::NUMERIC IS DISTINCT FROM payout_row."amount" THEN
    RAISE EXCEPTION 'Canonical payout audit amount does not match its payout.' USING ERRCODE = '23514';
  END IF;

  IF NEW."activity_type" = 'payout_requested' THEN
    IF payout_row."status" <> 'pending'::"PayoutStatus"
       OR NEW."user_id" IS DISTINCT FROM payout_row."user_id"
       OR NEW."user_role" IS DISTINCT FROM 'reseller'
       OR NEW."metadata"->>'reseller_id' IS DISTINCT FROM payout_row."user_id"
       OR NEW."metadata"->>'payment_method' IS DISTINCT FROM payout_row."payment_method"
       OR (NEW."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS DISTINCT FROM payout_row."requested_at" THEN
      RAISE EXCEPTION 'Payout-request audit evidence does not match the pending payout.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."activity_type" = 'payout_approved' THEN
    IF payout_row."status" <> 'approved'::"PayoutStatus"
       OR NEW."user_id" IS DISTINCT FROM payout_row."approved_by"
       OR NEW."user_role" IS DISTINCT FROM 'admin'
       OR NEW."metadata"->>'reseller_id' IS DISTINCT FROM payout_row."user_id"
       OR NEW."metadata"->>'transaction_number' IS DISTINCT FROM payout_row."transaction_number"
       OR (NEW."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS DISTINCT FROM payout_row."processed_at" THEN
      RAISE EXCEPTION 'Payout-approval audit evidence does not match the approved payout.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."activity_type" = 'payout_rejected' THEN
    IF payout_row."status" <> 'rejected'::"PayoutStatus"
       OR NEW."user_id" IS DISTINCT FROM payout_row."approved_by"
       OR NEW."user_role" IS DISTINCT FROM 'admin'
       OR NEW."metadata"->>'reseller_id' IS DISTINCT FROM payout_row."user_id"
       OR NEW."metadata"->>'notes' IS DISTINCT FROM payout_row."notes"
       OR (NEW."created_at" AT TIME ZONE 'UTC')::TIMESTAMP(3) IS DISTINCT FROM payout_row."processed_at" THEN
      RAISE EXCEPTION 'Payout-rejection audit evidence does not match the rejected payout.' USING ERRCODE = '23514';
    END IF;
  ELSIF NEW."activity_type" = 'payout_released' THEN
    IF payout_row."status" <> 'released'::"PayoutStatus"
       OR NEW."user_id" IS DISTINCT FROM payout_row."user_id"
       OR NEW."user_role" IS DISTINCT FROM 'system'
       OR NEW."metadata"->>'reseller_id' IS DISTINCT FROM payout_row."user_id"
       OR NEW."metadata"->>'transaction_number' IS DISTINCT FROM payout_row."transaction_number"
       OR NEW."metadata"->>'actor_type' IS DISTINCT FROM 'system'
       OR NEW."created_at" IS DISTINCT FROM payout_row."released_at" THEN
      RAISE EXCEPTION 'Payout-release audit evidence does not match the released payout.' USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: reserve_closed_product_binary_week_funding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reserve_closed_product_binary_week_funding() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE available numeric;
BEGIN
  IF OLD.closed_at IS NOT NULL OR NEW.closed_at IS NULL THEN RETURN NEW; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  SELECT COALESCE(SUM(GREATEST(0, remaining_amount - public.product_binary_inventory_earmark(order_id))), 0)
  INTO available FROM public.product_binary_funding_lots
  WHERE allocated_at <= CURRENT_TIMESTAMP AND remaining_amount > 0;
  IF NEW.pool_centavos::numeric > (available - public.product_binary_week_funding_held()) * 100 THEN
    RAISE EXCEPTION 'Product Binary weekly close held: pool budget is not fully funded.';
  END IF;
  INSERT INTO public.product_binary_week_funding (week_start, allocated_centavos, retained_centavos)
  VALUES (NEW.week_start, NEW.allocated_centavos, NEW.pool_centavos - NEW.allocated_centavos);
  RETURN NEW;
END;
$$;


--
-- Name: reserve_combined_order_replacement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reserve_combined_order_replacement() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE purchase orders%ROWTYPE; unit RECORD; remaining INT:=NEW.quantity;
BEGIN
 SELECT * INTO purchase FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF NOT FOUND OR purchase.status::text<>'pending' OR NOT reward_stock_actor_allowed(purchase.buyer_id,NEW.actor_id)
   OR NOT EXISTS(SELECT 1 FROM users WHERE id=purchase.buyer_id AND role::text IN ('city','provincial','regional'))
 THEN RAISE EXCEPTION 'Only pending purchase orders can include replacements.' USING ERRCODE='23514'; END IF;
 IF NOT can_supply_reward_stock(purchase.seller_id,purchase.buyer_id,NEW.kind)
 THEN RAISE EXCEPTION 'Replacement supplier is not authorized.' USING ERRCODE='23514'; END IF;
 PERFORM pg_advisory_xact_lock(hashtext('reward-stock-holder:'||purchase.buyer_id||':'||NEW.product_id));
 FOR unit IN SELECT u.id FROM reward_stock_units u WHERE u.holder_id=purchase.buyer_id AND u.product_id=NEW.product_id AND u.kind=NEW.kind
   AND u.settled_at IS NULL AND u.current_dispatch_id IS NULL
   AND NOT EXISTS(SELECT 1 FROM order_replacement_units a JOIN order_replacement_requests r ON r.id=a.request_id WHERE a.unit_id=u.id AND r.state='pending')
   ORDER BY u.created_at,u.id LIMIT NEW.quantity FOR UPDATE
 LOOP
   INSERT INTO order_replacement_units(request_id,unit_id) VALUES(NEW.id,unit.id); remaining:=remaining-1;
 END LOOP;
 IF remaining<>0 THEN RAISE EXCEPTION 'Replacement credits are unavailable or already reserved.' USING ERRCODE='23514'; END IF;
 UPDATE inventory SET reserved_quantity=reserved_quantity+NEW.quantity,updated_at=clock_timestamp()
   WHERE owner_id=purchase.seller_id AND product_id=NEW.product_id AND quantity-reserved_quantity>=NEW.quantity;
 IF NOT FOUND THEN RAISE EXCEPTION 'Replacement stock is currently unavailable. Reduce the quantity or contact the supplier.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: restore_product_binary_reserve_on_pos_return(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.restore_product_binary_reserve_on_pos_return() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  sale_order text;
  item record;
  stock record;
  needed integer;
  taken integer;
BEGIN
  IF NEW.status <> 'approved' OR OLD.status = 'approved' THEN RETURN NEW; END IF;
  SELECT order_id INTO sale_order FROM public.pos_transactions
  WHERE id = NEW.pos_transaction_id AND owner_id = NEW.owner_id AND transaction_type = 'non_member_sale';
  IF sale_order IS NULL THEN RETURN NEW; END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  IF EXISTS (SELECT 1 FROM public.product_binary_non_member_reserve_restorations
    WHERE adjustment_id = NEW.id) THEN RETURN NEW; END IF;

  FOR item IN
    SELECT i.product_id, SUM(CASE WHEN NEW.request_type = 'void' THEN i.quantity ELSE a.quantity END)::integer AS units
    FROM public.pos_transaction_items i
    LEFT JOIN public.pos_adjustment_items a ON a.pos_transaction_item_id = i.id AND a.adjustment_request_id = NEW.id
    WHERE i.pos_transaction_id = NEW.pos_transaction_id
      AND (NEW.request_type = 'void' OR a.disposition = 'resellable')
    GROUP BY i.product_id ORDER BY i.product_id
  LOOP
    needed := item.units;
    FOR stock IN
      SELECT r.source_order_item_id, r.units - COALESCE((
        SELECT SUM(s.units) FROM public.product_binary_non_member_reserve_restorations s
        WHERE s.order_id = r.order_id AND s.source_order_item_id = r.source_order_item_id
      ), 0) AS available
      FROM public.product_binary_non_member_reserve_releases r
      JOIN public.product_binary_inventory_reserves l USING (source_order_item_id)
      WHERE r.order_id = sale_order AND l.distributor_id = NEW.owner_id AND l.product_id = item.product_id
      ORDER BY l.created_at, l.source_order_item_id FOR UPDATE OF l
    LOOP
      taken := LEAST(needed, stock.available);
      CONTINUE WHEN taken <= 0;
      UPDATE public.product_binary_inventory_reserves SET remaining_units = remaining_units + taken
      WHERE source_order_item_id = stock.source_order_item_id;
      INSERT INTO public.product_binary_non_member_reserve_restorations
        (adjustment_id, order_id, source_order_item_id, units)
      VALUES (NEW.id, sale_order, stock.source_order_item_id, taken);
      needed := needed - taken;
      EXIT WHEN needed = 0;
    END LOOP;
  END LOOP;
  RETURN NEW;
END;
$$;


--
-- Name: retain_product_binary_non_member_reserve(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retain_product_binary_non_member_reserve() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  sale public.orders;
  item record;
  stock record;
  needed integer;
  taken integer;
BEGIN
  SELECT * INTO STRICT sale FROM public.orders WHERE id = NEW.id;
  IF sale.is_non_member_sale IS NOT TRUE OR sale.status <> 'delivered'
     OR sale.payment_status IS DISTINCT FROM 'paid' OR sale.financial_purpose <> 'commerce'
     OR NOT EXISTS (SELECT 1 FROM public.users WHERE id = sale.seller_id AND role = 'city') THEN
    RETURN NEW;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  INSERT INTO public.product_binary_non_member_reserve_processed VALUES (sale.id) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN
    RETURN NEW;
  END IF;

  FOR item IN
    SELECT product_id, SUM(quantity)::integer AS quantity
    FROM public.order_items WHERE order_id = sale.id GROUP BY product_id ORDER BY product_id
  LOOP
    needed := item.quantity;
    FOR stock IN
      SELECT source_order_item_id, remaining_units FROM public.product_binary_inventory_reserves
      WHERE distributor_id = sale.seller_id AND product_id = item.product_id AND remaining_units > 0
      ORDER BY created_at, source_order_item_id FOR UPDATE
    LOOP
      taken := LEAST(needed, stock.remaining_units);
      UPDATE public.product_binary_inventory_reserves SET remaining_units = remaining_units - taken
      WHERE source_order_item_id = stock.source_order_item_id;
      INSERT INTO public.product_binary_non_member_reserve_releases (order_id, source_order_item_id, units)
      VALUES (sale.id, stock.source_order_item_id, taken);
      needed := needed - taken;
      EXIT WHEN needed = 0;
    END LOOP;
  END LOOP;
  RETURN NEW;
END;
$$;


--
-- Name: retain_product_binary_package_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retain_product_binary_package_stock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  stock record;
  needed integer;
  taken integer;
  released integer := 0;
BEGIN
  IF NEW.event_type NOT IN ('registration_package_release', 'upgrade_package_release')
     OR NEW.reference_id IS NULL OR NEW.product_id IS NULL OR NEW.quantity_delta >= 0
     OR NOT EXISTS (SELECT 1 FROM public.users WHERE id = NEW.owner_id AND role = 'city') THEN
    RETURN NEW;
  END IF;

  IF (
    (NEW.event_type = 'registration_package_release' AND NEW.reference_type = 'registration_pin'
      AND EXISTS (SELECT 1 FROM public.pins p JOIN public.pin_registration_product_snapshots i ON i.pin_id=p.id
        JOIN public.registration_financials f ON f.pin_id=p.id AND f.city_dist_id=NEW.owner_id
        WHERE p.id=NEW.reference_id AND p.city_dist_id=NEW.owner_id AND i.product_id=NEW.product_id AND i.quantity=-NEW.quantity_delta))
    OR (NEW.event_type = 'upgrade_package_release' AND NEW.reference_type = 'upgrade_pin'
      AND EXISTS (SELECT 1 FROM public.pins p JOIN public.pin_upgrade_product_snapshots i ON i.pin_id=p.id
        JOIN public.upgrade_financials f ON f.upgrade_pin_id=p.id AND f.city_dist_id=NEW.owner_id
        WHERE p.id=NEW.reference_id AND p.city_dist_id=NEW.owner_id AND i.product_id=NEW.product_id AND i.quantity=-NEW.quantity_delta))
    OR (NEW.event_type = 'registration_package_release' AND NEW.reference_type = 'pos_registration_intake'
      AND EXISTS (SELECT 1 FROM public.pos_registration_intakes i WHERE i.id::text=NEW.reference_id
        AND i.owner_id=NEW.owner_id AND i.released_at IS NOT NULL))
  ) IS NOT TRUE THEN RETURN NEW; END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  INSERT INTO public.product_binary_package_reserve_releases (reference_type, reference_id, product_id)
  VALUES (NEW.reference_type, NEW.reference_id, NEW.product_id) ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RETURN NEW; END IF;

  needed := -NEW.quantity_delta;
  FOR stock IN
    SELECT source_order_item_id, remaining_units FROM public.product_binary_inventory_reserves
    WHERE distributor_id=NEW.owner_id AND product_id=NEW.product_id AND remaining_units>0
    ORDER BY created_at, source_order_item_id FOR UPDATE
  LOOP
    taken := LEAST(needed, stock.remaining_units);
    UPDATE public.product_binary_inventory_reserves SET remaining_units=remaining_units-taken
    WHERE source_order_item_id=stock.source_order_item_id;
    released := released + taken;
    needed := needed - taken;
    EXIT WHEN needed = 0;
  END LOOP;

  UPDATE public.product_binary_package_reserve_releases SET released_units=released
  WHERE reference_type=NEW.reference_type AND reference_id=NEW.reference_id AND product_id=NEW.product_id;
  RETURN NEW;
END;
$$;


--
-- Name: retain_product_binary_replacement_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retain_product_binary_replacement_stock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  stock record;
  needed integer;
  taken integer;
BEGIN
  IF pg_trigger_depth() < 2 OR NEW.event_type <> 'reward_replacement_dispatch' OR NEW.reference_type <> 'reward_stock_dispatch'
     OR NEW.quantity_delta >= 0 THEN RETURN NEW; END IF;
  SELECT d.quantity INTO needed FROM public.reward_stock_dispatches d
  JOIN public.users u ON u.id = d.supplier_id AND u.role = 'city'
  WHERE d.id::text = NEW.reference_id AND d.supplier_id = NEW.owner_id
    AND d.product_id = NEW.product_id AND d.quantity = -NEW.quantity_delta;
  IF NOT FOUND THEN RETURN NEW; END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  INSERT INTO public.product_binary_replacement_reserve_processed VALUES (NEW.reference_id::uuid)
  ON CONFLICT DO NOTHING;
  IF NOT FOUND THEN RETURN NEW; END IF;

  FOR stock IN
    SELECT source_order_item_id, remaining_units FROM public.product_binary_inventory_reserves
    WHERE distributor_id = NEW.owner_id AND product_id = NEW.product_id AND remaining_units > 0
    ORDER BY created_at, source_order_item_id FOR UPDATE
  LOOP
    taken := LEAST(needed, stock.remaining_units);
    UPDATE public.product_binary_inventory_reserves SET remaining_units = remaining_units - taken
    WHERE source_order_item_id = stock.source_order_item_id;
    INSERT INTO public.product_binary_replacement_reserve_releases (dispatch_id, source_order_item_id, units)
    VALUES (NEW.reference_id::uuid, stock.source_order_item_id, taken);
    needed := needed - taken;
    EXIT WHEN needed = 0;
  END LOOP;
  RETURN NEW;
END;
$$;


--
-- Name: retry_deferred_product_binary_credit(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retry_deferred_product_binary_credit(target_week date, member_id text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $_$
BEGIN
  PERFORM 1 FROM public.product_binary_pool_weeks w
  WHERE w.week_start = $1 AND w.released_at IS NOT NULL FOR UPDATE;
  IF NOT FOUND THEN RETURN false; END IF;

  PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
  PERFORM 1 FROM public.users u JOIN public.wallets w ON w.user_id = u.id
  WHERE u.id = $2 AND u.role = 'reseller' AND u.status = 'active' FOR SHARE OF u;
  IF NOT FOUND THEN RETURN false; END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.product_binary_pool_allocations a
    WHERE a.week_start = $1 AND a.recipient_user_id = $2
      AND a.amount_centavos > 0 AND a.commission_id IS NULL AND a.retained_at IS NULL
  ) THEN RETURN false; END IF;

  RETURN public.credit_product_binary_pool_allocation($1, $2);
END;
$_$;


--
-- Name: revalidate_package_upgrade_paths(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.revalidate_package_upgrade_paths() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  invalid_count INTEGER;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('package-upgrade-funding-configuration'));

  SELECT COUNT(*)::INTEGER
  INTO invalid_count
  FROM "package_upgrade_paths" path
  JOIN "packages" source ON source."id" = path."from_package_id"
  JOIN "packages" target ON target."id" = path."to_package_id"
  WHERE path."is_active"
    AND (path."from_package_id" = NEW."id" OR path."to_package_id" = NEW."id")
    AND (
      NOT source."is_active"
      OR NOT target."is_active"
      OR source."price" >= target."price"
      OR source."pairing_bonus_value" >= target."pairing_bonus_value"
      OR path."pin_price" <
         GREATEST(target."direct_referral_bonus" - source."direct_referral_bonus", 0)
         + GREATEST(target."pairing_bonus_value" - source."pairing_bonus_value", 0) * 0.50
    );

  IF invalid_count > 0 THEN
    RAISE EXCEPTION 'Package change would invalidate an active lower-to-higher funded upgrade path.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: reward_stock_actor_allowed(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reward_stock_actor_allowed(owner_id text, actor_id text) RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS(SELECT 1 FROM users o JOIN users a ON a.id=actor_id
    WHERE o.id=owner_id AND o.status::text='active' AND a.status::text='active'
      AND o.role::text IN ('admin','regional','provincial','city')
      AND (o.id=a.id OR EXISTS(SELECT 1 FROM staff_profiles sp WHERE sp.user_id=a.id AND sp.owner_id=o.id AND sp.is_active
        AND a.role::text='staff' AND sp.permissions::jsonb ? (CASE WHEN o.role::text='admin' THEN 'inventory:manage' ELSE 'inventory' END))));
$$;


--
-- Name: seal_closed_product_binary_allocation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_closed_product_binary_allocation() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  previous_week date;
  next_week date;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF ROW(NEW.week_start, NEW.recipient_user_id, NEW.payable_pairs, NEW.amount_centavos)
       IS NOT DISTINCT FROM ROW(OLD.week_start, OLD.recipient_user_id, OLD.payable_pairs, OLD.amount_centavos) THEN
      RETURN NEW;
    END IF;
  END IF;
  IF TG_OP <> 'INSERT' THEN previous_week := OLD.week_start; END IF;
  IF TG_OP <> 'DELETE' THEN next_week := NEW.week_start; END IF;
  IF EXISTS (
    SELECT 1 FROM public.product_binary_pool_weeks w
    WHERE w.closed_at IS NOT NULL AND w.week_start IN (previous_week, next_week)
  ) THEN
    RAISE EXCEPTION 'Closed Product Binary allocations cannot be added, removed or recalculated.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_inventory_movement_financial_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_inventory_movement_financial_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Inventory-movement evidence is append-only.' USING ERRCODE = '55000';
  END IF;
  IF ROW(NEW."transfer_id", NEW."admin_id", NEW."recipient_id", NEW."product_id", NEW."order_id",
         NEW."quantity", NEW."unit_cost", NEW."unit_price", NEW."reference_value", NEW."sale_value",
         NEW."admin_profit", NEW."is_sale", NEW."admin_stock_before", NEW."admin_stock_after",
         NEW."recipient_stock_before", NEW."created_at")
     IS DISTINCT FROM
     ROW(OLD."transfer_id", OLD."admin_id", OLD."recipient_id", OLD."product_id", OLD."order_id",
         OLD."quantity", OLD."unit_cost", OLD."unit_price", OLD."reference_value", OLD."sale_value",
         OLD."admin_profit", OLD."is_sale", OLD."admin_stock_before", OLD."admin_stock_after",
         OLD."recipient_stock_before", OLD."created_at") THEN
    RAISE EXCEPTION 'Inventory-movement financial identity is immutable.' USING ERRCODE = '55000';
  END IF;
  IF OLD."received_at" IS NOT NULL AND ROW(
       NEW."recipient_stock_after", NEW."accepted_quantity", NEW."damaged_quantity",
       NEW."missing_quantity", NEW."receiving_notes", NEW."received_at"
     ) IS DISTINCT FROM ROW(
       OLD."recipient_stock_after", OLD."accepted_quantity", OLD."damaged_quantity",
       OLD."missing_quantity", OLD."receiving_notes", OLD."received_at"
     ) THEN
    RAISE EXCEPTION 'Inventory receiving evidence is immutable after receipt.' USING ERRCODE = '55000';
  END IF;
  IF OLD."received_at" IS NULL THEN
    IF NEW."received_at" IS NULL AND NEW."recipient_stock_after" IS DISTINCT FROM OLD."recipient_stock_after" THEN
      RAISE EXCEPTION 'Recipient stock cannot change before receipt is sealed.' USING ERRCODE = '23514';
    END IF;
    IF NEW."received_at" IS NOT NULL AND (
         NEW."accepted_quantity" IS NULL
         OR NEW."damaged_quantity" IS NULL
         OR NEW."missing_quantity" IS NULL
         OR NEW."accepted_quantity" < 0
         OR NEW."damaged_quantity" < 0
         OR NEW."missing_quantity" < 0
         OR NEW."accepted_quantity" + NEW."damaged_quantity" + NEW."missing_quantity" <> NEW."quantity"
         OR NEW."recipient_stock_after" < NEW."accepted_quantity"
       ) THEN
      RAISE EXCEPTION 'Receiving quantities and recipient stock evidence are inconsistent.' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_product_binary_funding_lot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_product_binary_funding_lot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE'
     OR NEW."id" IS DISTINCT FROM OLD."id"
     OR NEW."inventory_movement_id" IS DISTINCT FROM OLD."inventory_movement_id"
     OR NEW."order_id" IS DISTINCT FROM OLD."order_id"
     OR NEW."original_amount" IS DISTINCT FROM OLD."original_amount"
     OR NEW."snapshot_source" IS DISTINCT FROM OLD."snapshot_source"
     OR NEW."payment_status_snapshot" IS DISTINCT FROM OLD."payment_status_snapshot"
     OR NEW."paid_at_snapshot" IS DISTINCT FROM OLD."paid_at_snapshot"
     OR NEW."delivered_at_snapshot" IS DISTINCT FROM OLD."delivered_at_snapshot"
     OR NEW."eligible_units_snapshot" IS DISTINCT FROM OLD."eligible_units_snapshot"
     OR NEW."total_pu_snapshot" IS DISTINCT FROM OLD."total_pu_snapshot"
     OR NEW."gross_margin_snapshot" IS DISTINCT FROM OLD."gross_margin_snapshot"
     OR NEW."snapshot_version" IS DISTINCT FROM OLD."snapshot_version"
     OR NEW."reconciliation_status" IS DISTINCT FROM OLD."reconciliation_status"
     OR NEW."allocated_at" IS DISTINCT FROM OLD."allocated_at"
     OR NEW."created_at" IS DISTINCT FROM OLD."created_at"
     OR NEW."remaining_amount" < 0
     OR NEW."remaining_amount" > OLD."remaining_amount" THEN
    RAISE EXCEPTION 'Product Binary funding provenance is immutable and reserve balance may only decrease.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_product_binary_job_snapshots(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_product_binary_job_snapshots() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."status" = 'completed' THEN
    RAISE EXCEPTION 'Completed Product Binary job is immutable.' USING ERRCODE = '23514';
  END IF;
  IF OLD."qualified_at" IS NOT NULL
     AND ROW(NEW."order_id", NEW."buyer_user_id", NEW."payment_status_snapshot", NEW."paid_at_snapshot",
             NEW."delivered_at_snapshot", NEW."eligible_units_snapshot", NEW."total_pu_snapshot",
             NEW."gross_margin_snapshot", NEW."snapshot_version", NEW."qualified_at")
         IS DISTINCT FROM
         ROW(OLD."order_id", OLD."buyer_user_id", OLD."payment_status_snapshot", OLD."paid_at_snapshot",
             OLD."delivered_at_snapshot", OLD."eligible_units_snapshot", OLD."total_pu_snapshot",
             OLD."gross_margin_snapshot", OLD."snapshot_version", OLD."qualified_at") THEN
    RAISE EXCEPTION 'Qualified Product Binary job snapshots are immutable.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_product_binary_order_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_product_binary_order_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  has_lineage BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM "product_binary_settlement_jobs" job WHERE job."order_id" = OLD."id"
    UNION ALL SELECT 1 FROM "product_binary_funding_lots" lot WHERE lot."order_id" = OLD."id"
    UNION ALL SELECT 1 FROM "product_binary_order_events" event WHERE event."order_id" = OLD."id"
  ) INTO has_lineage;

  IF (OLD."status"::text = 'delivered' OR OLD."payment_status" = 'paid' OR has_lineage)
     AND ROW(NEW."buyer_id", NEW."seller_id", NEW."order_type", NEW."total_amount",
             NEW."financial_purpose", NEW."is_non_member_sale")
         IS DISTINCT FROM
         ROW(OLD."buyer_id", OLD."seller_id", OLD."order_type", OLD."total_amount",
             OLD."financial_purpose", OLD."is_non_member_sale") THEN
    RAISE EXCEPTION 'Qualified order financial identity is immutable.' USING ERRCODE = '23514';
  END IF;
  IF OLD."payment_status" = 'paid' AND NEW."payment_status" IS DISTINCT FROM 'paid' THEN
    RAISE EXCEPTION 'A paid Product Binary source order cannot return to unpaid.' USING ERRCODE = '23514';
  END IF;
  IF OLD."payment_status" = 'paid' AND NEW."paid_at" IS DISTINCT FROM OLD."paid_at" THEN
    RAISE EXCEPTION 'Paid-at evidence is immutable.' USING ERRCODE = '23514';
  END IF;
  IF OLD."status"::text = 'delivered' AND NEW."status"::text IS DISTINCT FROM 'delivered' THEN
    RAISE EXCEPTION 'A delivered Product Binary source order cannot regress.' USING ERRCODE = '23514';
  END IF;
  IF OLD."status"::text = 'delivered' AND NEW."delivered_at" IS DISTINCT FROM OLD."delivered_at" THEN
    RAISE EXCEPTION 'Delivered-at evidence is immutable.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_product_binary_order_item(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_product_binary_order_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Order-item financial identity is immutable; cancel and recreate the order.' USING ERRCODE = '23514';
  END IF;
  IF ROW(NEW."order_id", NEW."product_id", NEW."quantity", NEW."unit_price",
         NEW."unit_acquisition_cost", NEW."subtotal", NEW."binary_eligible_snapshot",
         NEW."pu_value_snapshot", NEW."company_unit_cost_snapshot",
         NEW."company_unit_margin_snapshot", NEW."snapshot_source", NEW."snapshotted_at")
     IS DISTINCT FROM
     ROW(OLD."order_id", OLD."product_id", OLD."quantity", OLD."unit_price",
         OLD."unit_acquisition_cost", OLD."subtotal", OLD."binary_eligible_snapshot",
         OLD."pu_value_snapshot", OLD."company_unit_cost_snapshot",
         OLD."company_unit_margin_snapshot", OLD."snapshot_source", OLD."snapshotted_at") THEN
    RAISE EXCEPTION 'Order-item financial identity is immutable; cancel and recreate the order.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: seal_product_binary_source_rows(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seal_product_binary_source_rows() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Product Binary source snapshots and order-event lineage are immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: seed_reward_stock_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seed_reward_stock_unit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO reward_stock_units(claim_allocation_id,origin_outlet_id,product_id,kind,holder_id)
  SELECT NEW.id,c.owner_id,c.product_id,CASE WHEN dp.dist_level::text='branch' THEN 'internal_replenishment' ELSE 'distributor_replacement' END,c.owner_id
    FROM product_reward_claims c JOIN distributor_profiles dp ON dp.user_id=c.owner_id WHERE c.id=NEW.claim_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Reward release has no outlet ownership classification.'; END IF;
  RETURN NEW;
END $$;


--
-- Name: settle_combined_order_replacements(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.settle_combined_order_replacements() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE request RECORD; dispatch_actor TEXT;
BEGIN
 IF EXISTS(SELECT 1 FROM order_replacement_requests WHERE order_id=NEW.id) AND
   (NEW.seller_id IS DISTINCT FROM OLD.seller_id OR NEW.buyer_id IS DISTINCT FROM OLD.buyer_id)
 THEN RAISE EXCEPTION 'Combined order participants cannot change.'; END IF;
 IF NEW.status IS NOT DISTINCT FROM OLD.status OR NEW.status::text NOT IN ('delivered','cancelled') THEN RETURN NEW; END IF;
 FOR request IN SELECT * FROM order_replacement_requests WHERE order_id=NEW.id AND state='pending' ORDER BY product_id,kind FOR UPDATE
 LOOP
   PERFORM pg_advisory_xact_lock(hashtext('reward-stock-holder:'||NEW.buyer_id||':'||request.product_id));
   UPDATE inventory SET reserved_quantity=reserved_quantity-request.quantity,updated_at=clock_timestamp()
     WHERE owner_id=NEW.seller_id AND product_id=request.product_id AND reserved_quantity>=request.quantity;
   IF NOT FOUND THEN RAISE EXCEPTION 'Combined replacement reservation is missing.'; END IF;
   IF NEW.status::text='delivered' THEN
     dispatch_actor:=COALESCE(NULLIF(current_setting('hiroma.order_actor',true),''),NEW.seller_id);
     INSERT INTO reward_stock_dispatches(id,client_request_id,supplier_id,recipient_id,actor_id,product_id,kind,quantity)
       VALUES(request.id,request.id,NEW.seller_id,NEW.buyer_id,dispatch_actor,request.product_id,request.kind,request.quantity);
     UPDATE order_replacement_requests SET state='dispatched' WHERE id=request.id;
   ELSE
     UPDATE order_replacement_requests SET state='cancelled' WHERE id=request.id;
   END IF;
 END LOOP;
 RETURN NEW;
END $$;


--
-- Name: settle_unilevel_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.settle_unilevel_order() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  source_event public.product_binary_order_events;
  funding numeric(12,2);
  share numeric(12,2);
  total_credit numeric(12,2) := 0;
  total_retained numeric(12,2) := 0;
  slot_count integer;
  allocation record;
  recipient text;
  reason text;
  lot_id uuid;
  credit_id text;
BEGIN
  IF NEW.status <> 'completed' OR NEW.qualification_status <> 'qualified_paid_delivery' THEN RETURN NEW; END IF;
  SELECT * INTO source_event FROM public.product_binary_order_events WHERE settlement_job_id=NEW.id;
  IF NOT FOUND OR EXISTS(SELECT 1 FROM public.unilevel_order_settlements WHERE order_event_id=source_event.id) THEN RETURN NEW; END IF;
  SELECT COUNT(*) INTO slot_count FROM public.unilevel_order_allocations WHERE order_event_id=source_event.id;
  IF slot_count=0 THEN RETURN NEW; END IF;
  SELECT COALESCE(funded_amount,0) INTO funding FROM public.unilevel_order_funding WHERE order_event_id=source_event.id;
  funding := COALESCE(funding,0);
  share := LEAST(source_event.eligible_units::numeric,trunc(funding/slot_count,2));
  FOR recipient IN SELECT DISTINCT user_id FROM public.unilevel_order_allocations
    WHERE order_event_id=source_event.id AND user_id IS NOT NULL ORDER BY user_id
  LOOP
    PERFORM pg_advisory_xact_lock(hashtext('financial-user:'||recipient));
  END LOOP;
  FOR allocation IN SELECT * FROM public.unilevel_order_allocations
    WHERE order_event_id=source_event.id ORDER BY level
  LOOP
    IF share=0 THEN CONTINUE; END IF;
    reason := allocation.disposition;
    IF reason='qualified' THEN
      PERFORM 1 FROM public.users member JOIN public.reseller_profiles profile ON profile.user_id=member.id
      WHERE member.id=allocation.user_id AND member.role='reseller' AND member.status='active' AND profile.is_active
      FOR SHARE OF member,profile;
      IF NOT FOUND THEN reason := 'recipient_unavailable_at_credit'; END IF;
    END IF;
    IF reason='qualified' THEN
      lot_id := gen_random_uuid();
      credit_id := gen_random_uuid()::text;
      INSERT INTO public.wallets(id,user_id,updated_at) VALUES(gen_random_uuid()::text,allocation.user_id,CURRENT_TIMESTAMP)
      ON CONFLICT(user_id) DO NOTHING;
      INSERT INTO public.unilevel_payable_lots(id,order_event_id,level,user_id,original_amount,remaining_amount,commission_id)
      VALUES(lot_id,source_event.id,allocation.level,allocation.user_id,share,share,credit_id);
      INSERT INTO public.commissions(id,event_key,source_event_kind,source_event_id,rule_version,user_id,type,amount,source_user_id)
      VALUES(credit_id,'unilevel:'||source_event.id||':level:'||allocation.level,'unilevel_order',lot_id::text,
        'unilevel-v1',allocation.user_id,'multilevel',share,source_event.buyer_user_id);
      total_credit := total_credit+share;
    ELSE
      INSERT INTO public.unilevel_retention_entries(order_event_id,level,user_id,reason,amount)
      VALUES(source_event.id,allocation.level,allocation.user_id,reason,share);
      total_retained := total_retained+share;
    END IF;
  END LOOP;
  IF funding>total_credit+total_retained THEN
    INSERT INTO public.unilevel_retention_entries(order_event_id,level,reason,amount)
    VALUES(source_event.id,0,'rounding_or_excess_funding',funding-total_credit-total_retained);
    total_retained := funding-total_credit;
  END IF;
  INSERT INTO public.unilevel_order_settlements(order_event_id,funded_amount,credited_amount,retained_amount)
  VALUES(source_event.id,funding,total_credit,total_retained);
  RETURN NEW;
END;
$$;


--
-- Name: snapshot_order_geography(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_order_geography() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  buyer_row "users"%ROWTYPE;
  seller_profile "distributor_profiles"%ROWTYPE;
BEGIN
  SELECT * INTO buyer_row FROM "users" WHERE "id" = NEW."buyer_id";
  SELECT * INTO seller_profile FROM "distributor_profiles" WHERE "user_id" = NEW."seller_id";

  IF buyer_row."role" = 'reseller' THEN
    NEW."market_region_code" := COALESCE(NEW."market_region_code", buyer_row."region_code");
    NEW."market_region_name" := COALESCE(NEW."market_region_name", buyer_row."region_name");
    NEW."market_province_code" := COALESCE(NEW."market_province_code", buyer_row."province_code");
    NEW."market_province_name" := COALESCE(NEW."market_province_name", buyer_row."province_name");
    NEW."market_city_muni_code" := COALESCE(NEW."market_city_muni_code", buyer_row."city_muni_code");
    NEW."market_city_muni_name" := COALESCE(NEW."market_city_muni_name", buyer_row."city_muni_name");
    NEW."market_zip_code" := COALESCE(NEW."market_zip_code", buyer_row."zip_code");
    NEW."market_location_source" := COALESCE(NEW."market_location_source", 'registered_address');
  END IF;

  IF seller_profile."id" IS NOT NULL THEN
    NEW."fulfillment_region_code" := COALESCE(NEW."fulfillment_region_code", seller_profile."region_code");
    NEW."fulfillment_region_name" := COALESCE(NEW."fulfillment_region_name", seller_profile."region_name");
    NEW."fulfillment_province_code" := COALESCE(NEW."fulfillment_province_code", seller_profile."province_code");
    NEW."fulfillment_province_name" := COALESCE(NEW."fulfillment_province_name", seller_profile."province_name");
    NEW."fulfillment_city_muni_code" := COALESCE(NEW."fulfillment_city_muni_code", seller_profile."city_muni_code");
    NEW."fulfillment_city_muni_name" := COALESCE(NEW."fulfillment_city_muni_name", seller_profile."city_muni_name");
    NEW."fulfillment_outlet_name" := COALESCE(NEW."fulfillment_outlet_name", seller_profile."fulfillment_outlet_name");
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: snapshot_product_binary_order_item(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_product_binary_order_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  product_row RECORD;
BEGIN
  SELECT product."binary_eligible", product."pu_value", product."cost_price"
  INTO product_row
  FROM "products" product
  WHERE product."id" = NEW."product_id"
  FOR SHARE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order item product does not exist.' USING ERRCODE = '23503';
  END IF;
  IF NEW."quantity" <= 0 OR NEW."unit_price" < 0
     OR NEW."subtotal" IS DISTINCT FROM ROUND(NEW."unit_price" * NEW."quantity", 2) THEN
    RAISE EXCEPTION 'Order item quantity, price, and subtotal are inconsistent.' USING ERRCODE = '23514';
  END IF;

  NEW."binary_eligible_snapshot" := COALESCE(product_row."binary_eligible", false);
  NEW."pu_value_snapshot" := GREATEST(0, COALESCE(product_row."pu_value", 0));
  NEW."company_unit_cost_snapshot" := product_row."cost_price";
  NEW."company_unit_margin_snapshot" := GREATEST(0, NEW."unit_price" - product_row."cost_price");
  NEW."snapshot_source" := 'product-binary-order-v1';
  NEW."snapshotted_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: snapshot_unilevel_order_allocations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_unilevel_order_allocations() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  -- Pre-migration orders require reconciliation. They do not gain retroactive rewards.
  INSERT INTO public.unilevel_order_allocations(order_event_id,level,user_id,bottle_count,disposition)
  SELECT NEW.id,recipient.level,recipient.user_id,NEW.eligible_units,recipient.disposition
  FROM public.unilevel_qualified_recipients recipient
  WHERE recipient.settlement_job_id=NEW.settlement_job_id AND NEW.eligible_units>0;
  RETURN NEW;
END;
$$;


--
-- Name: stamp_audit_log_evidence_time(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stamp_audit_log_evidence_time() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."created_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: stamp_deactivation_liability_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stamp_deactivation_liability_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."liability_liquidation_version" := 'deactivation-liability-v1';
  NEW."created_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: stamp_product_binary_order_times(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stamp_product_binary_order_times() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."payment_status" = 'paid'
     AND (TG_OP = 'INSERT' OR OLD."payment_status" IS DISTINCT FROM 'paid') THEN
    NEW."paid_at" := transaction_timestamp();
  END IF;
  IF NEW."status"::text = 'delivered'
     AND (TG_OP = 'INSERT' OR OLD."status"::text IS DISTINCT FROM 'delivered') THEN
    NEW."delivered_at" := transaction_timestamp();
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: sync_open_product_binary_week_rate(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_open_product_binary_week_rate() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  current_week date := date_trunc('week', clock_timestamp() AT TIME ZONE 'Asia/Manila')::date;
BEGIN
  UPDATE public.product_binary_pool_weeks w
  SET max_rate_centavos = (NEW.value::numeric * 100)::integer
  WHERE w.week_start = current_week AND w.closed_at IS NULL
    AND w.max_rate_centavos IS DISTINCT FROM (NEW.value::numeric * 100)::integer
    AND NOT EXISTS (
      SELECT 1 FROM public.product_binary_week_preparation p WHERE p.week_start = w.week_start
    );
  RETURN NEW;
END;
$$;


--
-- Name: track_product_binary_account_hold(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.track_product_binary_account_hold() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
BEGIN
  IF OLD.status = 'suspended' THEN
    RAISE EXCEPTION 'Suspended reseller accounts are permanently disabled.' USING ERRCODE = '23514';
  END IF;
  IF NEW.status = 'inactive' THEN
    INSERT INTO public.product_binary_account_holds(user_id, inactive_since)
    VALUES (OLD.id, clock_timestamp())
    ON CONFLICT (user_id) DO UPDATE SET inactive_since = EXCLUDED.inactive_since;
  ELSIF NEW.status = 'active' AND OLD.status = 'inactive' THEN
    UPDATE public.product_binary_account_holds
    SET forfeited_before = CASE
      WHEN clock_timestamp() >= inactive_since + interval '72 hours'
      THEN GREATEST(forfeited_before, inactive_since + interval '72 hours')
      ELSE forfeited_before END,
      inactive_since = NULL
    WHERE user_id = OLD.id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: unilevel_level_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.unilevel_level_count() RETURNS integer
    LANGUAGE sql STABLE
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
 SELECT COALESCE((SELECT value::integer FROM public.system_settings WHERE key='unilevel_levels'),5)
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: upgrade_pin_snapshot_is_exact(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upgrade_pin_snapshot_is_exact(target_pin_id text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
  totals RECORD;
BEGIN
  SELECT * INTO issued
  FROM "pins"
  WHERE "id" = target_pin_id
  FOR SHARE;

  IF NOT FOUND OR issued."pin_type" <> 'upgrade' THEN
    RETURN false;
  END IF;

  SELECT
    COUNT(*)::INTEGER AS product_count,
    COUNT(*) FILTER (
      WHERE "quantity" <= 0
         OR "srp_snapshot" IS NULL
         OR "srp_snapshot" <= 0
         OR "reseller_price_snapshot" IS NULL
         OR "reseller_price_snapshot" <= 0
         OR "unit_acquisition_cost_snapshot" IS NULL
         OR "unit_acquisition_cost_snapshot" <= 0
    )::INTEGER AS invalid_product_count,
    COALESCE(SUM("quantity"), 0)::INTEGER AS units,
    COALESCE(SUM("srp_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS customer_payment,
    COALESCE(SUM("reseller_price_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS reseller_value,
    COALESCE(
      SUM("unit_acquisition_cost_snapshot" * "quantity"),
      0
    )::DECIMAL(12,2) AS acquisition_cost
  INTO totals
  FROM "pin_upgrade_product_snapshots"
  WHERE "pin_id" = issued."id";

  RETURN COALESCE(
    issued."upgrade_from_package_id" IS NOT NULL
    AND issued."upgrade_from_package_id" <> issued."package_id"
    AND issued."pin_allocation_snapshot" IS NOT NULL
    AND issued."pin_allocation_snapshot" > 0
    AND issued."upgrade_customer_payment_snapshot" IS NOT NULL
    AND issued."upgrade_customer_payment_snapshot" > 0
    AND issued."upgrade_reseller_value_snapshot" IS NOT NULL
    AND issued."upgrade_reseller_value_snapshot" > 0
    AND issued."upgrade_acquisition_cost_snapshot" IS NOT NULL
    AND issued."upgrade_acquisition_cost_snapshot" > 0
    AND issued."upgrade_acquisition_tier_snapshot" IN ('city', 'branch')
    AND issued."upgrade_direct_allocation_snapshot" IS NOT NULL
    AND issued."upgrade_direct_allocation_snapshot" >= 0
    AND issued."upgrade_binary_allocation_snapshot" IS NOT NULL
    AND issued."upgrade_binary_allocation_snapshot" > 0
    AND issued."upgrade_points_difference_snapshot" IS NOT NULL
    AND issued."upgrade_points_difference_snapshot" > 0
    AND issued."upgrade_product_line_count_snapshot" IS NOT NULL
    AND issued."upgrade_product_line_count_snapshot" > 0
    AND issued."upgrade_units_snapshot" IS NOT NULL
    AND issued."upgrade_units_snapshot" > 0
    AND issued."upgrade_customer_payment_snapshot"
      = issued."upgrade_reseller_value_snapshot" + issued."pin_allocation_snapshot"
    AND issued."upgrade_binary_allocation_snapshot"
      = issued."upgrade_points_difference_snapshot" * 0.5
    AND issued."upgrade_direct_allocation_snapshot"
      + issued."upgrade_binary_allocation_snapshot"
      <= issued."pin_allocation_snapshot"
    AND issued."upgrade_reseller_value_snapshot"
      >= issued."upgrade_acquisition_cost_snapshot"
    AND totals.invalid_product_count = 0
    AND totals.product_count = issued."upgrade_product_line_count_snapshot"
    AND totals.units = issued."upgrade_units_snapshot"
    AND totals.customer_payment = issued."upgrade_customer_payment_snapshot"
    AND totals.reseller_value = issued."upgrade_reseller_value_snapshot"
    AND totals.acquisition_cost = issued."upgrade_acquisition_cost_snapshot",
    false
  );
END;
$$;


--
-- Name: validate_admin_stock_receipt_header_total(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_admin_stock_receipt_header_total() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  actual_total INTEGER;
BEGIN
  SELECT COALESCE(SUM("quantity"), 0)::INTEGER INTO actual_total
  FROM "admin_stock_receipt_items" WHERE "receipt_id" = NEW."id";
  IF actual_total <> NEW."total_units" THEN
    RAISE EXCEPTION 'Admin stock receipt header does not match its item quantities.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_admin_stock_receipt_total(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_admin_stock_receipt_total() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  expected_total INTEGER;
  actual_total INTEGER;
BEGIN
  SELECT "total_units" INTO expected_total
  FROM "admin_stock_receipts" WHERE "id" = NEW."receipt_id" FOR UPDATE;
  SELECT COALESCE(SUM("quantity"), 0)::INTEGER INTO actual_total
  FROM "admin_stock_receipt_items" WHERE "receipt_id" = NEW."receipt_id";
  IF expected_total IS NULL OR actual_total <> expected_total THEN
    RAISE EXCEPTION 'Admin stock receipt items do not match the sealed total.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_and_protect_pin_request(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_and_protect_pin_request() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  snapshot_pin DECIMAL(12,2);
BEGIN
  IF NEW."quantity" <= 0 OR NEW."quantity" > 50 OR NEW."total_amount" <= 0 THEN
    RAISE EXCEPTION 'PIN request quantity must be between 1 and 50 and total must be positive.' USING ERRCODE = '23514';
  END IF;
  IF NEW."status" <> 'rejected'
     AND NOT "registration_snapshot_is_valid"(NEW."registration_snapshot", NEW."package_id") THEN
    RAISE EXCEPTION 'PIN request requires a complete registration snapshot.' USING ERRCODE = '23514';
  END IF;
  IF NEW."registration_snapshot" IS NOT NULL THEN
    snapshot_pin := (NEW."registration_snapshot"->>'pinAllocation')::DECIMAL(12,2);
    IF snapshot_pin <= 0 OR NEW."total_amount" <> snapshot_pin * NEW."quantity" THEN
      RAISE EXCEPTION 'PIN request total does not match its immutable snapshot.' USING ERRCODE = '23514';
    END IF;
  END IF;
  IF TG_OP = 'INSERT' AND NEW."status" <> 'pending' THEN
    RAISE EXCEPTION 'New PIN requests must start pending.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD."city_dist_id" IS DISTINCT FROM NEW."city_dist_id"
       OR OLD."package_id" IS DISTINCT FROM NEW."package_id"
       OR OLD."quantity" IS DISTINCT FROM NEW."quantity"
       OR OLD."total_amount" IS DISTINCT FROM NEW."total_amount"
       OR OLD."payment_method" IS DISTINCT FROM NEW."payment_method"
       OR OLD."payment_reference" IS DISTINCT FROM NEW."payment_reference"
       OR OLD."payment_sender_name" IS DISTINCT FROM NEW."payment_sender_name"
       OR OLD."payment_datetime" IS DISTINCT FROM NEW."payment_datetime"
       OR OLD."registration_snapshot" IS DISTINCT FROM NEW."registration_snapshot" THEN
      RAISE EXCEPTION 'PIN request economic and payment identity is immutable.' USING ERRCODE = '55000';
    END IF;
    IF OLD."status" IS DISTINCT FROM NEW."status" AND NOT (
         OLD."status" = 'pending' AND NEW."status" IN ('approved', 'rejected')
       ) THEN
      RAISE EXCEPTION 'PIN request status transition is not monotonic.' USING ERRCODE = '55000';
    END IF;
    IF OLD."payment_status" = 'paid' AND NEW."payment_status" <> 'paid' THEN
      RAISE EXCEPTION 'Paid PIN requests cannot be made unpaid.' USING ERRCODE = '55000';
    END IF;
    IF OLD."payment_status" IS DISTINCT FROM NEW."payment_status"
       AND NEW."payment_status" NOT IN ('unpaid', 'pending', 'paid') THEN
      RAISE EXCEPTION 'PIN request payment transition is invalid.' USING ERRCODE = '23514';
    END IF;
  END IF;
  IF NEW."status" = 'approved' AND NEW."payment_status" <> 'paid' THEN
    RAISE EXCEPTION 'PIN request cannot be approved before full payment.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_and_protect_pos_registration_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_and_protect_pos_registration_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
BEGIN
  IF NEW."registration_snapshot" IS NOT NULL
     AND (
       NOT "registration_snapshot_is_valid"(NEW."registration_snapshot", NEW."package_id")
       OR (NEW."registration_snapshot"->>'customerPayment')::DECIMAL(12,2) IS DISTINCT FROM NEW."amount_snapshot"
     ) THEN
    RAISE EXCEPTION 'POS registration snapshot does not match its package/payment.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD."owner_id" IS DISTINCT FROM NEW."owner_id"
       OR OLD."package_id" IS DISTINCT FROM NEW."package_id"
       OR OLD."amount_snapshot" IS DISTINCT FROM NEW."amount_snapshot"
       OR OLD."registration_snapshot" IS DISTINCT FROM NEW."registration_snapshot" THEN
      RAISE EXCEPTION 'POS registration financial identity is immutable.' USING ERRCODE = '55000';
    END IF;
    IF OLD."pin_id" IS NOT NULL AND OLD."pin_id" IS DISTINCT FROM NEW."pin_id" THEN
      RAISE EXCEPTION 'POS registration cannot be rebound to another PIN.' USING ERRCODE = '55000';
    END IF;
  END IF;
  IF NEW."status" IN (
       'released_pending_encoding'::"PosRegistrationIntakeStatus",
       'encoding_in_progress'::"PosRegistrationIntakeStatus",
       'registration_completed'::"PosRegistrationIntakeStatus"
     ) AND NEW."registration_snapshot" IS NULL THEN
    RAISE EXCEPTION 'POS release requires an immutable registration snapshot.' USING ERRCODE = '23514';
  END IF;
  IF NEW."pin_id" IS NOT NULL THEN
    SELECT * INTO issued FROM "pins" WHERE "id" = NEW."pin_id" FOR SHARE;
    IF NOT FOUND OR issued."pin_type" <> 'registration'
       OR issued."city_dist_id" <> NEW."owner_id"
       OR issued."package_id" <> NEW."package_id"
       OR issued."registration_customer_payment_snapshot" <> NEW."amount_snapshot"
       OR NOT "registration_snapshot_matches_pin"(NEW."registration_snapshot", issued."id") THEN
      RAISE EXCEPTION 'POS registration and issued PIN economics do not match.' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_binary_pair_event_closing_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_pair_event_closing_state() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE profile RECORD; recorded_usage BIGINT; cached_usage BIGINT;
BEGIN
 SELECT left_points,right_points,daily_pairing_count,daily_pairing_date INTO profile
 FROM reseller_profiles WHERE user_id=NEW.recipient_user_id FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Package Binary closing profile is missing.' USING ERRCODE='23514'; END IF;
 SELECT used_pairs INTO recorded_usage FROM binary_daily_cap_usage
   WHERE user_id=NEW.recipient_user_id AND pairing_day=NEW.pairing_day;
 SELECT COALESCE((SELECT used_pairs FROM binary_daily_cap_usage
   WHERE user_id=NEW.recipient_user_id AND pairing_day=profile.daily_pairing_date),0) INTO cached_usage;
 IF profile.left_points IS DISTINCT FROM NEW.closing_left_points
   OR profile.right_points IS DISTINCT FROM NEW.closing_right_points
   OR recorded_usage IS DISTINCT FROM NEW.closing_daily_pairing_count::bigint
   OR profile.daily_pairing_date IS NULL OR profile.daily_pairing_date<NEW.pairing_day
   OR profile.daily_pairing_count::bigint IS DISTINCT FROM cached_usage
 THEN RAISE EXCEPTION 'Package Binary event closing carryover/cap state was not applied atomically.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_binary_pair_event_entitlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_pair_event_entitlement() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  settlement_source_user_id TEXT;
  settlement_source_points INTEGER;
  settlement_parent_node_id TEXT;
  settlement_source_leg TEXT;
  expected_recipient_leg TEXT;
  current_left_points INTEGER;
  current_right_points INTEGER;
  current_daily_pairing_count INTEGER;
  current_daily_pairing_date DATE;
  available_left_points BIGINT;
  available_right_points BIGINT;
  expected_package_id TEXT;
  expected_package_name TEXT;
  expected_points_per_pair INTEGER;
  expected_user_status TEXT;
  expected_cap_enabled BOOLEAN;
  expected_cap_limit INTEGER;
  event_pairing_day DATE;
  policy_state RECORD;
  used_today INTEGER;
  used_session INTEGER;
  session_number INTEGER;
  session_limit INTEGER;
  remaining_slots INTEGER;
  potential_pairs INTEGER;
  accepted_source_points INTEGER;
  session_accepted_source_points INTEGER;
  planned_completed_pairs INTEGER;
  expected_within_cap INTEGER;
  expected_payable_pairs INTEGER;
  expected_cap_flashout_pairs INTEGER;
  expected_inactive_flashout_pairs INTEGER;
  reward_policy JSONB;
  reward_enabled BOOLEAN;
  expected_reward_interval INTEGER;
  expected_reward_product TEXT;
  expected_opening BIGINT;
  expected_products INTEGER;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('package-binary-product-reward-policy'));
  SELECT value::jsonb INTO reward_policy FROM system_settings WHERE key='package_binary_product_reward';
  reward_enabled := COALESCE((reward_policy->>'enabled')::boolean,false);
  expected_reward_interval := COALESCE((reward_policy->>'interval')::integer,5);
  expected_reward_product := reward_policy->>'product_id';
  IF expected_reward_interval NOT BETWEEN 2 AND 1000 THEN
    RAISE EXCEPTION 'Invalid product reward interval.' USING ERRCODE='23514';
  END IF;
  IF reward_enabled THEN
    PERFORM 1 FROM products WHERE id=expected_reward_product AND is_active=true AND cost_price>0 FOR SHARE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Select an active reward bottle with a positive company cost.' USING ERRCODE='23514'; END IF;
  END IF;
  -- Use the same lock key as the application so even direct SQL callers
  -- cannot race two cap/carryover decisions for one recipient.
  PERFORM pg_advisory_xact_lock(hashtext('binary:' || NEW."recipient_user_id"));

  SELECT event."source_user_id", event."source_points", event."parent_node_id", event."source_leg"
  INTO settlement_source_user_id, settlement_source_points,
       settlement_parent_node_id, settlement_source_leg
  FROM "binary_settlement_events" event
  WHERE event."source_kind" = NEW."source_kind"
    AND event."source_event_id" = NEW."source_event_id"
  FOR SHARE;

  IF settlement_source_user_id IS NULL
     OR NEW."source_user_id" IS DISTINCT FROM settlement_source_user_id
     OR NEW."source_points" IS DISTINCT FROM settlement_source_points THEN
    RAISE EXCEPTION 'Package Binary pair event does not match its settlement source.' USING ERRCODE = '23514';
  END IF;

  WITH RECURSIVE ancestor_chain AS (
    SELECT node."id", node."user_id", node."parent_id", node."position",
           settlement_source_leg::text AS effective_leg
    FROM "binary_tree_nodes" node
    WHERE node."id" = settlement_parent_node_id

    UNION ALL

    SELECT parent."id", parent."user_id", parent."parent_id", parent."position",
           child."position"::text AS effective_leg
    FROM ancestor_chain child
    JOIN "binary_tree_nodes" parent ON parent."id" = child."parent_id"
  )
  SELECT chain.effective_leg
  INTO expected_recipient_leg
  FROM ancestor_chain chain
  WHERE chain."user_id" = NEW."recipient_user_id"
  LIMIT 1;

  IF expected_recipient_leg IS NULL OR NEW."source_leg" IS DISTINCT FROM expected_recipient_leg THEN
    RAISE EXCEPTION 'Package Binary recipient is not an ancestor on the sealed source leg.' USING ERRCODE = '23514';
  END IF;

  SELECT COALESCE(profile."left_points", 0), COALESCE(profile."right_points", 0),
         COALESCE(profile."daily_pairing_count", 0), profile."daily_pairing_date",
         profile."package_id", package."name",
         ROUND(COALESCE(package."pairing_bonus_value", 0))::INTEGER,
         recipient."status"::text,
         COALESCE(package."binary_pair_cap_enabled", true),
         GREATEST(1, COALESCE(package."daily_binary_pair_cap", 10))::INTEGER
  INTO current_left_points, current_right_points,
       current_daily_pairing_count, current_daily_pairing_date,
       expected_package_id, expected_package_name, expected_points_per_pair,
       expected_user_status, expected_cap_enabled, expected_cap_limit
  FROM "reseller_profiles" profile
  JOIN "packages" package ON package."id" = profile."package_id"
  JOIN "users" recipient ON recipient."id" = profile."user_id"
  WHERE profile."user_id" = NEW."recipient_user_id"
  FOR UPDATE OF profile
  FOR SHARE OF package, recipient;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Package Binary recipient has no package/carryover profile.' USING ERRCODE = '23503';
  END IF;

  IF NEW."completed_pairs" < 0
     OR NEW."points_per_pair" <= 0
     OR NEW."points_per_pair" IS DISTINCT FROM expected_points_per_pair
     OR NEW."recipient_package_id" IS DISTINCT FROM expected_package_id
     OR NEW."package_name_snapshot" IS DISTINCT FROM expected_package_name
     OR NEW."package_snapshot_source" IS DISTINCT FROM 'exact_event'
     OR (NEW."created_at" AT TIME ZONE 'Asia/Manila')::date IS DISTINCT FROM
          (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date
     OR NEW."source_points" <= 0
     OR NEW."peso_per_point" <= 0
     OR NEW."peso_per_point" IS DISTINCT FROM 0.5
     OR NEW."consumed_left_points" IS DISTINCT FROM NEW."completed_pairs" * NEW."points_per_pair"
     OR NEW."consumed_right_points" IS DISTINCT FROM NEW."completed_pairs" * NEW."points_per_pair"
     OR NEW."pair_value_snapshot" IS DISTINCT FROM NEW."points_per_pair" * NEW."peso_per_point"
     OR NEW."payable_amount" IS DISTINCT FROM (NEW."payable_pairs" - NEW."product_reward_pairs") * NEW."points_per_pair" * NEW."peso_per_point"
     OR NEW."flashout_amount" IS DISTINCT FROM
          (NEW."cap_flashout_pairs" + NEW."inactive_flashout_pairs") * NEW."points_per_pair" * NEW."peso_per_point"
     OR (NEW."payable_amount" > 0) IS DISTINCT FROM (NEW."normal_commission_id" IS NOT NULL)
     OR (NEW."flashout_amount" > 0) IS DISTINCT FROM (NEW."flashout_commission_id" IS NOT NULL) THEN
    RAISE EXCEPTION 'Package Binary pair amounts or commission links are inconsistent.' USING ERRCODE = '23514';
  END IF;

  event_pairing_day := (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date;
  SELECT COALESCE((SELECT used_pairs FROM binary_daily_cap_usage
    WHERE user_id=NEW.recipient_user_id AND pairing_day=event_pairing_day),0)::integer INTO used_today;
  SELECT * INTO policy_state FROM package_binary_cap_state_v2(expected_package_id,NEW.recipient_user_id,CURRENT_TIMESTAMP);
  expected_cap_enabled:=policy_state.enabled;expected_cap_limit:=policy_state.cap;
  used_today:=policy_state.used_today;used_session:=policy_state.used_session;
  session_number:=policy_state.session;session_limit:=policy_state.session_cap;
  remaining_slots := CASE WHEN expected_cap_enabled THEN
    GREATEST(0,LEAST(expected_cap_limit-used_today,session_limit-used_session)) ELSE NULL END;
  potential_pairs := LEAST(current_left_points::bigint+CASE WHEN NEW.source_leg='left' THEN NEW.source_points ELSE 0 END,
    current_right_points::bigint+CASE WHEN NEW.source_leg='right' THEN NEW.source_points ELSE 0 END)/expected_points_per_pair;
  accepted_source_points := NEW.source_points;
  IF remaining_slots IS NOT NULL AND potential_pairs>=remaining_slots THEN
    accepted_source_points := LEAST(NEW.source_points,GREATEST(0,remaining_slots*expected_points_per_pair
      -CASE WHEN NEW.source_leg='left' THEN current_left_points ELSE current_right_points END));
  END IF;
  session_accepted_source_points:=accepted_source_points;
  planned_completed_pairs:=LEAST(potential_pairs,COALESCE(remaining_slots,potential_pairs));
  IF policy_state.carryover_enabled THEN
    accepted_source_points:=LEAST(accepted_source_points,GREATEST(0,policy_state.carryover_limit::bigint
      -CASE WHEN NEW.source_leg='left' THEN current_left_points ELSE current_right_points END
      +planned_completed_pairs::bigint*expected_points_per_pair))::integer;
  END IF;
  NEW.carryover_policy_id:=policy_state.carryover_policy_id::uuid;
  NEW.carryover_cap_enabled:=policy_state.carryover_enabled;
  NEW.carryover_cap_points:=CASE WHEN policy_state.carryover_enabled THEN policy_state.carryover_limit ELSE NULL END;
  NEW.session_flushed_points:=NEW.source_points-session_accepted_source_points;
  NEW.carryover_flushed_points:=session_accepted_source_points-accepted_source_points;
  IF NEW.source_points_flushed IS DISTINCT FROM NEW.source_points-accepted_source_points THEN
    RAISE EXCEPTION 'Package Binary source flush does not match locked session allowance.' USING ERRCODE='23514';
  END IF;

  -- The event is inserted before the application mutates this locked profile,
  -- so an attacker cannot fabricate an opposite-leg opening balance and use it
  -- to mint a pair. This specifically rejects a 0/0 profile claiming 0/600 as
  -- its opening state for a new 600-point left-leg source.
  available_left_points := NEW."opening_left_points"::bigint
    + CASE WHEN NEW."source_leg" = 'left' THEN accepted_source_points ELSE 0 END;
  available_right_points := NEW."opening_right_points"::bigint
    + CASE WHEN NEW."source_leg" = 'right' THEN accepted_source_points ELSE 0 END;

  IF NEW."opening_left_points" IS DISTINCT FROM current_left_points
     OR NEW."opening_right_points" IS DISTINCT FROM current_right_points
     OR NEW."opening_left_points" < 0 OR NEW."opening_right_points" < 0
     OR NEW."closing_left_points" < 0 OR NEW."closing_right_points" < 0
     OR NEW."completed_pairs" IS DISTINCT FROM (CASE
          WHEN NEW."points_per_pair" > 0
            THEN LEAST(available_left_points, available_right_points) / NEW."points_per_pair"
          ELSE 0
        END)
     OR NEW."closing_left_points" IS DISTINCT FROM
          available_left_points - NEW."consumed_left_points"
     OR NEW."closing_right_points" IS DISTINCT FROM
          available_right_points - NEW."consumed_right_points" THEN
    RAISE EXCEPTION 'Package Binary pair does not reconcile to locked opening carryover and exact source volume.' USING ERRCODE = '23514';
  END IF;

  expected_within_cap := CASE
    WHEN expected_cap_enabled
      THEN LEAST(NEW."completed_pairs", GREATEST(0, expected_cap_limit - used_today))
    ELSE NEW."completed_pairs"
  END;
  IF expected_within_cap IS DISTINCT FROM NEW.completed_pairs
    OR (remaining_slots IS NOT NULL AND NEW.completed_pairs>remaining_slots) THEN
    RAISE EXCEPTION 'Package Binary session cap exceeded.' USING ERRCODE='23514';
  END IF;
  expected_cap_flashout_pairs := NEW."completed_pairs" - expected_within_cap;
  expected_payable_pairs := CASE
    WHEN expected_user_status = 'active' THEN expected_within_cap
    ELSE 0
  END;
  expected_inactive_flashout_pairs := CASE
    WHEN expected_user_status = 'active' THEN 0
    ELSE expected_within_cap
  END;

  SELECT COALESCE(SUM(payable_pairs),0) INTO expected_opening
  FROM binary_pair_events WHERE recipient_user_id=NEW.recipient_user_id AND reward_interval IS NOT NULL;
  expected_products := CASE WHEN reward_enabled THEN
    ((expected_opening + expected_payable_pairs) / expected_reward_interval - expected_opening / expected_reward_interval)::integer
    ELSE 0 END;
  IF NEW.opening_reward_eligible_count IS DISTINCT FROM expected_opening
    OR NEW.product_reward_pairs IS DISTINCT FROM expected_products
    OR NEW.reward_interval IS DISTINCT FROM (CASE WHEN reward_enabled THEN expected_reward_interval ELSE NULL END)
    OR NEW.reward_product_id IS DISTINCT FROM (CASE WHEN reward_enabled THEN expected_reward_product ELSE NULL END)
  THEN RAISE EXCEPTION 'Package Binary product reward does not match locked policy and eligible ordinal.' USING ERRCODE='23514'; END IF;

  IF used_today < 0
     OR NEW."cap_enabled" IS DISTINCT FROM expected_cap_enabled
     OR NEW."cap_limit" IS DISTINCT FROM
          (CASE WHEN expected_cap_enabled THEN expected_cap_limit ELSE NULL END)
     OR NEW."payable_pairs" IS DISTINCT FROM expected_payable_pairs
     OR NEW."cap_flashout_pairs" IS DISTINCT FROM expected_cap_flashout_pairs
     OR NEW."inactive_flashout_pairs" IS DISTINCT FROM expected_inactive_flashout_pairs THEN
    RAISE EXCEPTION 'Package Binary payable/flashout partition does not match locked status and daily cap state.' USING ERRCODE = '23514';
  END IF;

  -- These cap snapshots are database-authored. The deferred verifier below
  -- proves the application applied both points and daily-cap state atomically.
  NEW.cap_policy_id:=policy_state.policy_id::uuid;
  NEW.cap_mode:=policy_state.mode;
  NEW.cap_cutoff:=policy_state.cutoff;
  NEW.cap_session := session_number;
  NEW.opening_session_pairing_count := used_session;
  NEW.closing_session_pairing_count := used_session+expected_within_cap;
  NEW."pairing_day" := event_pairing_day;
  NEW."opening_daily_pairing_count" := used_today;
  NEW."closing_daily_pairing_count" := used_today + expected_within_cap;

  RETURN NEW;
END;
$$;


--
-- Name: validate_binary_point_evidence_balance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_point_evidence_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  lot "binary_point_lots"%ROWTYPE;
  consumed INTEGER;
  expired INTEGER;
BEGIN
  SELECT * INTO lot FROM "binary_point_lots" WHERE "id"=NEW."point_lot_id";
  SELECT COALESCE(SUM(points),0)::INTEGER INTO consumed
  FROM "binary_point_consumptions" WHERE "point_lot_id"=NEW."point_lot_id";
  SELECT COALESCE(SUM(points),0)::INTEGER INTO expired
  FROM "binary_point_expirations" WHERE "point_lot_id"=NEW."point_lot_id";
  IF lot."id" IS NULL OR lot."original_points" - lot."remaining_points" <> consumed + expired THEN
    RAISE EXCEPTION 'Binary point evidence does not reconcile to its point lot.' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_binary_point_lot_balance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_point_lot_balance() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE original INTEGER; remaining INTEGER; consumed BIGINT; expired BIGINT;
BEGIN
 SELECT original_points,remaining_points INTO original,remaining FROM binary_point_lots WHERE id=NEW.id;
 SELECT COALESCE(SUM(points),0) INTO consumed FROM binary_point_consumptions WHERE point_lot_id=NEW.id;
 SELECT COALESCE(SUM(points),0) INTO expired FROM binary_point_expirations WHERE point_lot_id=NEW.id;
 IF original IS NULL OR original::bigint-remaining::bigint<>consumed+expired THEN
  RAISE EXCEPTION 'Binary point lot does not reconcile to final consumption and expiration evidence.' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_binary_session_closing_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_session_closing_state() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE actual_usage BIGINT; daily_usage BIGINT; recorded_total BIGINT;
 credited_points BIGINT; consumed_left BIGINT; consumed_right BIGINT;
 remaining_left BIGINT; remaining_right BIGINT;
BEGIN
 SELECT used_session INTO actual_usage FROM package_binary_cap_state(NEW.recipient_package_id,NEW.recipient_user_id,CURRENT_TIMESTAMP);
 IF actual_usage IS DISTINCT FROM NEW.closing_session_pairing_count::bigint THEN
  RAISE EXCEPTION 'Package Binary closing session usage was not applied atomically.' USING ERRCODE='23514';
 END IF;
 SELECT COALESCE(SUM(original_points),0) INTO credited_points FROM binary_point_lots
 WHERE recipient_user_id=NEW.recipient_user_id AND source_kind=NEW.source_kind
   AND source_event_id=NEW.source_event_id AND leg=NEW.source_leg;
 SELECT COALESCE(SUM(c.points) FILTER(WHERE lot.leg='left'),0),
   COALESCE(SUM(c.points) FILTER(WHERE lot.leg='right'),0)
 INTO consumed_left,consumed_right FROM binary_point_consumptions c
 JOIN binary_point_lots lot ON lot.id=c.point_lot_id WHERE c.binary_pair_event_id=NEW.id;
 SELECT COALESCE(SUM(remaining_points) FILTER(WHERE leg='left'),0),
   COALESCE(SUM(remaining_points) FILTER(WHERE leg='right'),0)
 INTO remaining_left,remaining_right FROM binary_point_lots WHERE recipient_user_id=NEW.recipient_user_id;
 IF credited_points IS DISTINCT FROM (NEW.source_points-NEW.source_points_flushed)::bigint
   OR consumed_left IS DISTINCT FROM NEW.consumed_left_points::bigint
   OR consumed_right IS DISTINCT FROM NEW.consumed_right_points::bigint
   OR remaining_left IS DISTINCT FROM NEW.closing_left_points::bigint
   OR remaining_right IS DISTINCT FROM NEW.closing_right_points::bigint THEN
  RAISE EXCEPTION 'Package Binary accepted/flushed volume does not reconcile to point lots.' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_binary_settlement_event_completeness(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_settlement_event_completeness() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  ancestor_set_mismatch BOOLEAN;
BEGIN
  WITH RECURSIVE ancestor_chain AS (
    SELECT node."id", node."user_id", node."parent_id"
    FROM "binary_tree_nodes" node
    WHERE node."id" = NEW."parent_node_id"

    UNION ALL

    SELECT parent."id", parent."user_id", parent."parent_id"
    FROM ancestor_chain child
    JOIN "binary_tree_nodes" parent ON parent."id" = child."parent_id"
  ),
  expected_recipients AS (
    SELECT chain."user_id"
    FROM ancestor_chain chain
    JOIN "reseller_profiles" profile ON profile."user_id" = chain."user_id"
  ),
  recorded_recipients AS (
    SELECT event."recipient_user_id" AS "user_id"
    FROM "binary_pair_events" event
    WHERE event."source_kind" = NEW."source_kind"
      AND event."source_event_id" = NEW."source_event_id"
  )
  SELECT EXISTS (
    (SELECT expected."user_id" FROM expected_recipients expected
     EXCEPT
     SELECT recorded."user_id" FROM recorded_recipients recorded)
    UNION ALL
    (SELECT recorded."user_id" FROM recorded_recipients recorded
     EXCEPT
     SELECT expected."user_id" FROM expected_recipients expected)
  )
  INTO ancestor_set_mismatch;

  IF ancestor_set_mismatch THEN
    RAISE EXCEPTION 'Package Binary settlement does not contain one exact volume event for every eligible ancestor.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_binary_settlement_source_entitlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_settlement_source_entitlement() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  expected_source_user_id TEXT;
  expected_source_points INTEGER;
  actual_parent_node_id TEXT;
  actual_source_leg TEXT;
BEGIN
  IF NEW."source_kind" = 'registration' THEN
    SELECT rf."reseller_id", rf."binary_points_per_pair"
    INTO expected_source_user_id, expected_source_points
    FROM "registration_financials" rf
    WHERE rf."pin_id" = NEW."source_event_id"
      AND rf."payment_status" = 'paid'
    FOR SHARE;
  ELSIF NEW."source_kind" = 'upgrade' THEN
    SELECT uf."reseller_id", uf."binary_points_difference"
    INTO expected_source_user_id, expected_source_points
    FROM "upgrade_financials" uf
    WHERE uf."upgrade_pin_id" = NEW."source_event_id"
      AND uf."payment_status" = 'paid'
    FOR SHARE;
  ELSE
    RAISE EXCEPTION 'Package Binary source kind is unsupported.' USING ERRCODE = '23514';
  END IF;

  IF expected_source_user_id IS NULL
     OR NEW."source_user_id" IS DISTINCT FROM expected_source_user_id
     OR NEW."source_points" IS DISTINCT FROM expected_source_points THEN
    RAISE EXCEPTION 'Package Binary settlement does not match its paid registration/upgrade source.' USING ERRCODE = '23514';
  END IF;

  SELECT node."parent_id", node."position"::text
  INTO actual_parent_node_id, actual_source_leg
  FROM "binary_tree_nodes" node
  WHERE node."user_id" = NEW."source_user_id"
  FOR SHARE;

  IF actual_parent_node_id IS NULL
     OR NEW."parent_node_id" IS DISTINCT FROM actual_parent_node_id
     OR NEW."source_leg" IS DISTINCT FROM actual_source_leg THEN
    RAISE EXCEPTION 'Package Binary settlement parent/leg does not match the source member placement.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_binary_tree_leaf_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_binary_tree_leaf_insert() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public'
    AS $$
BEGIN
  IF NEW."left_count" <> 0 OR NEW."right_count" <> 0 THEN
    RAISE EXCEPTION 'A newly placed binary-tree node must start with zero descendant counts.'
      USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_direct_referral_settlement_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_direct_referral_settlement_insert() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  financial RECORD;
  sponsor RECORD;
  system_account_count INTEGER;
  expected_opening INTEGER;
  expected_eligible BOOLEAN;
  expected_cap_exceeded BOOLEAN;
  expected_payable DECIMAL(12,2);
  expected_retained DECIMAL(12,2);
  expected_closing INTEGER;
  expected_disposition TEXT;
  normal_match_count INTEGER;
  retained_match_count INTEGER;
BEGIN
  NEW."created_at" := transaction_timestamp();

  SELECT rf."id", rf."pin_id", rf."reseller_id", rf."direct_referral_allocation"
  INTO financial
  FROM "registration_financials" rf
  WHERE rf."id" = NEW."registration_financial_id"
    AND rf."pin_id" = NEW."source_event_id"
    AND rf."reseller_id" = NEW."referred_user_id"
    AND rf."payment_status" = 'paid'
  FOR SHARE;

  IF financial."id" IS NULL
     OR NEW."source_allocation" IS DISTINCT FROM financial."direct_referral_allocation"
     OR NEW."settlement_day" IS DISTINCT FROM
        (transaction_timestamp() AT TIME ZONE 'Asia/Manila')::date THEN
    RAISE EXCEPTION 'Direct Referral event does not match one paid registration allocation.' USING ERRCODE = '23514';
  END IF;

  IF NEW."disposition" = 'retained_system_root' THEN
    SELECT COUNT(*)::INTEGER
    INTO system_account_count
    FROM "users" account
    WHERE account."id" = NEW."sponsor_user_id"
      AND account."username" = 'hiroma'
      AND account."role" = 'admin'::"Role";

    IF system_account_count IS DISTINCT FROM 1
       OR NEW."sponsor_package_id" IS NOT NULL
       OR NEW."package_name_snapshot" IS DISTINCT FROM 'Hiroma system root'
       OR NEW."sponsor_bonus_snapshot" IS DISTINCT FROM 0
       OR NEW."cap_enabled"
       OR NEW."cap_limit" IS DISTINCT FROM 0
       OR NEW."opening_daily_referral_count" IS DISTINCT FROM 0
       OR NEW."closing_daily_referral_count" IS DISTINCT FROM 0
       OR NEW."recipient_eligible"
       OR NEW."payable_amount" IS DISTINCT FROM 0
       OR NEW."retained_amount" IS DISTINCT FROM NEW."source_allocation"
       OR NEW."normal_commission_id" IS NOT NULL
       OR NEW."retained_commission_id" IS NOT NULL THEN
      RAISE EXCEPTION 'Hiroma root Direct Referral retention is not exact.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  SELECT profile."package_id",
         package."name" AS package_name,
         package."direct_referral_bonus"::DECIMAL(12,2) AS sponsor_bonus,
         COALESCE(package."direct_referral_cap_enabled", true) AS cap_enabled,
         GREATEST(COALESCE(package."daily_referral_cap", 10), 0)::INTEGER AS cap_limit,
         user_row."role"::TEXT AS role,
         user_row."status"::TEXT AS status,
         CASE
           WHEN (profile."last_referral_date" AT TIME ZONE 'Asia/Manila')::date = NEW."settlement_day"
             THEN GREATEST(profile."daily_referral_count", 0)
           ELSE 0
         END::INTEGER AS effective_count
  INTO sponsor
  FROM "reseller_profiles" profile
  JOIN "users" user_row ON user_row."id" = profile."user_id"
  JOIN "packages" package ON package."id" = profile."package_id"
  WHERE profile."user_id" = NEW."sponsor_user_id"
  FOR UPDATE OF profile, user_row FOR SHARE OF package;

  IF sponsor."package_id" IS NULL THEN
    RAISE EXCEPTION 'Direct Referral sponsor profile is missing.' USING ERRCODE = '23514';
  END IF;

  expected_opening := sponsor."effective_count";
  expected_eligible := sponsor."role" = 'reseller' AND sponsor."status" = 'active';
  expected_cap_exceeded := sponsor."cap_enabled" AND expected_opening >= sponsor."cap_limit";
  expected_payable := CASE
    WHEN expected_eligible AND NOT expected_cap_exceeded
      THEN LEAST(sponsor."sponsor_bonus", NEW."source_allocation")
    ELSE 0
  END;
  expected_retained := NEW."source_allocation" - expected_payable;
  expected_closing := expected_opening +
    CASE WHEN expected_eligible AND NOT expected_cap_exceeded THEN 1 ELSE 0 END;
  expected_disposition := CASE
    WHEN NOT expected_eligible THEN 'retained_ineligible'
    WHEN expected_cap_exceeded THEN 'retained_cap'
    WHEN expected_payable <= 0 THEN 'retained_package_difference'
    WHEN expected_retained > 0 THEN 'paid_with_package_remainder'
    ELSE 'paid'
  END;

  IF NEW."sponsor_package_id" IS DISTINCT FROM sponsor."package_id"
     OR NEW."package_name_snapshot" IS DISTINCT FROM sponsor."package_name"
     OR NEW."sponsor_bonus_snapshot" IS DISTINCT FROM sponsor."sponsor_bonus"
     OR NEW."cap_enabled" IS DISTINCT FROM sponsor."cap_enabled"
     OR NEW."cap_limit" IS DISTINCT FROM sponsor."cap_limit"
     OR NEW."opening_daily_referral_count" IS DISTINCT FROM expected_opening
     OR NEW."closing_daily_referral_count" IS DISTINCT FROM expected_closing
     OR NEW."recipient_eligible" IS DISTINCT FROM expected_eligible
     OR NEW."disposition" IS DISTINCT FROM expected_disposition
     OR NEW."payable_amount" IS DISTINCT FROM expected_payable
     OR NEW."retained_amount" IS DISTINCT FROM expected_retained THEN
    RAISE EXCEPTION 'Direct Referral event does not match locked sponsor package, eligibility, or cap state.' USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(*)::INTEGER
  INTO normal_match_count
  FROM "commissions" commission
  WHERE commission."id" = NEW."normal_commission_id"
    AND commission."event_key" =
        'registration:' || NEW."source_event_id" || ':direct:' || NEW."sponsor_user_id" || ':payable'
    AND commission."source_event_kind" = 'registration'
    AND commission."source_event_id" = NEW."source_event_id"
    AND commission."rule_version" = 'registration-direct-v1'
    AND commission."user_id" = NEW."sponsor_user_id"
    AND commission."type" = 'direct_referral'::"CommissionType"
    AND commission."amount" = NEW."payable_amount"
    AND commission."source_user_id" = NEW."referred_user_id"
    AND commission."is_pair_overflow" = false
    AND commission."overflow_to" IS NULL;

  IF (NEW."payable_amount" > 0 AND normal_match_count IS DISTINCT FROM 1)
     OR (NEW."payable_amount" = 0 AND NEW."normal_commission_id" IS NOT NULL) THEN
    RAISE EXCEPTION 'Direct Referral payable commission does not match its exact event.' USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(*)::INTEGER
  INTO retained_match_count
  FROM "commissions" commission
  JOIN "users" hiroma ON hiroma."id" = commission."user_id"
  WHERE commission."id" = NEW."retained_commission_id"
    AND commission."source_event_kind" = 'registration'
    AND commission."source_event_id" = NEW."source_event_id"
    AND commission."rule_version" = 'registration-direct-v1'
    AND commission."type" = 'direct_referral'::"CommissionType"
    AND commission."amount" = NEW."retained_amount"
    AND commission."source_user_id" = NEW."referred_user_id"
    AND commission."is_pair_overflow" = true
    AND commission."overflow_to" = commission."user_id"
    AND hiroma."username" = 'hiroma'
    AND hiroma."role" = 'admin'::"Role";

  IF (NEW."retained_amount" > 0 AND retained_match_count IS DISTINCT FROM 1)
     OR (NEW."retained_amount" = 0 AND NEW."retained_commission_id" IS NOT NULL) THEN
    RAISE EXCEPTION 'Direct Referral retained commission does not match its exact event.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_distributor_parent_territory(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_distributor_parent_territory() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE parent distributor_profiles%ROWTYPE;
BEGIN
 IF NEW.is_active AND (NULLIF(btrim(NEW.region_code),'') IS NULL
   OR (NEW.dist_level::text IN ('provincial','city','branch') AND NULLIF(btrim(NEW.province_code),'') IS NULL)
   OR (NEW.dist_level::text IN ('city','branch') AND NULLIF(btrim(NEW.city_muni_code),'') IS NULL))
 THEN RAISE EXCEPTION 'DISTRIBUTOR_TERRITORY_REQUIRED' USING ERRCODE='23514'; END IF;
 IF NEW.parent_dist_id IS NOT NULL THEN
   SELECT * INTO parent FROM distributor_profiles WHERE id=NEW.parent_dist_id FOR SHARE;
   IF NOT FOUND OR parent.id=NEW.id OR
     NOT ((NEW.dist_level::text IN ('city','branch') AND parent.dist_level::text='provincial'
       AND NULLIF(btrim(NEW.province_code),'')=NULLIF(btrim(parent.province_code),'')
       AND NULLIF(btrim(NEW.region_code),'')=NULLIF(btrim(parent.region_code),''))
     OR (NEW.dist_level::text IN ('city','branch','provincial') AND parent.dist_level::text='regional'
       AND NULLIF(btrim(NEW.region_code),'')=NULLIF(btrim(parent.region_code),''))) IS TRUE
   THEN RAISE EXCEPTION 'DISTRIBUTOR_PARENT_TERRITORY_MISMATCH' USING ERRCODE='23514'; END IF;
 END IF;
 -- A parent location/level edit must not strand existing child assignments.
 IF EXISTS(SELECT 1 FROM distributor_profiles c WHERE c.parent_dist_id=NEW.id AND c.is_active AND
   NOT ((c.dist_level::text IN ('city','branch') AND NEW.dist_level::text='provincial'
      AND NULLIF(btrim(c.province_code),'')=NULLIF(btrim(NEW.province_code),'')
      AND NULLIF(btrim(c.region_code),'')=NULLIF(btrim(NEW.region_code),''))
    OR (c.dist_level::text IN ('city','branch','provincial') AND NEW.dist_level::text='regional'
      AND NULLIF(btrim(c.region_code),'')=NULLIF(btrim(NEW.region_code),''))) IS TRUE)
 THEN RAISE EXCEPTION 'DISTRIBUTOR_CHILD_TERRITORY_MISMATCH' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_exact_commission_entitlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_exact_commission_entitlement() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  direct_source_user_id TEXT;
  direct_sponsor_user_id TEXT;
  direct_source_allocation DECIMAL(12,2);
  direct_entitled_amount DECIMAL(12,2);
  direct_paid_count INTEGER;
  direct_retained_count INTEGER;
  direct_paid_amount DECIMAL(12,2);
  direct_retained_amount DECIMAL(12,2);
  exact_match_count INTEGER;
BEGIN
  IF NEW."type" = 'direct_referral'::"CommissionType" THEN
    SELECT rf."reseller_id", source_node."sponsor_id", rf."direct_referral_allocation",
           LEAST(sponsor_package."direct_referral_bonus", rf."direct_referral_allocation")::DECIMAL(12,2)
    INTO direct_source_user_id, direct_sponsor_user_id,
         direct_source_allocation, direct_entitled_amount
    FROM "registration_financials" rf
    JOIN "binary_tree_nodes" source_node ON source_node."user_id" = rf."reseller_id"
    JOIN "reseller_profiles" sponsor_profile ON sponsor_profile."user_id" = source_node."sponsor_id"
    JOIN "packages" sponsor_package ON sponsor_package."id" = sponsor_profile."package_id"
    WHERE rf."pin_id" = NEW."source_event_id"
      AND rf."payment_status" = 'paid'
    FOR SHARE OF rf, source_node, sponsor_profile, sponsor_package;

    IF direct_source_user_id IS NULL
       OR NEW."rule_version" IS DISTINCT FROM 'registration-direct-v1'
       OR NEW."source_event_kind" IS DISTINCT FROM 'registration'
       OR NEW."source_user_id" IS DISTINCT FROM direct_source_user_id THEN
      RAISE EXCEPTION 'Direct referral commission does not match the registered member and exact sponsor entitlement.' USING ERRCODE = '23514';
    END IF;

    IF NEW."is_pair_overflow" = false THEN
      IF NEW."user_id" IS DISTINCT FROM direct_sponsor_user_id
         OR NEW."amount" IS DISTINCT FROM direct_entitled_amount THEN
        RAISE EXCEPTION 'Direct referral commission does not match the registered member and exact sponsor entitlement.' USING ERRCODE = '23514';
      END IF;
    ELSE
      -- Retained direct-referral evidence is non-spendable. Its exact daily-cap
      -- decision cannot be reconstructed without a dedicated immutable event,
      -- but it may never name another source, exceed the sealed allocation, or
      -- be retained by an account other than the Hiroma system account.
      IF NEW."amount" <= 0
         OR NEW."amount" > direct_source_allocation
         OR NEW."overflow_to" IS DISTINCT FROM NEW."user_id"
         OR NOT EXISTS (
              SELECT 1 FROM "users" hiroma
              WHERE hiroma."id" = NEW."user_id"
                AND hiroma."username" = 'hiroma'
                AND hiroma."role" = 'admin'::"Role"
            ) THEN
        RAISE EXCEPTION 'Retained direct referral evidence exceeds its sealed registration source or is not assigned to Hiroma.' USING ERRCODE = '23514';
      END IF;
    END IF;

    SELECT
      COUNT(*) FILTER (WHERE commission."is_pair_overflow" = false)::INTEGER,
      COUNT(*) FILTER (WHERE commission."is_pair_overflow" = true)::INTEGER,
      COALESCE(SUM(commission."amount") FILTER (WHERE commission."is_pair_overflow" = false), 0)::DECIMAL(12,2),
      COALESCE(SUM(commission."amount") FILTER (WHERE commission."is_pair_overflow" = true), 0)::DECIMAL(12,2)
    INTO direct_paid_count, direct_retained_count,
         direct_paid_amount, direct_retained_amount
    FROM "commissions" commission
    WHERE commission."type" = 'direct_referral'::"CommissionType"
      AND commission."rule_version" = 'registration-direct-v1'
      AND commission."source_event_kind" = 'registration'
      AND commission."source_event_id" = NEW."source_event_id";

    IF direct_paid_count > 1 OR direct_retained_count > 1
       OR direct_paid_amount NOT IN (0, direct_entitled_amount)
       OR direct_retained_amount IS DISTINCT FROM direct_source_allocation - direct_paid_amount THEN
      RAISE EXCEPTION 'Direct referral paid and retained evidence does not exactly exhaust one sealed allocation.' USING ERRCODE = '23514';
    END IF;

  ELSIF NEW."type" = 'binary_pairing'::"CommissionType" THEN
    IF NEW."rule_version" IS DISTINCT FROM 'package-binary-v1' THEN
      RAISE EXCEPTION 'Package Binary commission uses an unsupported rule version.' USING ERRCODE = '23514';
    END IF;

    IF NEW."is_pair_overflow" = false THEN
      SELECT COUNT(*)::INTEGER
      INTO exact_match_count
      FROM "binary_pair_events" event
      WHERE event."normal_commission_id" = NEW."id"
        AND event."recipient_user_id" = NEW."user_id"
        AND event."source_user_id" = NEW."source_user_id"
        AND event."source_kind" = NEW."source_event_kind"
        AND event."source_event_id" = NEW."source_event_id"
        AND event."payable_amount" = NEW."amount"
        AND NEW."points" IS NOT NULL
        AND NEW."points"::NUMERIC = (event."payable_pairs" - event."product_reward_pairs") * event."points_per_pair";

      IF exact_match_count <> 1 THEN
        RAISE EXCEPTION 'Package Binary commission has no exact immutable pair entitlement.' USING ERRCODE = '23514';
      END IF;
    ELSE
      SELECT COUNT(*)::INTEGER
      INTO exact_match_count
      FROM "binary_pair_events" event
      WHERE event."flashout_commission_id" = NEW."id"
        AND event."source_user_id" = NEW."source_user_id"
        AND event."source_kind" = NEW."source_event_kind"
        AND event."source_event_id" = NEW."source_event_id"
        AND event."flashout_amount" = NEW."amount"
        AND NEW."points" IS NOT NULL
        AND NEW."points"::NUMERIC =
            (event."cap_flashout_pairs" + event."inactive_flashout_pairs") * event."points_per_pair"
        AND NEW."overflow_to" = NEW."user_id"
        AND EXISTS (
          SELECT 1 FROM "users" hiroma
          WHERE hiroma."id" = NEW."user_id"
            AND hiroma."username" = 'hiroma'
            AND hiroma."role" = 'admin'::"Role"
        );

      IF exact_match_count <> 1 THEN
        RAISE EXCEPTION 'Retained Package Binary commission has no exact immutable pair entitlement.' USING ERRCODE = '23514';
      END IF;
    END IF;

  ELSIF NEW."type" = 'sponsor_point'::"CommissionType" THEN
    IF NEW.rule_version = 'product-binary-weekly-v1' THEN
      IF NEW.is_pair_overflow OR NEW.source_event_kind IS DISTINCT FROM 'product_binary_week'
         OR NEW.source_user_id IS NOT NULL OR NEW.points IS NOT NULL
         OR NOT EXISTS (
           SELECT 1 FROM product_binary_pool_allocations a
           JOIN product_binary_pool_weeks w USING (week_start)
           WHERE w.closed_at IS NOT NULL AND a.commission_id = NEW.id
             AND a.recipient_user_id = NEW.user_id
             AND to_char(a.week_start, 'YYYY-MM-DD') = NEW.source_event_id
             AND a.amount_centavos::numeric = NEW.amount * 100
         ) THEN
        RAISE EXCEPTION 'Product Binary commission has no exact weekly allocation.' USING ERRCODE = '23514';
      END IF;
      RETURN NEW;
    END IF;
    IF NEW."rule_version" IS DISTINCT FROM 'product-binary-v1' THEN
      RAISE EXCEPTION 'Product Binary commission uses an unsupported rule version.' USING ERRCODE = '23514';
    END IF;

    IF NEW."is_pair_overflow" = false THEN
      SELECT COUNT(*)::INTEGER
      INTO exact_match_count
      FROM "product_binary_pair_events" pair_event
      JOIN "product_binary_order_events" order_event
        ON order_event."id" = pair_event."order_event_id"
      WHERE pair_event."normal_commission_id" = NEW."id"
        AND pair_event."recipient_user_id" = NEW."user_id"
        AND pair_event."source_user_id" = NEW."source_user_id"
        AND NEW."source_event_kind" = 'product_order'
        AND order_event."order_id" = NEW."source_event_id"
        AND pair_event."payable_amount" = NEW."amount"
        AND NEW."points" IS NOT NULL
        AND NEW."points"::NUMERIC = pair_event."payable_pairs" * pair_event."pair_rate_points";

      IF exact_match_count <> 1 THEN
        RAISE EXCEPTION 'Product Binary commission has no exact immutable pair entitlement.' USING ERRCODE = '23514';
      END IF;
    ELSE
      SELECT COUNT(*)::INTEGER
      INTO exact_match_count
      FROM "product_binary_pair_events" pair_event
      JOIN "product_binary_order_events" order_event
        ON order_event."id" = pair_event."order_event_id"
      WHERE pair_event."flashout_commission_id" = NEW."id"
        AND pair_event."source_user_id" = NEW."source_user_id"
        AND NEW."source_event_kind" = 'product_order'
        AND order_event."order_id" = NEW."source_event_id"
        AND pair_event."flashout_amount" = NEW."amount"
        AND NEW."points" IS NOT NULL
        AND NEW."points"::NUMERIC =
            (pair_event."cap_flashout_pairs" + pair_event."inactive_flashout_pairs") * pair_event."pair_rate_points"
        AND NEW."overflow_to" = NEW."user_id"
        AND EXISTS (
          SELECT 1 FROM "users" hiroma
          WHERE hiroma."id" = NEW."user_id"
            AND hiroma."username" = 'hiroma'
            AND hiroma."role" = 'admin'::"Role"
        );

      IF exact_match_count <> 1 THEN
        RAISE EXCEPTION 'Retained Product Binary commission has no exact immutable pair entitlement.' USING ERRCODE = '23514';
      END IF;
    END IF;

  ELSIF NEW."type" = 'deactivation_wallet_transfer'::"CommissionType"
        AND NEW."is_pair_overflow" = true THEN
    -- Migration 1450 proves that the complete liquidation occurred. This
    -- complementary check binds its one retained commission to the same
    -- reseller, exact wallet value, rule version, and Hiroma account.
    SELECT COUNT(*)::INTEGER
    INTO exact_match_count
    FROM "reseller_deactivation_events" event
    WHERE event."id" = NEW."source_event_id"
      AND NEW."source_event_kind" = 'deactivation'
      AND NEW."rule_version" = 'reseller-deactivation-v1'
      AND event."reseller_id" = NEW."source_user_id"
      AND event."wallet_value" = NEW."amount"
      AND NEW."overflow_to" = NEW."user_id"
      AND EXISTS (
        SELECT 1 FROM "users" hiroma
        WHERE hiroma."id" = NEW."user_id"
          AND hiroma."username" = 'hiroma'
          AND hiroma."role" = 'admin'::"Role"
      );

    IF exact_match_count <> 1 THEN
      RAISE EXCEPTION 'Retained deactivation transfer has no exact immutable liquidation entitlement.' USING ERRCODE = '23514';
    END IF;

  ELSIF NEW."type" = 'multilevel'::"CommissionType" THEN
    IF NEW.source_event_kind IS DISTINCT FROM 'unilevel_order' OR NEW.rule_version IS DISTINCT FROM 'unilevel-v1'
       OR NEW.is_pair_overflow OR NEW.points IS NOT NULL
       OR NOT EXISTS (
         SELECT 1 FROM public.unilevel_payable_lots lot
         JOIN public.product_binary_order_events event ON event.id=lot.order_event_id
         JOIN public.unilevel_order_allocations allocation ON allocation.order_event_id=lot.order_event_id AND allocation.level=lot.level
         WHERE lot.id::text=NEW.source_event_id AND lot.commission_id=NEW.id AND lot.user_id=NEW.user_id
           AND lot.original_amount=NEW.amount AND event.buyer_user_id=NEW.source_user_id
           AND allocation.user_id=lot.user_id AND allocation.disposition='qualified'
       ) THEN RAISE EXCEPTION 'Unilevel commission requires an exact funded order allocation.' USING ERRCODE='23514'; END IF;
  ELSIF NEW."type" = 'rank_bonus'::"CommissionType" THEN
    IF NEW."source_event_kind" IS DISTINCT FROM 'rank_bonus'
       OR NEW."rule_version" IS DISTINCT FROM 'rank-bonus-v1'
       OR NEW."is_pair_overflow" OR NEW."points" IS NOT NULL OR NEW."source_user_id" IS NOT NULL
       OR NOT EXISTS (
         SELECT 1 FROM public.rank_bonus_awards award
         WHERE award.id::text = NEW."source_event_id"
           AND award.commission_id = NEW."id" AND award.user_id = NEW."user_id"
           AND award.original_amount = NEW."amount"
       ) THEN
      RAISE EXCEPTION 'Rank bonus commission has no exact funded award.' USING ERRCODE = '23514';
    END IF;
  ELSE
    RAISE EXCEPTION 'Spendable commission type has no exact entitlement rule.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_financial_operation_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_financial_operation_receipt() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE beneficiary TEXT;
BEGIN
 IF NEW.kind='registration' THEN
  SELECT reseller_id INTO beneficiary FROM registration_financials WHERE pin_id=NEW.source_id AND city_dist_id=NEW.owner_id;
 ELSE
  SELECT reseller_id INTO beneficiary FROM upgrade_financials WHERE upgrade_pin_id=NEW.source_id AND city_dist_id=NEW.owner_id;
 END IF;
 IF beneficiary IS NULL OR NEW.response->>'success' IS DISTINCT FROM 'true'
  OR NEW.response->'reseller'->>'id' IS DISTINCT FROM beneficiary
  OR NEW.response->>'operation_reference' IS DISTINCT FROM 'FO-'||NEW.id::text
 THEN RAISE EXCEPTION 'Operation receipt must match a completed financial source.' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.actor_id AND status::text='active' AND
   (id=NEW.owner_id OR EXISTS(SELECT 1 FROM staff_profiles s WHERE s.user_id=NEW.actor_id AND s.owner_id=NEW.owner_id
     AND s.is_active AND s.permissions::jsonb ? 'register_reseller')))
 THEN RAISE EXCEPTION 'Operation receipt actor is not authorized.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: validate_financial_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_financial_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'registration_financials' THEN
    IF NEW."customer_payment" < 0 OR NEW."product_acquisition_cost" < 0
       OR NEW."reseller_value" < 0 OR NEW."pin_allocation" < 0
       OR NEW."registration_profit" < 0
       OR NEW."registration_profit" <> NEW."reseller_value" - NEW."product_acquisition_cost"
       OR NEW."customer_payment" <> NEW."reseller_value" + NEW."pin_allocation"
       OR NEW."direct_referral_allocation" < 0 OR NEW."binary_commission_allocation" < 0
       OR NEW."direct_referral_allocation" + NEW."binary_commission_allocation" > NEW."pin_allocation"
       OR NEW."binary_commission_allocation" <> NEW."binary_points_per_pair" * NEW."binary_point_peso_rate"
       OR NEW."payment_status" <> 'paid' THEN
      RAISE EXCEPTION 'Registration financial snapshot is not balanced or fully funded.' USING ERRCODE = '23514';
    END IF;
  ELSIF TG_TABLE_NAME = 'upgrade_financials' THEN
    IF NEW."customer_payment" < 0 OR NEW."product_acquisition_cost" < 0
       OR NEW."reseller_value" < 0 OR NEW."pin_allocation" < 0
       OR NEW."registration_profit" < 0
       OR NEW."registration_profit" <> NEW."reseller_value" - NEW."product_acquisition_cost"
       OR NEW."customer_payment" <> NEW."reseller_value" + NEW."pin_allocation"
       OR NEW."direct_referral_allocation" < 0 OR NEW."direct_referral_paid" <> 0
       OR NEW."direct_referral_retained" <> NEW."direct_referral_allocation"
       OR NEW."binary_commission_allocation" < 0
       OR NEW."direct_referral_retained" + NEW."binary_commission_allocation" > NEW."pin_allocation"
       OR NEW."binary_commission_allocation" <> NEW."binary_points_difference" * 0.5
       OR NEW."payment_status" <> 'paid' THEN
      RAISE EXCEPTION 'Upgrade financial snapshot is not balanced or fully funded.' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_member_id_issuance_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_member_id_issuance_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
  NEW."allocated_at" := transaction_timestamp();
  IF NEW."member_id" <> ('HRM-' || NEW."year" || '-' || lpad(NEW."sequence"::TEXT, 6, '0'))
     OR NEW."year" !~ '^[0-9]{4}$'
     OR NEW."sequence" <= 0 THEN
    RAISE EXCEPTION 'Member ID issuance format and sequence do not match.' USING ERRCODE = '23514';
  END IF;

  INSERT INTO "member_id_sequences" ("year", "last_sequence")
  VALUES (NEW."year", NEW."sequence")
  ON CONFLICT ("year") DO UPDATE
  SET "last_sequence" = GREATEST(
    "member_id_sequences"."last_sequence",
    EXCLUDED."last_sequence"
  );
  RETURN NEW;
END;
$_$;


--
-- Name: validate_new_commission_provenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_new_commission_provenance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."event_key" IS NULL OR length(btrim(NEW."event_key")) = 0 THEN
    RAISE EXCEPTION 'Every commission requires an idempotent event key.' USING ERRCODE = '23514';
  END IF;
  IF NEW."source_event_kind" IS NULL OR length(btrim(NEW."source_event_kind")) = 0
     OR NEW."source_event_id" IS NULL OR length(btrim(NEW."source_event_id")) = 0
     OR NEW."rule_version" IS NULL OR length(btrim(NEW."rule_version")) = 0 THEN
    RAISE EXCEPTION 'Every commission requires immutable source provenance and a rule version.' USING ERRCODE = '23514';
  END IF;
  IF NEW."amount" <= 0 THEN
    RAISE EXCEPTION 'Commission amount must be positive.' USING ERRCODE = '23514';
  END IF;
  IF NEW."is_pair_overflow" = false
     AND NEW."type" NOT IN (
       'direct_referral'::"CommissionType",
       'binary_pairing'::"CommissionType",
       'sponsor_point'::"CommissionType",
       'rank_bonus'::"CommissionType",
       'multilevel'::"CommissionType"
     ) THEN
    RAISE EXCEPTION 'Unsupported commission type cannot become spendable.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_new_pin_request_payment_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_new_pin_request_payment_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  recipient RECORD;
BEGIN
  SELECT users."role"::text AS role, users."status"::text AS status,
         profiles."dist_level"::text AS level, profiles."is_active" AS profile_active
  INTO recipient
  FROM "users" users
  LEFT JOIN "distributor_profiles" profiles ON profiles."user_id" = users."id"
  WHERE users."id" = NEW."city_dist_id";

  IF recipient.role <> 'city'
     OR recipient.status <> 'active'
     OR recipient.level <> 'city'
     OR recipient.profile_active IS NOT TRUE
     OR NEW."payment_method" NOT IN ('gcash', 'bank_transfer')
     OR NULLIF(TRIM(NEW."payment_method_id"), '') IS NULL
     OR NEW."payment_destination_snapshot" IS NULL
     OR NEW."payment_status" <> 'awaiting_payment'
     OR NEW."payment_reference" IS NOT NULL
     OR NEW."payment_sender_name" IS NOT NULL
     OR NEW."payment_datetime" IS NOT NULL
     OR NEW."payment_due_at" IS NULL
     OR ABS(EXTRACT(EPOCH FROM (NEW."payment_due_at" - NEW."created_at")) - 172800) > 5 THEN
    RAISE EXCEPTION 'New City PIN requests require an approved payment destination and an exact 48-hour unpaid reservation.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_package_binary_product_reward(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_package_binary_product_reward() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF pg_trigger_depth() < 2 OR NOT EXISTS (
    SELECT 1 FROM binary_pair_events e JOIN products p ON p.id=e.reward_product_id
    WHERE e.id=NEW.pair_event_id AND e.recipient_user_id=NEW.user_id
      AND e.reward_product_id=NEW.product_id AND e.product_reward_pairs=NEW.quantity
      AND NEW.product_name_snapshot=p.name AND NEW.unit_cost_snapshot=p.cost_price
  ) THEN RAISE EXCEPTION 'Product rewards require an exact Package Binary entitlement.' USING ERRCODE='23514'; END IF;
  RETURN NEW;
END $$;


--
-- Name: validate_package_upgrade_path_ordering(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_package_upgrade_path_ordering() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  source RECORD;
  target RECORD;
  required_funding DECIMAL(12,2);
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('package-upgrade-funding-configuration'));
  IF NOT NEW."is_active" THEN
    RETURN NEW;
  END IF;

  SELECT "id", "price", "direct_referral_bonus", "pairing_bonus_value", "is_active"
  INTO source
  FROM "packages"
  WHERE "id" = NEW."from_package_id"
  FOR SHARE;

  SELECT "id", "price", "direct_referral_bonus", "pairing_bonus_value", "is_active"
  INTO target
  FROM "packages"
  WHERE "id" = NEW."to_package_id"
  FOR SHARE;

  IF source."id" IS NULL OR target."id" IS NULL
     OR NOT source."is_active" OR NOT target."is_active"
     OR source."price" >= target."price"
     OR source."pairing_bonus_value" >= target."pairing_bonus_value" THEN
    RAISE EXCEPTION 'Upgrade source must be an active package lower than its active target in both price and Package Binary points.' USING ERRCODE = '23514';
  END IF;

  required_funding :=
    GREATEST(target."direct_referral_bonus" - source."direct_referral_bonus", 0)
    + GREATEST(target."pairing_bonus_value" - source."pairing_bonus_value", 0) * 0.50;
  IF NEW."pin_price" < required_funding THEN
    RAISE EXCEPTION 'Upgrade PIN price cannot fund its incremental retained-direct and Package Binary allocation.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_pin_paid_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_pin_paid_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."status" IN ('in_transit'::"PinStatus", 'unused'::"PinStatus", 'used'::"PinStatus")
     AND NEW."pin_allocation_snapshot" IS NOT NULL
     AND NOT "pin_has_exact_paid_source"(NEW."id") THEN
    RAISE EXCEPTION 'PIN is not backed by exactly one paid source or accepted zero-revenue custody transfer.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_pin_transfer_batch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_pin_transfer_batch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  linked_count INTEGER;
  linked_total DECIMAL(12,2);
  invalid_count INTEGER;
BEGIN
  SELECT COUNT(*)::INTEGER,
         COALESCE(SUM("pin_allocation_snapshot"), 0)::DECIMAL(12,2),
         COUNT(*) FILTER (
           WHERE ("funding_order_id" IS NOT NULL OR "funding_pin_request_id" IS NOT NULL)
             OR ("status" = 'in_transit'::"PinStatus" AND NEW."status" <> 'in_transit')
             OR ("status" = 'unused'::"PinStatus" AND NEW."status" <> 'received')
             OR ("status" NOT IN ('in_transit'::"PinStatus", 'unused'::"PinStatus")
                 AND NEW."status" IN ('in_transit', 'received'))
             OR (NEW."status" = 'rejected' AND (
                  "status" <> 'cancelled'::"PinStatus"
                  OR "cancellation_disposition" <> 'internal_transfer_rejected'
                ))
         )::INTEGER
  INTO linked_count, linked_total, invalid_count
  FROM "pins" WHERE "funding_pin_transfer_id" = NEW."id";
  IF linked_count <> NEW."quantity"
     OR linked_total <> NEW."reference_value"
     OR invalid_count <> 0 THEN
    RAISE EXCEPTION 'PIN transfer batch is incomplete or its custody states are inconsistent.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_funding_lot_balance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_funding_lot_balance() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  lot public.product_binary_funding_lots;
  consumed numeric;
BEGIN
  SELECT * INTO STRICT lot FROM public.product_binary_funding_lots WHERE id = NEW.id;
  IF lot.reconciliation_status <> 'exact'
     OR NEW.remaining_amount IS DISTINCT FROM lot.remaining_amount THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(SUM(amount), 0) INTO consumed
  FROM public.product_binary_funding_consumptions WHERE funding_lot_id = lot.id AND NOT is_unfunded;
  IF lot.remaining_amount IS DISTINCT FROM lot.original_amount - consumed THEN
    RAISE EXCEPTION 'Product Binary funding-lot balance does not reconcile to append-only consumption.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_funding_lot_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_funding_lot_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  source_order RECORD;
  item_count INTEGER;
  exact_item_count INTEGER;
  expected_units INTEGER;
  expected_pu INTEGER;
  expected_margin DECIMAL(12,2);
  expected_allocation DECIMAL(12,2);
BEGIN
  SELECT orders."status"::text AS order_status, orders."payment_status", orders."financial_purpose",
         orders."paid_at", orders."delivered_at", seller."role"::text AS seller_role
  INTO source_order
  FROM "orders" orders
  JOIN "users" seller ON seller."id" = orders."seller_id"
  WHERE orders."id" = NEW."order_id"
  FOR SHARE OF orders, seller;

  SELECT COUNT(*)::INTEGER,
         COUNT(*) FILTER (WHERE item."snapshot_source" = 'product-binary-order-v1'
           AND item."binary_eligible_snapshot" IS NOT NULL AND item."pu_value_snapshot" IS NOT NULL
           AND item."company_unit_cost_snapshot" IS NOT NULL AND item."company_unit_margin_snapshot" IS NOT NULL
           AND item."snapshotted_at" IS NOT NULL)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" ELSE 0 END),0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * item."pu_value_snapshot" ELSE 0 END),0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * item."company_unit_margin_snapshot" ELSE 0 END),0)::DECIMAL(12,2)
  INTO item_count, exact_item_count, expected_units, expected_pu, expected_margin
  FROM "order_items" item WHERE item."order_id" = NEW."order_id";

  expected_allocation := LEAST(GREATEST(0, expected_margin), expected_units * 20.00);
  IF NEW."order_id" IS NULL OR NEW."inventory_movement_id" IS NOT NULL
     OR source_order.order_status IS NULL
     OR source_order.order_status <> 'delivered' OR source_order.payment_status <> 'paid'
     OR source_order.financial_purpose <> 'commerce' OR source_order.seller_role <> 'admin'
     OR source_order.paid_at IS NULL OR source_order.delivered_at IS NULL
     OR item_count = 0 OR exact_item_count <> item_count
     OR NEW."snapshot_source" <> 'paid-delivered-admin-order'
     OR NEW."reconciliation_status" <> 'exact'
     OR NEW."snapshot_version" <> 'product-binary-order-v1'
     OR NEW."payment_status_snapshot" <> 'paid'
     OR NEW."paid_at_snapshot" IS DISTINCT FROM source_order.paid_at
     OR NEW."delivered_at_snapshot" IS DISTINCT FROM source_order.delivered_at
     OR NEW."eligible_units_snapshot" IS DISTINCT FROM expected_units
     OR NEW."total_pu_snapshot" IS DISTINCT FROM expected_pu
     OR NEW."gross_margin_snapshot" IS DISTINCT FROM expected_margin
     OR NEW."original_amount" IS DISTINCT FROM expected_allocation
     OR NEW."remaining_amount" IS DISTINCT FROM expected_allocation THEN
    RAISE EXCEPTION 'Product Binary funding lot does not match one exact paid-delivered Admin order.' USING ERRCODE = '23514';
  END IF;

  NEW."allocated_at" := GREATEST(source_order.paid_at, source_order.delivered_at);
  NEW."created_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_job_completion(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_job_completion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  exact_order_event_count INTEGER;
BEGIN
  IF NEW."status" <> 'completed' THEN
    RETURN NEW;
  END IF;
  IF NEW."completed_at" IS NULL OR NEW."payment_status_snapshot" <> 'paid'
     OR NEW."paid_at_snapshot" IS NULL OR NEW."delivered_at_snapshot" IS NULL
     OR NEW."snapshot_version" <> 'product-binary-order-v1' THEN
    RAISE EXCEPTION 'Completed Product Binary job lacks exact paid-delivered snapshots.' USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(*)::INTEGER INTO exact_order_event_count
  FROM "product_binary_order_events" event
  WHERE event."settlement_job_id" = NEW."id"
    AND event."order_id" = NEW."order_id"
    AND event."buyer_user_id" = NEW."buyer_user_id"
    AND event."eligible_units" = NEW."eligible_units_snapshot"
    AND event."total_pu" = NEW."total_pu_snapshot"
    AND event."recorded_gross_margin" = NEW."gross_margin_snapshot"
    AND event."snapshot_version" = NEW."snapshot_version";

  IF NEW."qualification_status" = 'qualified_paid_delivery'
     AND NEW."total_pu_snapshot" > 0
     AND exact_order_event_count <> 1 THEN
    RAISE EXCEPTION 'Positive-PU completed job must bind one exact snapshotted order event.' USING ERRCODE = '23514';
  ELSIF NEW."qualification_status" = 'ineligible_zero_pu'
     AND NEW."total_pu_snapshot" = 0
     AND exact_order_event_count <> 0 THEN
    RAISE EXCEPTION 'Auditable zero-PU job cannot claim a Product Binary order event.' USING ERRCODE = '23514';
  ELSIF NEW."qualification_status" NOT IN ('qualified_paid_delivery', 'ineligible_zero_pu', 'legacy_completed') THEN
    RAISE EXCEPTION 'Unqualified Product Binary job cannot complete.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_job_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_job_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  source_order RECORD;
  item_count INTEGER;
  exact_item_count INTEGER;
  expected_units INTEGER;
  expected_pu INTEGER;
  expected_margin DECIMAL(12,2);
  expected_qualification TEXT;
BEGIN
  IF NEW."qualification_status" NOT IN ('qualified_paid_delivery', 'ineligible_zero_pu') THEN
    IF NEW."status" = 'completed' AND NEW."qualification_status" <> 'legacy_completed' THEN
      RAISE EXCEPTION 'A non-qualified Product Binary job cannot complete.' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  SELECT orders."buyer_id", buyer."role"::text AS buyer_role, orders."status"::text AS order_status,
         orders."payment_status", orders."financial_purpose", orders."paid_at", orders."delivered_at"
  INTO source_order
  FROM "orders" orders
  JOIN "users" buyer ON buyer."id" = orders."buyer_id"
  WHERE orders."id" = NEW."order_id"
  FOR SHARE OF orders, buyer;

  SELECT COUNT(*)::INTEGER,
         COUNT(*) FILTER (WHERE item."snapshot_source" = 'product-binary-order-v1'
           AND item."binary_eligible_snapshot" IS NOT NULL AND item."pu_value_snapshot" IS NOT NULL
           AND item."company_unit_cost_snapshot" IS NOT NULL AND item."company_unit_margin_snapshot" IS NOT NULL
           AND item."snapshotted_at" IS NOT NULL)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" ELSE 0 END),0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * item."pu_value_snapshot" ELSE 0 END),0)::INTEGER,
         COALESCE(SUM(CASE WHEN item."binary_eligible_snapshot" AND item."pu_value_snapshot" > 0
                           THEN item."quantity" * GREATEST(0, item."unit_price" - COALESCE(item."unit_acquisition_cost", item."company_unit_cost_snapshot"))
                           ELSE 0 END),0)::DECIMAL(12,2)
  INTO item_count, exact_item_count, expected_units, expected_pu, expected_margin
  FROM "order_items" item WHERE item."order_id" = NEW."order_id";

  expected_qualification := CASE WHEN expected_pu > 0
    THEN 'qualified_paid_delivery' ELSE 'ineligible_zero_pu' END;
  IF source_order.order_status IS NULL
     OR source_order.buyer_role <> 'reseller' OR source_order.order_status <> 'delivered'
     OR source_order.payment_status <> 'paid' OR source_order.financial_purpose <> 'commerce'
     OR source_order.paid_at IS NULL OR source_order.delivered_at IS NULL
     OR item_count = 0 OR exact_item_count <> item_count
     OR NEW."buyer_user_id" IS DISTINCT FROM source_order.buyer_id
     OR NEW."payment_status_snapshot" <> 'paid'
     OR NEW."paid_at_snapshot" IS DISTINCT FROM source_order.paid_at
     OR NEW."delivered_at_snapshot" IS DISTINCT FROM source_order.delivered_at
     OR NEW."eligible_units_snapshot" IS DISTINCT FROM expected_units
     OR NEW."total_pu_snapshot" IS DISTINCT FROM expected_pu
     OR NEW."gross_margin_snapshot" IS DISTINCT FROM expected_margin
     OR NEW."snapshot_version" <> 'product-binary-order-v1'
     OR NEW."qualification_status" <> expected_qualification
     OR (expected_pu > 0 AND NEW."status" NOT IN ('pending','failed','completed'))
     OR (expected_pu = 0 AND NEW."status" <> 'completed') THEN
    RAISE EXCEPTION 'Product Binary settlement job does not match one exact paid-delivered reseller order.' USING ERRCODE = '23514';
  END IF;

  IF TG_OP = 'INSERT' OR OLD."qualification_status" NOT IN ('qualified_paid_delivery', 'ineligible_zero_pu') THEN
    NEW."qualified_at" := transaction_timestamp();
  ELSIF NEW."qualified_at" IS DISTINCT FROM OLD."qualified_at" THEN
    RAISE EXCEPTION 'Product Binary qualification timestamp is immutable.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_order_event_completeness(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_order_event_completeness() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  ancestor_set_mismatch BOOLEAN;
BEGIN
  WITH RECURSIVE ancestor_chain AS (
    SELECT parent."id", parent."user_id", parent."parent_id"
    FROM "binary_tree_nodes" source
    JOIN "binary_tree_nodes" parent ON parent."id" = source."parent_id"
    WHERE source."user_id" = NEW."buyer_user_id"

    UNION ALL

    SELECT parent."id", parent."user_id", parent."parent_id"
    FROM ancestor_chain child
    JOIN "binary_tree_nodes" parent ON parent."id" = child."parent_id"
  ),
  expected_recipients AS (
    SELECT chain."user_id"
    FROM ancestor_chain chain
    JOIN "reseller_profiles" profile ON profile."user_id" = chain."user_id"
  ),
  recorded_recipients AS (
    SELECT event."recipient_user_id" AS "user_id"
    FROM "product_binary_pair_events" event
    WHERE event."order_event_id" = NEW."id"
  )
  SELECT EXISTS (
    (SELECT expected."user_id" FROM expected_recipients expected
     EXCEPT
     SELECT recorded."user_id" FROM recorded_recipients recorded)
    UNION ALL
    (SELECT recorded."user_id" FROM recorded_recipients recorded
     EXCEPT
     SELECT expected."user_id" FROM expected_recipients expected)
  )
  INTO ancestor_set_mismatch;

  IF ancestor_set_mismatch THEN
    RAISE EXCEPTION 'Product Binary order event does not contain one exact volume event for every eligible ancestor.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_order_event_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_order_event_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  source_job RECORD;
BEGIN
  SELECT job.* INTO source_job
  FROM "product_binary_settlement_jobs" job
  WHERE job."id" = NEW."settlement_job_id"
    AND job."order_id" = NEW."order_id"
  FOR SHARE;

  IF NOT FOUND
     OR source_job."status" NOT IN ('pending', 'failed')
     OR source_job."qualification_status" <> 'qualified_paid_delivery'
     OR source_job."snapshot_version" <> 'product-binary-order-v1'
     OR source_job."payment_status_snapshot" <> 'paid'
     OR source_job."paid_at_snapshot" IS NULL
     OR source_job."delivered_at_snapshot" IS NULL
     OR source_job."total_pu_snapshot" <= 0
     OR NEW."buyer_user_id" IS DISTINCT FROM source_job."buyer_user_id"
     OR NEW."eligible_units" IS DISTINCT FROM source_job."eligible_units_snapshot"
     OR NEW."total_pu" IS DISTINCT FROM source_job."total_pu_snapshot"
     OR NEW."recorded_gross_margin" IS DISTINCT FROM source_job."gross_margin_snapshot" THEN
    RAISE EXCEPTION 'Product Binary event does not match one exact paid-delivered order qualification.' USING ERRCODE = '23514';
  END IF;

  NEW."payment_status_snapshot" := source_job."payment_status_snapshot";
  NEW."paid_at_snapshot" := source_job."paid_at_snapshot";
  NEW."delivered_at_snapshot" := source_job."delivered_at_snapshot";
  NEW."snapshot_version" := source_job."snapshot_version";
  NEW."processed_at" := transaction_timestamp();
  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_pair_event_closing_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_pair_event_closing_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  applied_left_pu INTEGER;
  applied_right_pu INTEGER;
  applied_lifetime_pairs INTEGER;
  applied_lifetime_payable INTEGER;
  applied_lifetime_flashout INTEGER;
BEGIN
  SELECT position."left_carryover_pu", position."right_carryover_pu",
         position."lifetime_pairs", position."lifetime_payable",
         position."lifetime_flashout"
  INTO applied_left_pu, applied_right_pu, applied_lifetime_pairs,
       applied_lifetime_payable, applied_lifetime_flashout
  FROM "product_binary_positions" position
  WHERE position."user_id" = NEW."recipient_user_id"
  FOR SHARE;

  IF NOT FOUND
     OR applied_left_pu IS DISTINCT FROM NEW."closing_left_pu"
     OR applied_right_pu IS DISTINCT FROM NEW."closing_right_pu"
     OR applied_lifetime_pairs IS DISTINCT FROM NEW."closing_lifetime_pairs"
     OR applied_lifetime_payable IS DISTINCT FROM NEW."closing_lifetime_payable"
     OR applied_lifetime_flashout IS DISTINCT FROM NEW."closing_lifetime_flashout" THEN
    RAISE EXCEPTION 'Product Binary event closing carryover/lifetime state was not applied atomically.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_product_binary_pair_event_entitlement(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_product_binary_pair_event_entitlement() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  source_buyer_user_id TEXT;
  source_total_pu INTEGER;
  expected_recipient_leg TEXT;
  current_left_pu INTEGER;
  current_right_pu INTEGER;
  current_lifetime_pairs INTEGER;
  current_lifetime_payable INTEGER;
  current_lifetime_flashout INTEGER;
  available_left_pu INTEGER;
  incoming_pu INTEGER;
  available_right_pu INTEGER;
  expected_package_id TEXT;
  expected_package_name TEXT;
  recipient_total_pu INTEGER;
  expected_rank_id TEXT;
  expected_rank_name TEXT;
  package_rate_points NUMERIC;
  rank_rate_points NUMERIC;
  required_pu_per_leg INTEGER;
  weekly_pool BOOLEAN;
  expected_pair_rate_amount NUMERIC;
  expected_pair_rate_points NUMERIC;
  expected_user_status TEXT;
  expected_cap_enabled BOOLEAN;
  expected_cap_limit INTEGER;
  used_today INTEGER;
  expected_payable_pairs INTEGER;
  expected_cap_flashout_pairs INTEGER;
  expected_inactive_flashout_pairs INTEGER;
BEGIN
  -- Serialize even direct SQL callers on the same key used by the worker.
  PERFORM pg_advisory_xact_lock(hashtext('product-binary-user:' || NEW."recipient_user_id"));

  SELECT event."buyer_user_id", event."total_pu"
  INTO source_buyer_user_id, source_total_pu
  FROM "product_binary_order_events" event
  WHERE event."id" = NEW."order_event_id"
  FOR SHARE;

  IF source_buyer_user_id IS NULL
     OR NEW."source_user_id" IS DISTINCT FROM source_buyer_user_id
     OR NEW."source_pu" IS DISTINCT FROM source_total_pu THEN
    RAISE EXCEPTION 'Product Binary pair event does not match its order event source.' USING ERRCODE = '23514';
  END IF;

  WITH RECURSIVE ancestor_chain AS (
    SELECT parent."id", parent."user_id", parent."parent_id", parent."position",
           source."position"::text AS effective_leg
    FROM "binary_tree_nodes" source
    JOIN "binary_tree_nodes" parent ON parent."id" = source."parent_id"
    WHERE source."user_id" = source_buyer_user_id

    UNION ALL

    SELECT parent."id", parent."user_id", parent."parent_id", parent."position",
           child."position"::text AS effective_leg
    FROM ancestor_chain child
    JOIN "binary_tree_nodes" parent ON parent."id" = child."parent_id"
  )
  SELECT chain.effective_leg
  INTO expected_recipient_leg
  FROM ancestor_chain chain
  WHERE chain."user_id" = NEW."recipient_user_id"
  LIMIT 1;

  IF expected_recipient_leg IS NULL OR NEW."source_leg" IS DISTINCT FROM expected_recipient_leg THEN
    RAISE EXCEPTION 'Product Binary recipient is not an ancestor on the source order leg.' USING ERRCODE = '23514';
  END IF;

  SELECT profile."package_id", package."name", COALESCE(profile."total_pu", 0),
         package."point_php_value", recipient."status"::text,
         COALESCE(package."product_binary_cap_enabled", true),
         GREATEST(0, COALESCE(package."daily_product_pairing_cap", 50))::INTEGER
  INTO expected_package_id, expected_package_name, recipient_total_pu,
       package_rate_points, expected_user_status, expected_cap_enabled,
       expected_cap_limit
  FROM "reseller_profiles" profile
  JOIN "packages" package ON package."id" = profile."package_id"
  JOIN "users" recipient ON recipient."id" = profile."user_id"
  WHERE profile."user_id" = NEW."recipient_user_id"
  FOR SHARE OF profile, package, recipient;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Product Binary recipient has no package profile.' USING ERRCODE = '23503';
  END IF;

  SELECT rank."id", rank."name", rank."pair_income"
  INTO expected_rank_id, expected_rank_name, rank_rate_points
  FROM "ranks" rank
  WHERE rank."package_id" = expected_package_id
    AND rank."required_pu" <= recipient_total_pu
  ORDER BY rank."sequence" DESC
  LIMIT 1
  FOR SHARE;

  IF NOT FOUND THEN
    expected_rank_id := NULL;
    expected_rank_name := 'Default';
  END IF;

  SELECT COALESCE((SELECT value::integer FROM public.system_settings WHERE key = 'product_binary_pu_per_leg'), 2) INTO required_pu_per_leg;
  SELECT EXISTS (SELECT 1 FROM public.product_binary_pool_orders WHERE order_event_id=NEW.order_event_id) INTO weekly_pool;
  IF weekly_pool THEN
    expected_cap_enabled := false;
    expected_cap_limit := NULL;
  END IF;
  expected_pair_rate_amount := public.product_binary_pair_amount();
  expected_pair_rate_points := expected_pair_rate_amount / 0.5;

  SELECT position."left_carryover_pu", position."right_carryover_pu",
         position."lifetime_pairs", position."lifetime_payable",
         position."lifetime_flashout"
  INTO current_left_pu, current_right_pu, current_lifetime_pairs,
       current_lifetime_payable, current_lifetime_flashout
  FROM "product_binary_positions" position
  WHERE position."user_id" = NEW."recipient_user_id"
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Product Binary recipient has no locked carryover position.' USING ERRCODE = '23503';
  END IF;

  SELECT COALESCE(SUM(event."payable_pairs"), 0)::INTEGER
  INTO used_today
  FROM "product_binary_pair_events" event
  WHERE event."recipient_user_id" = NEW."recipient_user_id"
    AND (event."created_at" AT TIME ZONE 'Asia/Manila')::date =
        (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date;

  IF (weekly_pool AND NOT public.product_binary_weekly_pair_eligible(NEW.recipient_user_id))
      OR (NOT weekly_pool AND expected_user_status <> 'active') THEN
    expected_payable_pairs := 0;
    expected_cap_flashout_pairs := 0;
    expected_inactive_flashout_pairs := NEW."completed_pairs";
  ELSIF NOT expected_cap_enabled THEN
    expected_payable_pairs := NEW."completed_pairs";
    expected_cap_flashout_pairs := 0;
    expected_inactive_flashout_pairs := 0;
  ELSE
    expected_payable_pairs := LEAST(
      NEW."completed_pairs",
      GREATEST(0, expected_cap_limit - used_today)
    );
    expected_cap_flashout_pairs := NEW."completed_pairs" - expected_payable_pairs;
    expected_inactive_flashout_pairs := 0;
  END IF;

  IF NEW."completed_pairs" < 0
     OR NEW."source_pu" <= 0
     OR NEW."pair_rate_points" < 0
     OR NEW."pair_rate_points" IS DISTINCT FROM expected_pair_rate_points
     OR NEW."peso_per_point" <= 0
     OR NEW."peso_per_point" IS DISTINCT FROM 0.5
     OR NEW."package_id_snapshot" IS DISTINCT FROM expected_package_id
     OR NEW."package_name_snapshot" IS DISTINCT FROM expected_package_name
     OR NEW."rank_id_snapshot" IS DISTINCT FROM expected_rank_id
     OR NEW."rank_name_snapshot" IS DISTINCT FROM expected_rank_name
     OR (NEW."created_at" AT TIME ZONE 'Asia/Manila')::date IS DISTINCT FROM
          (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila')::date
     OR NEW."pair_rate_amount" IS DISTINCT FROM expected_pair_rate_amount
     OR NEW."pair_rate_amount" IS DISTINCT FROM NEW."pair_rate_points" * NEW."peso_per_point"
     OR NEW."payable_amount" IS DISTINCT FROM (CASE WHEN weekly_pool THEN 0 ELSE NEW."payable_pairs" * NEW."pair_rate_amount" END)
     OR NEW."flashout_amount" IS DISTINCT FROM
          (CASE WHEN weekly_pool THEN 0 ELSE
            (NEW."cap_flashout_pairs" + NEW."inactive_flashout_pairs") * NEW."pair_rate_amount" END)
     OR NEW."cap_enabled" IS DISTINCT FROM expected_cap_enabled
     OR NEW."cap_limit" IS DISTINCT FROM
          (CASE WHEN expected_cap_enabled THEN expected_cap_limit ELSE NULL END)
     OR NEW."payable_pairs" IS DISTINCT FROM expected_payable_pairs
     OR NEW."cap_flashout_pairs" IS DISTINCT FROM expected_cap_flashout_pairs
     OR NEW."inactive_flashout_pairs" IS DISTINCT FROM expected_inactive_flashout_pairs
     OR (NEW."payable_amount" > 0) IS DISTINCT FROM (NEW."normal_commission_id" IS NOT NULL)
     OR (NEW."flashout_amount" > 0) IS DISTINCT FROM (NEW."flashout_commission_id" IS NOT NULL) THEN
    RAISE EXCEPTION 'Product Binary pair amounts or commission links are inconsistent.' USING ERRCODE = '23514';
  END IF;

  -- The app posts and expires the incoming lot before inserting the pair event.
  SELECT remaining_pu INTO STRICT incoming_pu
  FROM public.product_binary_pu_lots
  WHERE order_event_id = NEW.order_event_id AND recipient_user_id = NEW.recipient_user_id
    AND leg = NEW.source_leg AND original_pu = NEW.source_pu;

  available_left_pu := current_left_pu;
  available_right_pu := current_right_pu;
  IF NEW."opening_left_pu" IS DISTINCT FROM current_left_pu - (CASE WHEN NEW.source_leg = 'left' THEN incoming_pu ELSE 0 END)
     OR NEW."opening_right_pu" IS DISTINCT FROM current_right_pu - (CASE WHEN NEW.source_leg = 'right' THEN incoming_pu ELSE 0 END)
     OR NEW."opening_lifetime_pairs" IS DISTINCT FROM current_lifetime_pairs
     OR NEW."opening_lifetime_payable" IS DISTINCT FROM current_lifetime_payable
     OR NEW."opening_lifetime_flashout" IS DISTINCT FROM current_lifetime_flashout
     OR NEW."opening_left_pu" < 0 OR NEW."opening_right_pu" < 0
     OR NEW."closing_left_pu" < 0 OR NEW."closing_right_pu" < 0
     OR NEW."completed_pairs" IS DISTINCT FROM LEAST(available_left_pu, available_right_pu) / required_pu_per_leg
     OR NEW."closing_left_pu" IS DISTINCT FROM available_left_pu - NEW."completed_pairs" * required_pu_per_leg
     OR NEW."closing_right_pu" IS DISTINCT FROM available_right_pu - NEW."completed_pairs" * required_pu_per_leg
     OR NEW."closing_lifetime_pairs" IS DISTINCT FROM current_lifetime_pairs + NEW."completed_pairs"
     OR NEW."closing_lifetime_payable" IS DISTINCT FROM current_lifetime_payable + NEW."payable_pairs"
     OR NEW."closing_lifetime_flashout" IS DISTINCT FROM current_lifetime_flashout
          + NEW."cap_flashout_pairs" + NEW."inactive_flashout_pairs" THEN
    RAISE EXCEPTION 'Product Binary pair does not reconcile to locked carryover and exact source PU.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: validate_registration_financial_against_pin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_registration_financial_against_pin() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
  issued_units INTEGER;
BEGIN
  SELECT * INTO issued FROM "pins" WHERE "id" = NEW."pin_id" FOR SHARE;
  IF NOT FOUND OR issued."pin_type" <> 'registration'
     OR issued."status" <> 'used'::"PinStatus"
     OR issued."used_at" IS NULL
     OR issued."used_by" IS DISTINCT FROM NEW."reseller_id"
     OR NOT "pin_has_exact_paid_source"(issued."id") THEN
    RAISE EXCEPTION 'Registration financial source PIN is invalid.' USING ERRCODE = '23514';
  END IF;
  SELECT COALESCE(SUM("quantity"), 0)::INTEGER INTO issued_units
  FROM "pin_registration_product_snapshots" WHERE "pin_id" = NEW."pin_id";

  IF issued."city_dist_id" <> NEW."city_dist_id"
     OR issued."package_id" <> NEW."package_id"
     OR issued."registration_package_name_snapshot" IS NULL
     OR NEW."customer_payment" <> issued."registration_customer_payment_snapshot"
     OR NEW."product_acquisition_cost" <> issued."registration_acquisition_cost_snapshot"
     OR NEW."reseller_value" <> issued."registration_reseller_value_snapshot"
     OR NEW."pin_allocation" <> issued."pin_allocation_snapshot"
     OR NEW."registration_profit" <> issued."registration_reseller_value_snapshot" - issued."registration_acquisition_cost_snapshot"
     OR NEW."package_name_snapshot" <> issued."registration_package_name_snapshot"
     OR issued_units <> issued."registration_units_snapshot"
     OR NEW."package_units_snapshot" <> issued."registration_units_snapshot"
     OR NEW."direct_referral_allocation" <> issued."registration_direct_allocation_snapshot"
     OR NEW."binary_commission_allocation" <> issued."registration_binary_allocation_snapshot"
     OR NEW."binary_points_per_pair" <> issued."registration_points_snapshot"
     OR NEW."binary_point_peso_rate" <> 0.5
     OR NEW."allocation_snapshot_source" <> 'registration'
     OR NEW."payment_status" <> 'paid'
     OR NEW."paid_at" IS NULL THEN
    RAISE EXCEPTION 'Registration financial record does not exactly match its issued PIN snapshot.' USING ERRCODE = '23514';
  END IF;
  IF EXISTS (SELECT 1 FROM "pos_registration_intakes" WHERE "pin_id" = issued."id")
     AND NOT EXISTS (
       SELECT 1 FROM "pos_registration_intakes" intake
       WHERE intake."pin_id" = issued."id"
         AND intake."owner_id" = NEW."city_dist_id"
         AND intake."package_id" = NEW."package_id"
         AND intake."amount_snapshot" = NEW."customer_payment"
         AND intake."registration_snapshot" IS NOT NULL
         AND intake."status" IN (
           'encoding_in_progress'::"PosRegistrationIntakeStatus",
           'registration_completed'::"PosRegistrationIntakeStatus"
         )
     ) THEN
    RAISE EXCEPTION 'POS registration funding handoff is not bound to this PIN transaction.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_registration_pin_after_product_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_registration_pin_after_product_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
  totals RECORD;
BEGIN
  SELECT * INTO issued FROM "pins" WHERE "id" = NEW."pin_id";
  IF NOT FOUND OR issued."pin_type" <> 'registration'
     OR issued."status" NOT IN ('unused'::"PinStatus", 'in_transit'::"PinStatus") THEN
    RAISE EXCEPTION 'Registration product snapshots belong only to a newly issued unused or in-transit registration PIN.' USING ERRCODE = '23514';
  END IF;
  SELECT
    COUNT(*)::INTEGER AS product_count,
    COALESCE(SUM("quantity"), 0)::INTEGER AS units,
    COALESCE(SUM("srp_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS customer_payment,
    COALESCE(SUM("reseller_price_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS reseller_value,
    COALESCE(SUM("unit_acquisition_cost_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS acquisition_cost
  INTO totals
  FROM "pin_registration_product_snapshots" WHERE "pin_id" = NEW."pin_id";
  IF totals.product_count <> issued."registration_product_line_count_snapshot"
     OR totals.units <> issued."registration_units_snapshot"
     OR totals.customer_payment <> issued."registration_customer_payment_snapshot"
     OR totals.reseller_value <> issued."registration_reseller_value_snapshot"
     OR totals.acquisition_cost <> issued."registration_acquisition_cost_snapshot" THEN
    RAISE EXCEPTION 'Registration PIN product rows do not match the immutable PIN totals.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_registration_pin_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_registration_pin_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  totals RECORD;
BEGIN
  IF NEW."pin_type" <> 'registration' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT'
     AND NEW."status" NOT IN ('unused'::"PinStatus", 'in_transit'::"PinStatus") THEN
    RAISE EXCEPTION 'A registration PIN must be issued unused or in transit with a complete immutable snapshot.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'UPDATE' AND NEW."status" IN ('cancelled'::"PinStatus", 'expired'::"PinStatus") THEN
    RETURN NEW;
  END IF;
  IF NEW."pin_allocation_snapshot" IS NULL
     OR NEW."registration_package_name_snapshot" IS NULL
     OR NEW."registration_customer_payment_snapshot" IS NULL
     OR NEW."registration_reseller_value_snapshot" IS NULL
     OR NEW."registration_acquisition_cost_snapshot" IS NULL
     OR NEW."registration_acquisition_tier_snapshot" IS NULL
     OR NEW."registration_acquisition_tier_snapshot" NOT IN ('admin', 'city', 'branch')
     OR NEW."registration_direct_allocation_snapshot" IS NULL
     OR NEW."registration_binary_allocation_snapshot" IS NULL
     OR NEW."registration_points_snapshot" IS NULL
     OR NEW."registration_points_snapshot" <= 0
     OR NEW."registration_product_line_count_snapshot" IS NULL
     OR NEW."registration_product_line_count_snapshot" <= 0
     OR NEW."registration_units_snapshot" IS NULL
     OR NEW."registration_units_snapshot" <= 0
     OR NEW."registration_customer_payment_snapshot" <> NEW."registration_reseller_value_snapshot" + NEW."pin_allocation_snapshot"
     OR NEW."registration_binary_allocation_snapshot" <> NEW."registration_points_snapshot" * 0.5
     OR NEW."registration_direct_allocation_snapshot" + NEW."registration_binary_allocation_snapshot" > NEW."pin_allocation_snapshot"
     OR NEW."registration_reseller_value_snapshot" < NEW."registration_acquisition_cost_snapshot" THEN
    RAISE EXCEPTION 'Registration PIN snapshot is missing, inconsistent, or underfunded.' USING ERRCODE = '23514';
  END IF;
  SELECT
    COUNT(*)::INTEGER AS product_count,
    COALESCE(SUM("quantity"), 0)::INTEGER AS units,
    COALESCE(SUM("srp_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS customer_payment,
    COALESCE(SUM("reseller_price_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS reseller_value,
    COALESCE(SUM("unit_acquisition_cost_snapshot" * "quantity"), 0)::DECIMAL(12,2) AS acquisition_cost
  INTO totals
  FROM "pin_registration_product_snapshots"
  WHERE "pin_id" = NEW."id";
  IF totals.product_count <> NEW."registration_product_line_count_snapshot"
     OR totals.units <> NEW."registration_units_snapshot"
     OR totals.customer_payment <> NEW."registration_customer_payment_snapshot"
     OR totals.reseller_value <> NEW."registration_reseller_value_snapshot"
     OR totals.acquisition_cost <> NEW."registration_acquisition_cost_snapshot" THEN
    RAISE EXCEPTION 'Registration PIN product snapshot does not match its financial totals.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_reward_stock_dispatch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_reward_stock_dispatch() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE stock RECORD; supplier_role TEXT;
BEGIN
  IF NOT reward_stock_actor_allowed(NEW.supplier_id,NEW.actor_id) OR NOT can_supply_reward_stock(NEW.supplier_id,NEW.recipient_id,NEW.kind)
    THEN RAISE EXCEPTION 'Only Hiroma or an authorized upstream supplier can replace this stock.' USING ERRCODE='23514'; END IF;
  PERFORM 1 FROM users WHERE id=NEW.recipient_id AND status::text='active' FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Replacement recipient is unavailable.' USING ERRCODE='23514'; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('reward-stock-holder:'||NEW.recipient_id||':'||NEW.product_id));
  SELECT full_name,role::text INTO NEW.supplier_name,supplier_role FROM users WHERE id=NEW.supplier_id;
  NEW.supplier_role:=supplier_role;
  SELECT full_name INTO NEW.recipient_name FROM users WHERE id=NEW.recipient_id;
  SELECT full_name INTO NEW.actor_name FROM users WHERE id=NEW.actor_id;
  SELECT name,CASE supplier_role WHEN 'regional' THEN regional_price WHEN 'provincial' THEN provincial_price ELSE cost_price END
    INTO NEW.product_name,NEW.unit_cost_snapshot FROM products WHERE id=NEW.product_id FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Replacement product is unavailable.' USING ERRCODE='23514'; END IF;
  SELECT quantity,reserved_quantity INTO stock FROM inventory WHERE owner_id=NEW.supplier_id AND product_id=NEW.product_id FOR UPDATE;
  IF NOT FOUND OR stock.quantity-stock.reserved_quantity<NEW.quantity THEN RAISE EXCEPTION 'Not enough available supplier stock.' USING ERRCODE='23514'; END IF;
  NEW.stock_before:=stock.quantity;NEW.stock_after:=stock.quantity-NEW.quantity;NEW.dispatched_at:=clock_timestamp();
  RETURN NEW;
END $$;


--
-- Name: validate_upgrade_financial_against_pin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_upgrade_financial_against_pin() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
BEGIN
  SELECT * INTO issued
  FROM "pins"
  WHERE "id" = NEW."upgrade_pin_id"
  FOR SHARE;

  IF NOT FOUND
     OR issued."pin_type" <> 'upgrade'
     OR issued."status" <> 'used'::"PinStatus"
     OR issued."used_at" IS NULL
     OR issued."used_by" IS DISTINCT FROM NEW."reseller_id"
     OR NOT "pin_has_exact_paid_source"(issued."id")
     OR NOT "upgrade_pin_snapshot_is_exact"(issued."id")
     OR issued."city_dist_id" <> NEW."city_dist_id"
     OR issued."upgrade_from_package_id" <> NEW."from_package_id"
     OR issued."package_id" <> NEW."to_package_id"
     OR NEW."customer_payment"
       <> issued."upgrade_customer_payment_snapshot"
     OR NEW."product_acquisition_cost"
       <> issued."upgrade_acquisition_cost_snapshot"
     OR NEW."reseller_value" <> issued."upgrade_reseller_value_snapshot"
     OR NEW."pin_allocation" <> issued."pin_allocation_snapshot"
     OR NEW."customer_payment" <> NEW."reseller_value" + NEW."pin_allocation"
     OR NEW."registration_profit"
       <> issued."upgrade_reseller_value_snapshot"
          - issued."upgrade_acquisition_cost_snapshot"
     OR NEW."direct_referral_allocation"
       <> issued."upgrade_direct_allocation_snapshot"
     OR NEW."direct_referral_paid" <> 0
     OR NEW."direct_referral_retained"
       <> issued."upgrade_direct_allocation_snapshot"
     OR NEW."binary_commission_allocation"
       <> issued."upgrade_binary_allocation_snapshot"
     OR NEW."binary_commission_allocation"
       <> NEW."binary_points_difference" * 0.5
     OR NEW."binary_points_difference"
       <> issued."upgrade_points_difference_snapshot"
     OR NEW."direct_referral_retained"
          + NEW."binary_commission_allocation"
       > NEW."pin_allocation"
     OR NEW."allocation_snapshot_source" <> 'upgrade_pin_snapshot'
     OR NEW."payment_status" <> 'paid'
     OR NEW."paid_at" IS NULL THEN
    RAISE EXCEPTION
      'Upgrade financial record does not exactly match its paid sealed Upgrade PIN.'
      USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_upgrade_pin_after_product_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_upgrade_pin_after_product_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  issued RECORD;
BEGIN
  SELECT * INTO issued FROM "pins" WHERE "id" = NEW."pin_id";
  IF NOT FOUND OR issued."pin_type" <> 'upgrade'
     OR issued."status" NOT IN ('unused'::"PinStatus", 'in_transit'::"PinStatus")
     OR NOT "upgrade_pin_snapshot_is_exact"(NEW."pin_id") THEN
    RAISE EXCEPTION 'Upgrade product snapshots require an exact newly issued unused or in-transit Upgrade PIN.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_upgrade_pin_snapshot(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_upgrade_pin_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW."pin_type" <> 'upgrade' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT'
     AND NEW."status" NOT IN ('unused'::"PinStatus", 'in_transit'::"PinStatus") THEN
    RAISE EXCEPTION 'An Upgrade PIN must be issued unused or in transit with a complete immutable snapshot.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'UPDATE' AND NEW."status" IN ('cancelled'::"PinStatus", 'expired'::"PinStatus") THEN
    RETURN NEW;
  END IF;
  IF NOT "upgrade_pin_snapshot_is_exact"(NEW."id") THEN
    RAISE EXCEPTION 'Upgrade PIN snapshot is missing, inconsistent, underfunded, or does not match its products.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_user_member_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_user_member_id() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD."member_id" IS DISTINCT FROM NEW."member_id" THEN
    RAISE EXCEPTION 'A user Member ID is permanent and cannot be changed.' USING ERRCODE = '55000';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM "member_id_issuances" issuance
    WHERE issuance."member_id" = NEW."member_id"
  ) THEN
    RAISE EXCEPTION 'User Member ID has no permanent issuance record.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: verify_deactivation_financial_liquidation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_deactivation_financial_liquidation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  ledger_count BIGINT := 0;
  ledger_amount DECIMAL(12,2) := 0;
  forfeiture_total DECIMAL(12,2) := 0;
  remaining_total DECIMAL(12,2) := 0;
  transfer_count BIGINT := 0;
  exact_transfer_count BIGINT := 0;
  audit_count BIGINT := 0;
  current_wallet_balance DECIMAL(12,2);
  current_wallet_reserved DECIMAL(12,2);
  profile_left INTEGER;
  profile_right INTEGER;
  profile_active BOOLEAN;
  current_status TEXT;
BEGIN
  IF NEW."liability_liquidation_version" IS DISTINCT FROM 'deactivation-liability-v1' THEN
    RAISE EXCEPTION 'Unknown deactivation liability liquidation version.' USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(*), COALESCE(SUM(-w."balance_delta"), 0)
  INTO ledger_count, ledger_amount
  FROM "wallet_ledger_entries" w
  WHERE w."entry_type" = 'deactivation_forfeit'
    AND w."source_kind" = 'deactivation'
    AND w."source_event_id" = NEW."id"
    AND w."user_id" = NEW."reseller_id";

  SELECT COALESCE(SUM(f."amount"), 0)
  INTO forfeiture_total
  FROM "payable_lot_forfeitures" f
  WHERE f."deactivation_event_id" = NEW."id";

  SELECT
    COALESCE((SELECT SUM("remaining_amount") FROM "direct_referral_reserve_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "binary_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "product_binary_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "rank_bonus_awards" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "unilevel_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
  INTO remaining_total;

  SELECT COUNT(*), COUNT(*) FILTER (
    WHERE c."type" = 'deactivation_wallet_transfer'::"CommissionType"
      AND c."amount" = NEW."wallet_value"
      AND c."source_user_id" = NEW."reseller_id"
      AND c."is_pair_overflow" = true
  )
  INTO transfer_count, exact_transfer_count
  FROM "commissions" c
  WHERE c."source_event_kind" = 'deactivation'
    AND c."source_event_id" = NEW."id";

  SELECT COUNT(*) INTO audit_count
  FROM "audit_logs" a
  WHERE a."activity_type" = 'reseller_deactivated'
    AND a."status" = 'completed'
    AND a."metadata"->>'deactivation_event_id' = NEW."id";

  SELECT w."balance", w."reserved_balance"
  INTO current_wallet_balance, current_wallet_reserved
  FROM "wallets" w WHERE w."user_id" = NEW."reseller_id";

  SELECT COALESCE(rp."left_points", 0), COALESCE(rp."right_points", 0), rp."is_active"
  INTO profile_left, profile_right, profile_active
  FROM "reseller_profiles" rp WHERE rp."user_id" = NEW."reseller_id";

  SELECT u."status"::text INTO current_status
  FROM "users" u WHERE u."id" = NEW."reseller_id";

  IF ledger_count <> 1 OR ledger_amount <> NEW."wallet_value"
     OR forfeiture_total <> NEW."wallet_value" OR remaining_total <> 0
     OR current_wallet_balance IS DISTINCT FROM 0 OR current_wallet_reserved IS DISTINCT FROM 0
     OR profile_left IS DISTINCT FROM 0 OR profile_right IS DISTINCT FROM 0 OR profile_active IS DISTINCT FROM false
     OR current_status IS DISTINCT FROM 'inactive' OR audit_count <> 1
     OR (NEW."wallet_value" > 0 AND (transfer_count <> 1 OR exact_transfer_count <> 1))
     OR (NEW."wallet_value" = 0 AND transfer_count <> 0) THEN
    RAISE EXCEPTION 'Deactivation financial liquidation is incomplete or inconsistent.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: verify_deactivation_fresh_zero_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_deactivation_fresh_zero_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  wallet_count BIGINT := 0;
  wallet_balance DECIMAL(12,2) := 0;
  wallet_reserved DECIMAL(12,2) := 0;
  remaining_payable DECIMAL(12,2) := 0;
  open_payout_count BIGINT := 0;
  profile_count BIGINT := 0;
  profile_left INTEGER := 0;
  profile_right INTEGER := 0;
  profile_active BOOLEAN;
  product_left INTEGER := 0;
  product_right INTEGER := 0;
  audit_count BIGINT := 0;
  current_status TEXT;
BEGIN
  SELECT COUNT(*), COALESCE(SUM(w."balance"), 0),
         COALESCE(SUM(w."reserved_balance"), 0)
  INTO wallet_count, wallet_balance, wallet_reserved
  FROM "wallets" w
  WHERE w."user_id" = NEW."reseller_id";

  SELECT
    COALESCE((SELECT SUM(l."remaining_amount") FROM "direct_referral_reserve_lots" l WHERE l."user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM(l."remaining_amount") FROM "binary_payable_lots" l WHERE l."user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM(l."remaining_amount") FROM "product_binary_payable_lots" l WHERE l."user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "rank_bonus_awards" WHERE "user_id" = NEW."reseller_id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "unilevel_payable_lots" WHERE "user_id" = NEW."reseller_id"), 0)
  INTO remaining_payable;

  SELECT COUNT(*)
  INTO open_payout_count
  FROM "payouts" p
  WHERE p."user_id" = NEW."reseller_id"
    AND p."status" IN ('pending'::"PayoutStatus", 'approved'::"PayoutStatus");

  SELECT COUNT(*), COALESCE(SUM(COALESCE(rp."left_points", 0)), 0)::INTEGER,
         COALESCE(SUM(COALESCE(rp."right_points", 0)), 0)::INTEGER,
         BOOL_AND(rp."is_active")
  INTO profile_count, profile_left, profile_right, profile_active
  FROM "reseller_profiles" rp
  WHERE rp."user_id" = NEW."reseller_id";

  SELECT COALESCE(SUM(position."left_carryover_pu"), 0)::INTEGER,
         COALESCE(SUM(position."right_carryover_pu"), 0)::INTEGER
  INTO product_left, product_right
  FROM "product_binary_positions" position
  WHERE position."user_id" = NEW."reseller_id";

  SELECT COUNT(*)
  INTO audit_count
  FROM "audit_logs" audit
  WHERE audit."activity_type" = 'reseller_deactivated'
    AND audit."status" = 'completed'
    AND audit."metadata"->>'deactivation_event_id' = NEW."id"
    AND audit."created_at" = NEW."created_at";

  SELECT u."status"::text
  INTO current_status
  FROM "users" u
  WHERE u."id" = NEW."reseller_id";

  IF NEW."created_at" IS DISTINCT FROM transaction_timestamp()
     OR audit_count <> 1
     OR current_status IS DISTINCT FROM 'inactive'
     OR wallet_count <> 1 OR wallet_balance <> 0 OR wallet_reserved <> 0
     OR remaining_payable <> 0 OR open_payout_count <> 0
     OR profile_count <> 1 OR profile_left <> 0 OR profile_right <> 0
     OR profile_active IS DISTINCT FROM false
     OR product_left <> 0 OR product_right <> 0 THEN
    RAISE EXCEPTION 'Deactivation requires fresh same-transaction evidence and a zero-liability closing state.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: verify_direct_referral_settlement_commit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_direct_referral_settlement_commit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  effective_closing INTEGER;
  sponsor_node_count INTEGER;
  linked_commission_count INTEGER;
BEGIN
  SELECT COUNT(*)::INTEGER
  INTO sponsor_node_count
  FROM "binary_tree_nodes" node
  WHERE node."user_id" = NEW."referred_user_id"
    AND node."sponsor_id" = NEW."sponsor_user_id";

  IF sponsor_node_count IS DISTINCT FROM 1 THEN
    RAISE EXCEPTION 'Direct Referral event sponsor does not match the committed genealogy.' USING ERRCODE = '23514';
  END IF;

  IF NEW."disposition" <> 'retained_system_root' THEN
    SELECT CASE
             WHEN (profile."last_referral_date" AT TIME ZONE 'Asia/Manila')::date = NEW."settlement_day"
               THEN GREATEST(profile."daily_referral_count", 0)
             ELSE 0
           END::INTEGER
    INTO effective_closing
    FROM "reseller_profiles" profile
    WHERE profile."user_id" = NEW."sponsor_user_id";

    IF effective_closing IS DISTINCT FROM NEW."closing_daily_referral_count" THEN
      RAISE EXCEPTION 'Direct Referral sponsor daily counter does not match the immutable event closing state.' USING ERRCODE = '23514';
    END IF;
  END IF;

  SELECT COUNT(*)::INTEGER
  INTO linked_commission_count
  FROM "commissions" commission
  WHERE commission."type" = 'direct_referral'::"CommissionType"
    AND commission."rule_version" = 'registration-direct-v1'
    AND commission."source_event_kind" = 'registration'
    AND commission."source_event_id" = NEW."source_event_id";

  IF linked_commission_count IS DISTINCT FROM
     ((NEW."normal_commission_id" IS NOT NULL)::INTEGER +
      (NEW."retained_commission_id" IS NOT NULL)::INTEGER) THEN
    RAISE EXCEPTION 'Direct Referral source has commissions outside its exact settlement event.' USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: verify_legacy_product_binary_week_readiness(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_legacy_product_binary_week_readiness(target_week date) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  w public.product_binary_pool_weeks;
  blocker text;
  available numeric;
  recorded_budget numeric;
  recorded_pairs numeric;
  allocated numeric;
  allocation_pairs numeric;
BEGIN
  SELECT * INTO STRICT w FROM public.product_binary_pool_weeks
  WHERE week_start = target_week FOR UPDATE;
  IF w.closed_at IS NULL OR w.released_at IS NOT NULL OR w.release_started_at IS NOT NULL THEN
    RETURN 'Week must be finalized and unreleased.';
  END IF;

  SELECT COALESCE(SUM(COALESCE(o.funded_units, e.eligible_units)::numeric), 0) * 500
  INTO recorded_budget
  FROM public.product_binary_pool_orders o JOIN public.product_binary_order_events e ON e.id=o.order_event_id
  WHERE o.week_start=target_week;
  SELECT COALESCE(SUM(e.payable_pairs::numeric),0) INTO recorded_pairs
  FROM public.product_binary_pool_pairs p JOIN public.product_binary_pair_events e ON e.id=p.pair_event_id
  WHERE p.week_start=target_week;
  SELECT COALESCE(SUM(a.amount_centavos),0), COALESCE(SUM(a.payable_pairs),0)
  INTO allocated, allocation_pairs FROM public.product_binary_pool_allocations a WHERE a.week_start=target_week;

  IF recorded_budget <> w.pool_centavos OR recorded_pairs <> w.total_pairs
     OR allocated <> w.allocated_centavos OR allocation_pairs <> recorded_pairs
     OR allocated > recorded_budget THEN
    blocker := 'Recorded funding, pairs, and finalized allocations do not reconcile.';
  ELSIF EXISTS (SELECT 1 FROM public.product_binary_pool_allocations
    WHERE week_start=target_week AND commission_id IS NOT NULL) THEN
    blocker := 'The week already contains wallet credits.';
  ELSIF EXISTS (
    WITH expected_pairs AS (
      SELECT e.recipient_user_id, SUM(e.payable_pairs::numeric) AS pairs
      FROM public.product_binary_pool_pairs p
      JOIN public.product_binary_pair_events e ON e.id = p.pair_event_id
      WHERE p.week_start = target_week AND e.payable_pairs > 0
      GROUP BY e.recipient_user_id
    ), actual AS (
      SELECT recipient_user_id, payable_pairs, amount_centavos
      FROM public.product_binary_pool_allocations WHERE week_start = target_week
    )
    SELECT 1 FROM expected_pairs e FULL JOIN actual a USING (recipient_user_id)
    WHERE e.pairs IS DISTINCT FROM a.payable_pairs::numeric
       OR a.amount_centavos::numeric IS DISTINCT FROM
          div(e.pairs * LEAST(recorded_budget, recorded_pairs * w.max_rate_centavos), NULLIF(recorded_pairs, 0))
  ) THEN
    blocker := 'One or more recipient allocations do not match the finalized pair records.';
  ELSE
    PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
    SELECT COALESCE(SUM(GREATEST(0, remaining_amount-public.product_binary_inventory_earmark(order_id))),0)
    INTO available FROM public.product_binary_funding_lots WHERE allocated_at<=CURRENT_TIMESTAMP;
    IF allocated - 
    COALESCE((SELECT SUM(a.amount_centavos) FROM public.product_binary_pool_allocations a
      WHERE a.week_start = target_week AND a.retained_at IS NOT NULL AND a.commission_id IS NULL), 0)
   > GREATEST(0, available-public.product_binary_week_funding_held(target_week))*100 THEN
      blocker := 'Available funded reserve is insufficient.';
    END IF;
  END IF;
  UPDATE public.product_binary_pool_weeks
  SET readiness_checked_at=clock_timestamp(), readiness_blocker=blocker WHERE week_start=target_week;
  RETURN blocker;
END;
$$;


--
-- Name: verify_package_binary_cap_policy_audit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_package_binary_cap_policy_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM audit_logs WHERE activity_type='package_binary_cap_policy_scheduled'
  AND metadata->>'policy_id'=NEW.id::text AND metadata->>'actor_id'=NEW.created_by) THEN
  RAISE EXCEPTION 'Cap policy requires its atomic owner audit record.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: verify_package_binary_carryover_audit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_package_binary_carryover_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.created_by IS NULL AND NEW.cap_policy_id IS NULL AND EXISTS(SELECT 1 FROM audit_logs WHERE activity_type='package_binary_carryover_cap_initialized' AND metadata->>'carryover_policy_id'=NEW.id::text) THEN RETURN NEW; END IF;
 IF NOT EXISTS(SELECT 1 FROM audit_logs WHERE activity_type='package_binary_cap_policy_scheduled' AND metadata->>'carryover_policy_id'=NEW.id::text AND metadata->>'actor_id'=NEW.created_by) THEN RAISE EXCEPTION 'Carryover policy requires its atomic owner audit record.' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: verify_product_binary_week_readiness(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_product_binary_week_readiness(target_week date) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'public', 'pg_temp'
    AS $$
DECLARE
  w public.product_binary_pool_weeks;
  preparation public.product_binary_week_preparation;
  recipient record;
  last_recipient text;
  batch_pairs bigint := 0;
  batch_centavos bigint := 0;
  batch_count bigint := 0;
  allocation_count bigint;
  available numeric;
  blocker text;
BEGIN
  SELECT * INTO STRICT w FROM public.product_binary_pool_weeks WHERE week_start = target_week FOR UPDATE;
  IF w.closed_at IS NULL OR w.released_at IS NOT NULL OR w.release_started_at IS NOT NULL THEN
    RETURN 'Week must be finalized and unreleased.';
  END IF;
  SELECT * INTO preparation FROM public.product_binary_week_preparation WHERE week_start = target_week;
  IF NOT FOUND THEN RETURN public.verify_legacy_product_binary_week_readiness(target_week); END IF;
  IF preparation.stage <> 'complete' OR w.pool_centavos <> preparation.pool_centavos
     OR w.total_pairs <> preparation.total_pairs OR w.allocated_centavos <> preparation.allocated_centavos THEN
    blocker := 'Prepared funding, pairs, and finalized totals do not reconcile.';
  ELSIF preparation.verification_completed_at IS NULL THEN
    FOR recipient IN
      SELECT r.recipient_user_id, r.payable_pairs, a.payable_pairs AS actual_pairs, a.amount_centavos, a.commission_id
      FROM public.product_binary_prepared_recipients r
      LEFT JOIN public.product_binary_pool_allocations a USING (week_start, recipient_user_id)
      WHERE r.week_start = target_week
        AND r.recipient_user_id >= COALESCE(preparation.verification_cursor, '')
        AND r.recipient_user_id IS DISTINCT FROM preparation.verification_cursor
      ORDER BY r.recipient_user_id LIMIT 1000
    LOOP
      IF recipient.payable_pairs IS DISTINCT FROM recipient.actual_pairs
         OR recipient.commission_id IS NOT NULL
         OR recipient.amount_centavos::numeric IS DISTINCT FROM
          div(recipient.payable_pairs::numeric *
            LEAST(w.pool_centavos::numeric, w.total_pairs::numeric * w.max_rate_centavos), w.total_pairs) THEN
        blocker := 'One or more recipient allocations do not match the finalized pair records.';
        EXIT;
      END IF;
      batch_pairs := batch_pairs + recipient.payable_pairs;
      batch_centavos := batch_centavos + recipient.amount_centavos;
      batch_count := batch_count + 1;
      last_recipient := recipient.recipient_user_id;
    END LOOP;
    IF blocker IS NULL AND last_recipient IS NOT NULL THEN
      UPDATE public.product_binary_week_preparation
      SET verification_cursor = last_recipient, verified_pairs = verified_pairs + batch_pairs,
        verified_centavos = verified_centavos + batch_centavos, verified_recipients = verified_recipients + batch_count
      WHERE week_start = target_week;
      UPDATE public.product_binary_pool_weeks
      SET readiness_blocker = 'Verification in progress', readiness_checked_at = clock_timestamp()
      WHERE week_start = target_week;
      RETURN 'Verification in progress';
    END IF;
    IF blocker IS NULL THEN
      SELECT COUNT(*) INTO allocation_count FROM public.product_binary_pool_allocations WHERE week_start = target_week;
      IF allocation_count <> preparation.verified_recipients OR preparation.verified_pairs <> w.total_pairs
         OR preparation.verified_centavos <> w.allocated_centavos THEN
        blocker := 'Recorded allocations do not match the prepared recipient totals.';

      ELSE
        UPDATE public.product_binary_week_preparation SET verification_completed_at = clock_timestamp()
        WHERE week_start = target_week;
      END IF;
    END IF;
  END IF;
  IF blocker IS NULL THEN
    -- Recheck real funding hourly and immediately before the first release.
    PERFORM pg_advisory_xact_lock(hashtext('product-binary-funding'));
    SELECT COALESCE(SUM(GREATEST(0, remaining_amount - public.product_binary_inventory_earmark(order_id))), 0)
    INTO available FROM public.product_binary_funding_lots WHERE allocated_at <= CURRENT_TIMESTAMP;
    IF w.allocated_centavos > GREATEST(0, available - public.product_binary_week_funding_held(target_week)) * 100 THEN
      blocker := 'Available funded reserve is insufficient.';
    END IF;
  END IF;
  UPDATE public.product_binary_week_preparation
  SET verification_cursor = NULL, verified_pairs = 0, verified_centavos = 0, verified_recipients = 0
  WHERE week_start = target_week;
  UPDATE public.product_binary_pool_weeks SET readiness_checked_at = clock_timestamp(), readiness_blocker = blocker
  WHERE week_start = target_week;
  RETURN blocker;
END;
$$;


--
-- Name: verify_reseller_status_transition(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_reseller_status_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  profile_count BIGINT := 0;
  profile_active BOOLEAN;
  profile_left INTEGER := 0;
  profile_right INTEGER := 0;
  product_left INTEGER := 0;
  product_right INTEGER := 0;
  evidence_count BIGINT := 0;
  wallet_count BIGINT := 0;
  wallet_balance DECIMAL(12,2) := 0;
  wallet_reserved DECIMAL(12,2) := 0;
  remaining_payable DECIMAL(12,2) := 0;
  open_payout_count BIGINT := 0;
  current_status TEXT;
BEGIN
  IF OLD."role" <> 'reseller'::"Role"
     OR NEW."status" IS NOT DISTINCT FROM OLD."status" THEN
    RETURN NEW;
  END IF;

  SELECT COUNT(*), BOOL_AND(rp."is_active"),
         COALESCE(SUM(COALESCE(rp."left_points", 0)), 0)::INTEGER,
         COALESCE(SUM(COALESCE(rp."right_points", 0)), 0)::INTEGER
  INTO profile_count, profile_active, profile_left, profile_right
  FROM "reseller_profiles" rp
  WHERE rp."user_id" = NEW."id";

  SELECT u."status"::text
  INTO current_status
  FROM "users" u
  WHERE u."id" = NEW."id";

  IF current_status IS DISTINCT FROM NEW."status"::text
     OR profile_count <> 1
     OR profile_active IS DISTINCT FROM (NEW."status" = 'active'::"UserStatus") THEN
    RAISE EXCEPTION 'Reseller status and profile activity are inconsistent.' USING ERRCODE = '23514';
  END IF;

  IF NEW."status" = 'inactive'::"UserStatus" THEN
    SELECT COUNT(*)
    INTO evidence_count
    FROM "reseller_deactivation_events" event
    WHERE event."reseller_id" = NEW."id"
      AND event."liability_liquidation_version" = 'deactivation-liability-v1'
      AND event."created_at" = transaction_timestamp();

    SELECT COUNT(*), COALESCE(SUM(w."balance"), 0),
           COALESCE(SUM(w."reserved_balance"), 0)
    INTO wallet_count, wallet_balance, wallet_reserved
    FROM "wallets" w
    WHERE w."user_id" = NEW."id";

    SELECT
      COALESCE((SELECT SUM(l."remaining_amount") FROM "direct_referral_reserve_lots" l WHERE l."user_id" = NEW."id"), 0)
      + COALESCE((SELECT SUM(l."remaining_amount") FROM "binary_payable_lots" l WHERE l."user_id" = NEW."id"), 0)
      + COALESCE((SELECT SUM(l."remaining_amount") FROM "product_binary_payable_lots" l WHERE l."user_id" = NEW."id"), 0)
      + COALESCE((SELECT SUM("remaining_amount") FROM "rank_bonus_awards" WHERE "user_id" = NEW."id"), 0)
    + COALESCE((SELECT SUM("remaining_amount") FROM "unilevel_payable_lots" WHERE "user_id" = NEW."id"), 0)
    INTO remaining_payable;

    SELECT COUNT(*)
    INTO open_payout_count
    FROM "payouts" p
    WHERE p."user_id" = NEW."id"
      AND p."status" IN ('pending'::"PayoutStatus", 'approved'::"PayoutStatus");

    SELECT COALESCE(SUM(position."left_carryover_pu"), 0)::INTEGER,
           COALESCE(SUM(position."right_carryover_pu"), 0)::INTEGER
    INTO product_left, product_right
    FROM "product_binary_positions" position
    WHERE position."user_id" = NEW."id";

    IF evidence_count <> 1
       OR wallet_count <> 1 OR wallet_balance <> 0 OR wallet_reserved <> 0
       OR remaining_payable <> 0 OR open_payout_count <> 0
       OR profile_left <> 0 OR profile_right <> 0
       OR product_left <> 0 OR product_right <> 0 THEN
      RAISE EXCEPTION 'Inactive reseller transition requires one fresh sealed settlement and zero remaining liability or carryover.' USING ERRCODE = '23514';
    END IF;
  ELSE
    SELECT COUNT(*)
    INTO evidence_count
    FROM "audit_logs" audit
    WHERE audit."activity_type" = 'reseller_status_changed'
      AND audit."status" = 'completed'
      AND audit."metadata"->>'reseller_id' = NEW."id"
      AND audit."metadata"->>'to_status' = NEW."status"::text
      AND audit."created_at" = transaction_timestamp();

    IF evidence_count <> 1 THEN
      RAISE EXCEPTION 'Reseller activation or suspension requires one fresh immutable audit event.' USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: address_geocode_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address_geocode_cache (
    id uuid NOT NULL,
    address_hash character varying NOT NULL,
    latitude numeric(10,7),
    longitude numeric(10,7),
    provider character varying DEFAULT 'nominatim'::character varying NOT NULL,
    result_label text,
    lookup_status character varying DEFAULT 'found'::character varying NOT NULL,
    last_lookup_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT address_geocode_cache_coordinates_pair_check CHECK (((latitude IS NULL) = (longitude IS NULL)))
);


--
-- Name: admin_stock_receipt_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_stock_receipt_items (
    id uuid NOT NULL,
    receipt_id uuid NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    stock_before integer NOT NULL,
    stock_after integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_stock_receipt_items_cost_check CHECK ((unit_cost >= (0)::numeric)),
    CONSTRAINT admin_stock_receipt_items_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT admin_stock_receipt_items_stock_check CHECK ((stock_after = (stock_before + quantity)))
);


--
-- Name: admin_stock_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_stock_receipts (
    id uuid NOT NULL,
    reference_number character varying(40) NOT NULL,
    source_type character varying(32) NOT NULL,
    source_reference character varying(120) NOT NULL,
    source_reference_key character varying(120) NOT NULL,
    admin_id text NOT NULL,
    received_by_actor_id uuid,
    total_units integer NOT NULL,
    notes text,
    received_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text,
    user_name text,
    user_role text,
    member_id text,
    activity_type text NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address text,
    device text,
    risk_level text DEFAULT 'low'::text NOT NULL,
    status text DEFAULT 'normal'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: binary_daily_cap_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_daily_cap_usage (
    user_id text NOT NULL,
    pairing_day date NOT NULL,
    used_pairs bigint NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT binary_daily_cap_usage_used_pairs_check CHECK ((used_pairs >= 0))
);


--
-- Name: binary_pair_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_pair_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipient_user_id text NOT NULL,
    source_user_id text NOT NULL,
    source_kind character varying NOT NULL,
    source_leg character varying NOT NULL,
    source_points integer NOT NULL,
    points_per_pair integer NOT NULL,
    peso_per_point numeric(8,4) NOT NULL,
    completed_pairs integer NOT NULL,
    payable_pairs integer NOT NULL,
    cap_flashout_pairs integer NOT NULL,
    inactive_flashout_pairs integer NOT NULL,
    consumed_left_points integer NOT NULL,
    consumed_right_points integer NOT NULL,
    payable_amount numeric(12,2) NOT NULL,
    flashout_amount numeric(12,2) NOT NULL,
    cap_enabled boolean NOT NULL,
    cap_limit integer,
    normal_commission_id text,
    flashout_commission_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    recipient_package_id text,
    package_name_snapshot character varying DEFAULT 'Unknown'::character varying NOT NULL,
    pair_value_snapshot numeric(12,2) DEFAULT 0 NOT NULL,
    package_snapshot_source character varying DEFAULT 'exact_event'::character varying NOT NULL,
    source_event_id character varying(255),
    opening_left_points integer,
    opening_right_points integer,
    closing_left_points integer,
    closing_right_points integer,
    pairing_day date,
    opening_daily_pairing_count integer,
    closing_daily_pairing_count integer,
    product_reward_pairs integer DEFAULT 0 NOT NULL,
    reward_interval integer,
    reward_product_id text,
    opening_reward_eligible_count bigint DEFAULT 0 NOT NULL,
    source_points_flushed integer DEFAULT 0 NOT NULL,
    cap_session smallint,
    opening_session_pairing_count integer,
    closing_session_pairing_count integer,
    cap_policy_id uuid,
    cap_mode text,
    cap_cutoff text,
    carryover_policy_id uuid,
    carryover_cap_enabled boolean,
    carryover_cap_points integer,
    session_flushed_points integer,
    carryover_flushed_points integer,
    CONSTRAINT binary_pair_event_source_flush_parts CHECK (((carryover_cap_enabled IS NULL) OR ((session_flushed_points IS NOT NULL) AND (carryover_flushed_points IS NOT NULL) AND (session_flushed_points >= 0) AND (carryover_flushed_points >= 0) AND ((session_flushed_points + carryover_flushed_points) = source_points_flushed)))),
    CONSTRAINT binary_pair_events_amounts_check CHECK (((payable_amount >= (0)::numeric) AND (flashout_amount >= (0)::numeric))),
    CONSTRAINT binary_pair_events_counts_check CHECK (((completed_pairs >= 0) AND (payable_pairs >= 0) AND (cap_flashout_pairs >= 0) AND (inactive_flashout_pairs >= 0) AND (completed_pairs = ((payable_pairs + cap_flashout_pairs) + inactive_flashout_pairs)))),
    CONSTRAINT binary_pair_events_session_check CHECK (((source_points_flushed >= 0) AND (source_points_flushed <= source_points) AND ((cap_session IS NULL) OR ((cap_session = ANY (ARRAY[0, 1, 2])) AND (opening_session_pairing_count >= 0) AND (closing_session_pairing_count >= opening_session_pairing_count))))),
    CONSTRAINT binary_pair_events_state_snapshot_check CHECK ((((opening_left_points IS NULL) AND (opening_right_points IS NULL) AND (closing_left_points IS NULL) AND (closing_right_points IS NULL) AND (pairing_day IS NULL) AND (opening_daily_pairing_count IS NULL) AND (closing_daily_pairing_count IS NULL)) OR ((opening_left_points IS NOT NULL) AND (opening_right_points IS NOT NULL) AND (closing_left_points IS NOT NULL) AND (closing_right_points IS NOT NULL) AND (pairing_day IS NOT NULL) AND (opening_daily_pairing_count IS NOT NULL) AND (closing_daily_pairing_count IS NOT NULL) AND (opening_left_points >= 0) AND (opening_right_points >= 0) AND (closing_left_points >= 0) AND (closing_right_points >= 0) AND (opening_daily_pairing_count >= 0) AND (closing_daily_pairing_count >= 0)))),
    CONSTRAINT binary_reward_partition CHECK (((product_reward_pairs >= 0) AND (product_reward_pairs <= payable_pairs) AND (opening_reward_eligible_count >= 0) AND ((reward_interval IS NULL) OR ((reward_interval >= 2) AND (reward_interval <= 1000))) AND ((reward_interval IS NOT NULL) OR (product_reward_pairs = 0))))
);


--
-- Name: binary_payable_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_payable_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    commission_id text NOT NULL,
    user_id text NOT NULL,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    allocated_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_payable_lots_amount_check CHECK (((original_amount >= (0)::numeric) AND (remaining_amount >= (0)::numeric)))
);


--
-- Name: binary_payout_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_payout_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payout_id text NOT NULL,
    payable_lot_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    allocated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_payout_consumptions_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: binary_point_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_point_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    point_lot_id uuid NOT NULL,
    binary_pair_event_id uuid NOT NULL,
    points integer NOT NULL,
    consumed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_point_consumptions_points_check CHECK ((points > 0))
);


--
-- Name: binary_point_expirations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_point_expirations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    point_lot_id uuid NOT NULL,
    recipient_user_id text NOT NULL,
    leg character varying(5) NOT NULL,
    points integer NOT NULL,
    generated_at timestamp(6) with time zone NOT NULL,
    scheduled_at timestamp(6) with time zone NOT NULL,
    expired_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expiry_years integer NOT NULL,
    CONSTRAINT binary_point_expirations_leg_check CHECK (((leg)::text = ANY (ARRAY[('left'::character varying)::text, ('right'::character varying)::text]))),
    CONSTRAINT binary_point_expirations_points_check CHECK (((points > 0) AND ((expiry_years >= 1) AND (expiry_years <= 20))))
);


--
-- Name: binary_point_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_point_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipient_user_id text NOT NULL,
    source_user_id text NOT NULL,
    source_kind character varying(40) NOT NULL,
    source_event_id character varying(255) NOT NULL,
    leg character varying(5) NOT NULL,
    original_points integer NOT NULL,
    remaining_points integer NOT NULL,
    generated_at timestamp(6) with time zone NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    expiry_years integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_point_lots_expiry_check CHECK (((expiry_years >= 1) AND (expiry_years <= 20) AND (expires_at > generated_at))),
    CONSTRAINT binary_point_lots_leg_check CHECK (((leg)::text = ANY (ARRAY[('left'::character varying)::text, ('right'::character varying)::text]))),
    CONSTRAINT binary_point_lots_points_check CHECK (((original_points > 0) AND (remaining_points >= 0) AND (remaining_points <= original_points)))
);


--
-- Name: binary_reserve_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_reserve_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reserve_lot_id uuid,
    commission_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    is_unfunded boolean DEFAULT false NOT NULL,
    consumed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_reserve_consumptions_amount_positive CHECK ((amount > (0)::numeric))
);


--
-- Name: binary_reserve_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_reserve_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    registration_financial_id uuid,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    snapshot_source character varying NOT NULL,
    allocated_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    upgrade_financial_id uuid,
    CONSTRAINT binary_reserve_lots_amount_non_negative CHECK (((original_amount >= (0)::numeric) AND (remaining_amount >= (0)::numeric)))
);


--
-- Name: binary_settlement_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_settlement_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_kind character varying NOT NULL,
    source_event_id character varying(255) NOT NULL,
    source_user_id text NOT NULL,
    source_points integer NOT NULL,
    parent_node_id text NOT NULL,
    source_leg character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_settlement_events_leg_check CHECK (((source_leg)::text = ANY (ARRAY[('left'::character varying)::text, ('right'::character varying)::text]))),
    CONSTRAINT binary_settlement_events_points_check CHECK ((source_points > 0)),
    CONSTRAINT binary_settlement_events_source_check CHECK (((source_kind)::text = ANY (ARRAY[('registration'::character varying)::text, ('upgrade'::character varying)::text])))
);


--
-- Name: binary_tree_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_tree_nodes (
    id text NOT NULL,
    user_id text NOT NULL,
    parent_id text,
    "position" public."TreePosition",
    sponsor_id text,
    left_count integer DEFAULT 0 NOT NULL,
    right_count integer DEFAULT 0 NOT NULL,
    is_overflow boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT binary_tree_nodes_descendant_counts_nonnegative_check CHECK (((left_count >= 0) AND (right_count >= 0))),
    CONSTRAINT binary_tree_nodes_parent_position_shape_check CHECK ((((parent_id IS NULL) AND ("position" IS NULL)) OR ((parent_id IS NOT NULL) AND ("position" IS NOT NULL) AND (id <> parent_id))))
);


--
-- Name: branch_cash_deposits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branch_cash_deposits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reference_number character varying NOT NULL,
    branch_id text NOT NULL,
    period_start timestamp(6) with time zone NOT NULL,
    period_end timestamp(6) with time zone NOT NULL,
    expected_cash_snapshot numeric(12,2) NOT NULL,
    deposit_amount numeric(12,2) NOT NULL,
    variance_amount numeric(12,2) NOT NULL,
    bank_name character varying NOT NULL,
    bank_account_last_four character varying(4),
    bank_reference character varying NOT NULL,
    deposited_at timestamp(6) with time zone NOT NULL,
    proof_storage_path character varying,
    notes text,
    status character varying DEFAULT 'submitted'::character varying NOT NULL,
    submitted_by text NOT NULL,
    submitted_by_name_snapshot character varying NOT NULL,
    submitted_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    confirmed_by text,
    confirmed_by_name_snapshot character varying,
    confirmed_at timestamp(6) with time zone,
    reviewed_by text,
    reviewed_by_name_snapshot character varying,
    reviewed_at timestamp(6) with time zone,
    review_notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commissions (
    id text NOT NULL,
    user_id text NOT NULL,
    type public."CommissionType" NOT NULL,
    amount numeric(10,2) NOT NULL,
    points integer,
    source_user_id text,
    cascade_remainder numeric(10,2),
    is_pair_overflow boolean DEFAULT false NOT NULL,
    overflow_to text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    event_key character varying(255),
    source_event_kind character varying(32),
    source_event_id character varying(255),
    rule_version character varying(64) DEFAULT 'legacy-v1'::character varying NOT NULL
);


--
-- Name: direct_referral_payout_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_referral_payout_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payout_id text NOT NULL,
    reserve_lot_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    allocated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT direct_referral_payout_consumptions_amount_positive CHECK ((amount > (0)::numeric))
);


--
-- Name: direct_referral_reserve_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_referral_reserve_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    commission_id text NOT NULL,
    user_id text NOT NULL,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    snapshot_source character varying NOT NULL,
    allocated_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT direct_referral_reserve_lots_amount_non_negative CHECK (((original_amount >= (0)::numeric) AND (remaining_amount >= (0)::numeric)))
);


--
-- Name: direct_referral_settlement_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.direct_referral_settlement_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    registration_financial_id uuid CONSTRAINT direct_referral_settlement_e_registration_financial_id_not_null NOT NULL,
    source_event_id character varying(255) NOT NULL,
    sponsor_user_id text NOT NULL,
    referred_user_id text NOT NULL,
    sponsor_package_id text,
    package_name_snapshot character varying CONSTRAINT direct_referral_settlement_event_package_name_snapshot_not_null NOT NULL,
    sponsor_bonus_snapshot numeric(12,2) CONSTRAINT direct_referral_settlement_even_sponsor_bonus_snapshot_not_null NOT NULL,
    source_allocation numeric(12,2) NOT NULL,
    cap_enabled boolean NOT NULL,
    cap_limit integer NOT NULL,
    settlement_day date NOT NULL,
    opening_daily_referral_count integer CONSTRAINT direct_referral_settlement__opening_daily_referral_cou_not_null NOT NULL,
    closing_daily_referral_count integer CONSTRAINT direct_referral_settlement__closing_daily_referral_cou_not_null NOT NULL,
    recipient_eligible boolean NOT NULL,
    disposition character varying(40) NOT NULL,
    payable_amount numeric(12,2) NOT NULL,
    retained_amount numeric(12,2) NOT NULL,
    normal_commission_id text,
    retained_commission_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT direct_referral_settlement_amounts_check CHECK (((sponsor_bonus_snapshot >= (0)::numeric) AND (source_allocation >= (0)::numeric) AND (cap_limit >= 0) AND (opening_daily_referral_count >= 0) AND (closing_daily_referral_count >= 0) AND (payable_amount >= (0)::numeric) AND (retained_amount >= (0)::numeric) AND ((payable_amount + retained_amount) = source_allocation))),
    CONSTRAINT direct_referral_settlement_disposition_check CHECK (((disposition)::text = ANY (ARRAY[('paid'::character varying)::text, ('paid_with_package_remainder'::character varying)::text, ('retained_package_difference'::character varying)::text, ('retained_cap'::character varying)::text, ('retained_ineligible'::character varying)::text, ('retained_system_root'::character varying)::text])))
);


--
-- Name: distributor_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_profiles (
    id text NOT NULL,
    user_id text NOT NULL,
    dist_level public."DistributorLevel" NOT NULL,
    coverage_area text NOT NULL,
    parent_dist_id text,
    contract_signed_at timestamp(3) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    region_code text,
    region_name text,
    province_code text,
    province_name text,
    city_muni_code text,
    city_muni_name text,
    barangay_code text,
    barangay_name text,
    fulfillment_outlet_name text,
    fulfillment_outlet_address text,
    fulfillment_outlet_region_code text,
    fulfillment_outlet_region_name text,
    fulfillment_outlet_province_code text,
    fulfillment_outlet_province_name text,
    fulfillment_outlet_city_muni_code text,
    fulfillment_outlet_city_muni_name text,
    fulfillment_outlet_barangay_code text,
    fulfillment_outlet_barangay_name text,
    fulfillment_outlet_zip_code text,
    fulfillment_latitude numeric(10,7),
    fulfillment_longitude numeric(10,7),
    accepts_cash_on_pickup boolean DEFAULT true NOT NULL,
    CONSTRAINT distributor_profiles_fulfillment_coordinates_pair_check CHECK (((fulfillment_latitude IS NULL) = (fulfillment_longitude IS NULL))),
    CONSTRAINT distributor_profiles_fulfillment_latitude_check CHECK (((fulfillment_latitude IS NULL) OR ((fulfillment_latitude >= ('-90'::integer)::numeric) AND (fulfillment_latitude <= (90)::numeric)))),
    CONSTRAINT distributor_profiles_fulfillment_longitude_check CHECK (((fulfillment_longitude IS NULL) OR ((fulfillment_longitude >= ('-180'::integer)::numeric) AND (fulfillment_longitude <= (180)::numeric))))
);


--
-- Name: financial_operation_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_operation_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    kind text NOT NULL,
    source_id text NOT NULL,
    owner_id text NOT NULL,
    actor_id text NOT NULL,
    request_hash text NOT NULL,
    response jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT financial_operation_receipts_kind_check CHECK ((kind = ANY (ARRAY['registration'::text, 'upgrade'::text]))),
    CONSTRAINT financial_operation_receipts_request_hash_check CHECK ((request_hash ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT financial_operation_receipts_response_check CHECK ((jsonb_typeof(response) = 'object'::text))
);


--
-- Name: hiro_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hiro_conversations (
    id text NOT NULL,
    user_id text NOT NULL,
    status public."HiroConversationStatus" DEFAULT 'active'::public."HiroConversationStatus" NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_activity timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    closed_at timestamp(3) without time zone,
    close_reason text
);


--
-- Name: hiro_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hiro_messages (
    id text NOT NULL,
    conversation_id text NOT NULL,
    role public."HiroMessageRole" NOT NULL,
    text text NOT NULL,
    intent text,
    links jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: identity_account_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_account_limits (
    identity_hash character varying(64) NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    max_allowed integer DEFAULT 7 NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT identity_account_limit_range_check CHECK (((count >= 0) AND (max_allowed > 0) AND (count <= max_allowed))),
    CONSTRAINT identity_account_maximum_seven CHECK ((max_allowed = 7))
);


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory (
    id text NOT NULL,
    owner_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    low_stock_threshold integer DEFAULT 10 NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    reserved_quantity integer DEFAULT 0 NOT NULL,
    CONSTRAINT inventory_non_negative_stock_check CHECK (((quantity >= 0) AND (reserved_quantity >= 0) AND (reserved_quantity <= quantity)))
);


--
-- Name: inventory_audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_audit_events (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    product_id text,
    actor_id text,
    actor_name_snapshot character varying NOT NULL,
    event_type character varying NOT NULL,
    quantity_delta integer DEFAULT 0 NOT NULL,
    quantity_before integer,
    quantity_after integer,
    unit_cost_snapshot numeric(12,2),
    total_value numeric(12,2),
    reference_type character varying,
    reference_id text,
    reason text,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: inventory_audit_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_audit_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    inventory_id text NOT NULL,
    product_id text NOT NULL,
    product_name_snapshot character varying NOT NULL,
    expected_quantity integer NOT NULL,
    counted_quantity integer,
    variance_quantity integer,
    unit_cost_snapshot numeric(12,2) NOT NULL,
    variance_value numeric(12,2),
    damaged_quantity integer DEFAULT 0 NOT NULL,
    expired_quantity integer DEFAULT 0 NOT NULL,
    missing_quantity integer DEFAULT 0 NOT NULL,
    notes text,
    counted_by text,
    counted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: inventory_audit_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_audit_sessions (
    id uuid NOT NULL,
    reference_number character varying NOT NULL,
    owner_id text NOT NULL,
    status character varying DEFAULT 'counting'::character varying NOT NULL,
    scope character varying DEFAULT 'full'::character varying NOT NULL,
    started_by text NOT NULL,
    started_by_name_snapshot character varying NOT NULL,
    notes text,
    submitted_at timestamp(6) with time zone,
    approved_at timestamp(6) with time zone,
    approved_by text,
    approval_notes text,
    started_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    pos_shift_id uuid
);


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    recipient_id uuid NOT NULL,
    product_id uuid NOT NULL,
    order_id uuid,
    quantity integer NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    reference_value numeric(12,2) NOT NULL,
    sale_value numeric(12,2) NOT NULL,
    admin_profit numeric(12,2) NOT NULL,
    is_sale boolean DEFAULT true NOT NULL,
    admin_stock_before integer NOT NULL,
    admin_stock_after integer NOT NULL,
    recipient_stock_before integer NOT NULL,
    recipient_stock_after integer NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    transfer_id uuid,
    accepted_quantity integer,
    damaged_quantity integer,
    missing_quantity integer,
    receiving_notes text,
    received_at timestamp(6) with time zone
);


--
-- Name: inventory_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transfers (
    id uuid NOT NULL,
    reference_number character varying NOT NULL,
    admin_id text NOT NULL,
    recipient_id text NOT NULL,
    status character varying DEFAULT 'in_transit'::character varying NOT NULL,
    reference_value numeric(12,2) NOT NULL,
    notes text,
    dispatched_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    received_at timestamp(6) with time zone,
    received_by text,
    receiving_notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dispatched_by_actor_id uuid,
    received_by_actor_id uuid
);


--
-- Name: login_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_rate_limits (
    bucket_key character varying(80) NOT NULL,
    window_start timestamp(6) with time zone NOT NULL,
    request_count integer NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT login_rate_limits_request_count_check CHECK (((request_count >= 1) AND (request_count <= 1001)))
);


--
-- Name: member_id_issuances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_id_issuances (
    member_id text NOT NULL,
    year text NOT NULL,
    sequence integer NOT NULL,
    evidence_source character varying(32) NOT NULL,
    evidence_subject_id text,
    allocated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT member_id_issuances_format_check CHECK (((member_id = ((('HRM-'::text || year) || '-'::text) || lpad((sequence)::text, 6, '0'::text))) AND (year ~ '^[0-9]{4}$'::text) AND (sequence > 0))),
    CONSTRAINT member_id_issuances_source_check CHECK (((evidence_source)::text = ANY (ARRAY[('runtime_allocation'::character varying)::text, ('current_user_backfill'::character varying)::text, ('audit_log_backfill'::character varying)::text, ('operator_reconciled'::character varying)::text])))
);


--
-- Name: member_id_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_id_sequences (
    year text NOT NULL,
    last_sequence integer NOT NULL,
    CONSTRAINT member_id_sequences_last_sequence_check CHECK ((last_sequence > 0))
);


--
-- Name: name_cap_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.name_cap_registry (
    id text NOT NULL,
    normalized_name text NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    max_allowed integer DEFAULT 7 NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    type character varying NOT NULL,
    title character varying NOT NULL,
    message text NOT NULL,
    amount numeric(12,2),
    entity_type character varying,
    entity_id text,
    action_url character varying,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    order_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    unit_acquisition_cost numeric(10,2),
    binary_eligible_snapshot boolean,
    pu_value_snapshot integer,
    company_unit_cost_snapshot numeric(10,2),
    company_unit_margin_snapshot numeric(10,2),
    snapshot_source character varying(40),
    snapshotted_at timestamp(6) with time zone
);


--
-- Name: order_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id text NOT NULL,
    sender_id text NOT NULL,
    sender_name character varying(160) NOT NULL,
    sender_role character varying(40) NOT NULL,
    message character varying(2000) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT order_messages_nonblank_check CHECK ((length(btrim((message)::text)) >= 1))
);


--
-- Name: order_payment_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_payment_evidence (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id text NOT NULL,
    submitted_by uuid NOT NULL,
    sender_name character varying(160) NOT NULL,
    reference_number character varying(160) NOT NULL,
    amount numeric(10,2) NOT NULL,
    paid_at timestamp(6) with time zone NOT NULL,
    proof_path text NOT NULL,
    status character varying(24) DEFAULT 'submitted'::character varying NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp(6) with time zone,
    rejection_reason character varying(500),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: order_replacement_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_replacement_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id text NOT NULL,
    actor_id text NOT NULL,
    product_id text NOT NULL,
    kind text NOT NULL,
    quantity integer NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT order_replacement_requests_kind_check CHECK ((kind = ANY (ARRAY['distributor_replacement'::text, 'internal_replenishment'::text]))),
    CONSTRAINT order_replacement_requests_quantity_check CHECK (((quantity >= 1) AND (quantity <= 100))),
    CONSTRAINT order_replacement_requests_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'cancelled'::text, 'dispatched'::text])))
);


--
-- Name: order_replacement_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_replacement_units (
    request_id uuid NOT NULL,
    unit_id uuid NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id text NOT NULL,
    buyer_id text NOT NULL,
    seller_id text NOT NULL,
    order_type public."OrderType" NOT NULL,
    status public."OrderStatus" DEFAULT 'pending'::public."OrderStatus" NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    is_cross_purchase boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    payment_method character varying DEFAULT 'cash'::character varying,
    payment_reference character varying,
    payment_status character varying DEFAULT 'unpaid'::character varying,
    order_number text,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    is_non_member_sale boolean DEFAULT false NOT NULL,
    customer_name text,
    delivered_at timestamp(3) without time zone,
    paid_at timestamp(3) without time zone,
    delivery_address text,
    market_region_code text,
    market_region_name text,
    market_province_code text,
    market_province_name text,
    market_city_muni_code text,
    market_city_muni_name text,
    market_zip_code text,
    market_location_source text,
    fulfillment_region_code text,
    fulfillment_region_name text,
    fulfillment_province_code text,
    fulfillment_province_name text,
    fulfillment_city_muni_code text,
    fulfillment_city_muni_name text,
    fulfillment_outlet_name text,
    fulfillment_method character varying DEFAULT 'partner_pickup'::character varying NOT NULL,
    shipping_status character varying,
    shipping_fee numeric(10,2) DEFAULT 0 NOT NULL,
    courier_name character varying,
    courier_service character varying,
    courier_quote_reference character varying,
    financial_purpose character varying(24) DEFAULT 'commerce'::character varying NOT NULL,
    payment_sender_name character varying(120),
    payment_evidence_at timestamp(6) with time zone,
    payment_recorded_by_actor_id uuid,
    payment_verified_by_actor_id uuid,
    cancelled_at timestamp(6) with time zone,
    cancelled_by_actor_id text,
    cancelled_by_name character varying(160),
    cancelled_by_role character varying(40),
    cancellation_reason character varying(500),
    pickup_scheduled_at timestamp(6) with time zone,
    pickup_schedule_timezone character varying(40),
    payment_method_id uuid,
    payment_due_at timestamp(6) with time zone,
    payment_destination_snapshot jsonb,
    CONSTRAINT orders_financial_purpose_check CHECK (((financial_purpose)::text = ANY (ARRAY[('commerce'::character varying)::text, ('pin_sale'::character varying)::text])))
);


--
-- Name: package_binary_cap_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_binary_cap_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    revision bigint NOT NULL,
    package_id text NOT NULL,
    effective_day date NOT NULL,
    mode text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    daily_limit integer NOT NULL,
    first_limit integer,
    cutoff_minute integer,
    created_by text,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT package_binary_cap_policies_check CHECK ((((mode = 'daily_anytime'::text) AND (first_limit IS NULL) AND (cutoff_minute IS NULL)) OR ((mode = 'two_sessions'::text) AND (first_limit IS NOT NULL) AND (cutoff_minute IS NOT NULL) AND (first_limit > 0) AND (first_limit < daily_limit) AND ((cutoff_minute >= 1) AND (cutoff_minute <= 1439))))),
    CONSTRAINT package_binary_cap_policies_daily_limit_check CHECK (((daily_limit >= 1) AND (daily_limit <= 10000))),
    CONSTRAINT package_binary_cap_policies_mode_check CHECK ((mode = ANY (ARRAY['two_sessions'::text, 'daily_anytime'::text])))
);


--
-- Name: package_binary_cap_policies_revision_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.package_binary_cap_policies ALTER COLUMN revision ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.package_binary_cap_policies_revision_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: package_binary_carryover_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_binary_carryover_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    revision bigint NOT NULL,
    package_id text NOT NULL,
    effective_day date NOT NULL,
    enabled boolean NOT NULL,
    max_points integer NOT NULL,
    cap_policy_id uuid,
    created_by text,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT package_binary_carryover_policies_max_points_check CHECK ((max_points > 0))
);


--
-- Name: package_binary_carryover_policies_revision_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.package_binary_carryover_policies ALTER COLUMN revision ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.package_binary_carryover_policies_revision_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: package_binary_product_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_binary_product_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pair_event_id uuid NOT NULL,
    user_id text NOT NULL,
    product_id text NOT NULL,
    product_name_snapshot text NOT NULL,
    unit_cost_snapshot numeric(12,2) NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT package_binary_product_rewards_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT package_binary_product_rewards_unit_cost_snapshot_check CHECK ((unit_cost_snapshot > (0)::numeric))
);


--
-- Name: package_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_products (
    id text NOT NULL,
    package_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL
);


--
-- Name: package_upgrade_paths; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_upgrade_paths (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_package_id text NOT NULL,
    to_package_id text NOT NULL,
    customer_price numeric(12,2) NOT NULL,
    pin_price numeric(12,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT package_upgrade_paths_distinct_packages_check CHECK ((from_package_id <> to_package_id)),
    CONSTRAINT package_upgrade_paths_price_check CHECK (((customer_price > (0)::numeric) AND (pin_price > (0)::numeric)))
);


--
-- Name: package_upgrade_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_upgrade_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upgrade_path_id uuid NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    CONSTRAINT package_upgrade_products_quantity_check CHECK ((quantity > 0))
);


--
-- Name: packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.packages (
    id text NOT NULL,
    name text NOT NULL,
    price numeric(10,2) NOT NULL,
    direct_referral_bonus numeric(10,2) NOT NULL,
    pairing_bonus_value numeric(10,2) NOT NULL,
    point_php_value numeric(10,2) NOT NULL,
    point_reset_days integer DEFAULT 30 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    daily_product_pairing_cap integer DEFAULT 50,
    direct_referral_cap_enabled boolean DEFAULT true NOT NULL,
    daily_referral_cap integer DEFAULT 10 NOT NULL,
    binary_pair_cap_enabled boolean DEFAULT true NOT NULL,
    daily_binary_pair_cap integer DEFAULT 10 NOT NULL,
    product_binary_cap_enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT packages_daily_binary_pair_cap_check CHECK ((daily_binary_pair_cap >= 1)),
    CONSTRAINT packages_daily_referral_cap_positive CHECK ((daily_referral_cap > 0))
);


--
-- Name: pairing_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pairing_logs (
    id text NOT NULL,
    member_id text NOT NULL,
    left_points_used integer DEFAULT 0 NOT NULL,
    right_points_used integer DEFAULT 0 NOT NULL,
    pairs_created integer DEFAULT 0 NOT NULL,
    commission numeric(10,2) NOT NULL,
    date_created timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: passkey_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passkey_challenges (
    id text NOT NULL,
    user_id text,
    challenge text NOT NULL,
    purpose text NOT NULL,
    device_name text,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: passkey_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passkey_credentials (
    id text NOT NULL,
    user_id text NOT NULL,
    credential_id text NOT NULL,
    public_key bytea NOT NULL,
    counter bigint DEFAULT 0 NOT NULL,
    transports text[] DEFAULT ARRAY[]::text[] NOT NULL,
    device_name text NOT NULL,
    device_type text,
    backed_up boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    requested_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: payable_lot_forfeitures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payable_lot_forfeitures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deactivation_event_id text NOT NULL,
    source_type character varying(32) NOT NULL,
    direct_lot_id uuid,
    binary_lot_id uuid,
    product_binary_lot_id uuid,
    amount numeric(12,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rank_bonus_lot_id uuid,
    unilevel_lot_id uuid,
    CONSTRAINT payable_lot_forfeitures_exact_source_check CHECK (((num_nonnulls(direct_lot_id, binary_lot_id, product_binary_lot_id, rank_bonus_lot_id, unilevel_lot_id) = 1) AND ((((source_type)::text = 'direct_referral'::text) AND (direct_lot_id IS NOT NULL)) OR (((source_type)::text = 'binary'::text) AND (binary_lot_id IS NOT NULL)) OR (((source_type)::text = 'product_binary'::text) AND (product_binary_lot_id IS NOT NULL)) OR (((source_type)::text = 'rank_bonus'::text) AND (rank_bonus_lot_id IS NOT NULL)) OR (((source_type)::text = 'unilevel'::text) AND (unilevel_lot_id IS NOT NULL))))),
    CONSTRAINT payable_lot_forfeitures_positive_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text NOT NULL,
    type character varying NOT NULL,
    account_name character varying NOT NULL,
    account_number character varying NOT NULL,
    bank_name character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_enabled boolean DEFAULT true NOT NULL
);


--
-- Name: payout_destination_owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payout_destination_owners (
    destination_hash character varying(64) NOT NULL,
    identity_hash character varying(64) NOT NULL,
    first_registered_by text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payouts (
    id text NOT NULL,
    user_id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."PayoutStatus" DEFAULT 'pending'::public."PayoutStatus" NOT NULL,
    payment_method text,
    payment_reference text,
    approved_by text,
    requested_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamp(3) without time zone,
    cutoff_date timestamp(3) without time zone,
    notes text,
    transaction_number text,
    payout_date timestamp(3) without time zone,
    released_at timestamp(6) with time zone,
    batch_id character varying(40),
    disbursement_provider character varying(80),
    external_reference character varying(160),
    disbursed_amount numeric(10,2),
    disbursed_at timestamp(6) with time zone,
    released_by text
);


--
-- Name: person_account_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_account_documents (
    document_hash text NOT NULL,
    person_key text NOT NULL
);


--
-- Name: person_account_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_account_memberships (
    user_id text NOT NULL,
    person_key text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: person_account_totals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_account_totals (
    person_key text NOT NULL,
    account_count integer NOT NULL,
    CONSTRAINT person_account_totals_account_count_check CHECK (((account_count >= 1) AND (account_count <= 7)))
);


--
-- Name: pin_registration_product_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_registration_product_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pin_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    srp_snapshot numeric(10,2) NOT NULL,
    reseller_price_snapshot numeric(10,2) CONSTRAINT pin_registration_product_snaps_reseller_price_snapshot_not_null NOT NULL,
    unit_acquisition_cost_snapshot numeric(10,2) CONSTRAINT pin_registration_product_sn_unit_acquisition_cost_snap_not_null NOT NULL,
    CONSTRAINT pin_registration_product_snapshots_prices_check CHECK (((srp_snapshot > (0)::numeric) AND (reseller_price_snapshot > (0)::numeric) AND (unit_acquisition_cost_snapshot > (0)::numeric))),
    CONSTRAINT pin_registration_product_snapshots_quantity_check CHECK ((quantity > 0))
);


--
-- Name: pin_request_payment_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_request_payment_evidence (
    id text NOT NULL,
    pin_request_id text NOT NULL,
    payment_method_id text NOT NULL,
    provider_snapshot character varying(40) NOT NULL,
    account_name_snapshot character varying(160) NOT NULL,
    account_number_snapshot character varying(160) NOT NULL,
    bank_name_snapshot character varying(160),
    sender_name character varying(160) NOT NULL,
    reference_number character varying(160) NOT NULL,
    paid_at timestamp(6) with time zone NOT NULL,
    proof_path character varying(500) NOT NULL,
    status character varying(40) DEFAULT 'submitted'::character varying NOT NULL,
    reviewed_by_actor_id uuid,
    reviewed_at timestamp(6) with time zone,
    review_notes character varying(500),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pin_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_requests (
    id text NOT NULL,
    city_dist_id text NOT NULL,
    package_id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_method character varying DEFAULT 'cash_on_pickup'::text NOT NULL,
    payment_reference character varying,
    payment_sender_name character varying,
    payment_datetime timestamp with time zone,
    payment_status character varying DEFAULT 'unpaid'::text NOT NULL,
    status character varying DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    registration_snapshot jsonb,
    approved_by_actor_id uuid,
    approved_at timestamp(6) with time zone,
    rejected_by_actor_id uuid,
    rejected_at timestamp(6) with time zone,
    payment_due_at timestamp(6) with time zone,
    payment_method_id text,
    payment_destination_snapshot jsonb
);


--
-- Name: pin_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_transfers (
    id uuid NOT NULL,
    reference_number character varying(40) NOT NULL,
    admin_id text NOT NULL,
    recipient_id text NOT NULL,
    initiated_by_actor_id uuid,
    package_id text NOT NULL,
    pin_type character varying(24) NOT NULL,
    upgrade_from_package_id text,
    quantity integer NOT NULL,
    unit_allocation numeric(12,2) NOT NULL,
    reference_value numeric(12,2) NOT NULL,
    sale_value numeric(12,2) DEFAULT 0 NOT NULL,
    status character varying(32) DEFAULT 'in_transit'::character varying NOT NULL,
    notes text,
    dispatched_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    received_at timestamp(6) with time zone,
    received_by_actor_id uuid,
    rejected_at timestamp(6) with time zone,
    rejected_by_actor_id uuid,
    rejection_reason character varying(500),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pin_upgrade_product_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_upgrade_product_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pin_id text NOT NULL,
    product_id text NOT NULL,
    quantity integer NOT NULL,
    unit_acquisition_cost_snapshot numeric(10,2),
    srp_snapshot numeric(10,2),
    reseller_price_snapshot numeric(10,2),
    CONSTRAINT pin_upgrade_product_snapshots_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT pin_upgrade_product_snapshots_sealed_prices_check CHECK ((((srp_snapshot IS NULL) OR (srp_snapshot > (0)::numeric)) AND ((reseller_price_snapshot IS NULL) OR (reseller_price_snapshot > (0)::numeric)) AND ((unit_acquisition_cost_snapshot IS NULL) OR (unit_acquisition_cost_snapshot > (0)::numeric))))
);


--
-- Name: pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pins (
    id text NOT NULL,
    pin_code text NOT NULL,
    package_id text NOT NULL,
    city_dist_id text NOT NULL,
    status public."PinStatus" DEFAULT 'unused'::public."PinStatus" NOT NULL,
    used_by text,
    used_at timestamp(3) without time zone,
    generated_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    pin_type character varying DEFAULT 'registration'::character varying NOT NULL,
    upgrade_from_package_id text,
    pin_allocation_snapshot numeric(12,2),
    upgrade_customer_payment_snapshot numeric(12,2),
    upgrade_reseller_value_snapshot numeric(12,2),
    upgrade_acquisition_cost_snapshot numeric(12,2),
    upgrade_direct_allocation_snapshot numeric(12,2),
    upgrade_binary_allocation_snapshot numeric(12,2),
    upgrade_points_difference_snapshot integer,
    cancelled_at timestamp(3) without time zone,
    cancelled_by uuid,
    cancellation_reason character varying(500),
    upgrade_acquisition_tier_snapshot character varying(16),
    funding_order_id text,
    funding_pin_request_id text,
    registration_package_name_snapshot character varying,
    registration_customer_payment_snapshot numeric(12,2),
    registration_reseller_value_snapshot numeric(12,2),
    registration_acquisition_cost_snapshot numeric(12,2),
    registration_acquisition_tier_snapshot character varying(16),
    registration_direct_allocation_snapshot numeric(12,2),
    registration_binary_allocation_snapshot numeric(12,2),
    registration_points_snapshot integer,
    registration_product_line_count_snapshot integer,
    registration_units_snapshot integer,
    upgrade_product_line_count_snapshot integer,
    upgrade_units_snapshot integer,
    funding_pin_transfer_id uuid,
    generated_by_actor_id uuid,
    cancellation_disposition character varying(32),
    cancellation_reference character varying(120),
    cancellation_amount numeric(12,2),
    CONSTRAINT pins_upgrade_acquisition_tier_snapshot_check CHECK (((upgrade_acquisition_tier_snapshot IS NULL) OR ((upgrade_acquisition_tier_snapshot)::text = ANY (ARRAY[('city'::character varying)::text, ('branch'::character varying)::text]))))
);


--
-- Name: pos_adjustment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_adjustment_items (
    id uuid NOT NULL,
    adjustment_request_id uuid NOT NULL,
    pos_transaction_item_id uuid NOT NULL,
    quantity integer NOT NULL,
    disposition character varying(30) NOT NULL,
    unit_price_snapshot numeric(12,2) NOT NULL,
    subtotal_snapshot numeric(12,2) NOT NULL,
    CONSTRAINT pos_adjustment_items_disposition_valid CHECK (((disposition)::text = ANY (ARRAY[('resellable'::character varying)::text, ('damaged'::character varying)::text, ('expired'::character varying)::text]))),
    CONSTRAINT pos_adjustment_items_quantity_positive CHECK ((quantity > 0))
);


--
-- Name: pos_adjustment_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_adjustment_requests (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    pos_transaction_id uuid NOT NULL,
    requested_by_id text NOT NULL,
    reviewed_by_id text,
    request_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    reason character varying(500) NOT NULL,
    review_notes character varying(500),
    amount_snapshot numeric(12,2) NOT NULL,
    requested_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reviewed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: pos_cash_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_cash_movements (
    id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    owner_id text NOT NULL,
    shift_id uuid NOT NULL,
    terminal_id uuid NOT NULL,
    requested_by_id text NOT NULL,
    reviewed_by_id text,
    movement_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    purpose character varying(80) NOT NULL,
    notes character varying(500) NOT NULL,
    reference character varying(160),
    review_notes character varying(500),
    requested_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reviewed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT pos_cash_movements_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT pos_cash_movements_status_check CHECK (((status)::text = ANY (ARRAY[('applied'::character varying)::text, ('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text]))),
    CONSTRAINT pos_cash_movements_type_check CHECK (((movement_type)::text = ANY (ARRAY[('paid_in'::character varying)::text, ('paid_out'::character varying)::text])))
);


--
-- Name: pos_enrollment_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_enrollment_rate_limits (
    bucket_key character varying(96) NOT NULL,
    window_start timestamp(6) with time zone NOT NULL,
    request_count integer DEFAULT 1 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL
);


--
-- Name: pos_inventory_allowances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_inventory_allowances (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    terminal_id uuid NOT NULL,
    product_id text NOT NULL,
    allocated_quantity integer NOT NULL,
    consumed_quantity integer DEFAULT 0 NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: pos_registration_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_registration_events (
    id uuid NOT NULL,
    intake_id uuid NOT NULL,
    actor_id text NOT NULL,
    from_status public."PosRegistrationIntakeStatus",
    to_status public."PosRegistrationIntakeStatus" NOT NULL,
    action character varying(80) NOT NULL,
    reason character varying(500),
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pos_registration_intakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_registration_intakes (
    id uuid NOT NULL,
    client_intake_id uuid NOT NULL,
    receipt_number character varying(80) NOT NULL,
    owner_id text NOT NULL,
    terminal_id uuid NOT NULL,
    shift_id uuid NOT NULL,
    cashier_id text NOT NULL,
    package_id text NOT NULL,
    payment_method_id text,
    pin_id text,
    status public."PosRegistrationIntakeStatus" DEFAULT 'draft_intake'::public."PosRegistrationIntakeStatus" NOT NULL,
    applicant_full_name character varying(180) NOT NULL,
    applicant_mobile character varying(40) NOT NULL,
    applicant_email character varying(180),
    applicant_birthday date NOT NULL,
    applicant_birthplace character varying(240) NOT NULL,
    applicant_address jsonb NOT NULL,
    identity_document_type character varying(80),
    identity_document_reference character varying(180),
    referrer_username character varying(120) NOT NULL,
    preferred_position character varying(10),
    applicant_snapshot jsonb NOT NULL,
    payment_method_snapshot character varying(160) NOT NULL,
    payment_reference character varying(160),
    payment_proof_url text,
    amount_snapshot numeric(12,2) NOT NULL,
    captured_offline boolean DEFAULT false NOT NULL,
    payment_verified_at timestamp(6) with time zone,
    approver_id text,
    released_at timestamp(6) with time zone,
    released_by_id text,
    encoding_started_at timestamp(6) with time zone,
    encoder_id text,
    completed_at timestamp(6) with time zone,
    completed_user_id text,
    exception_reason character varying(500),
    notes character varying(1000),
    local_created_at timestamp(6) with time zone NOT NULL,
    server_received_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    registration_snapshot jsonb,
    identity_document_hash character varying(64)
);


--
-- Name: pos_shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_shifts (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    terminal_id uuid NOT NULL,
    opened_by_id text NOT NULL,
    closed_by_id text,
    status public."PosShiftStatus" DEFAULT 'open'::public."PosShiftStatus" NOT NULL,
    opening_cash numeric(12,2) DEFAULT 0 NOT NULL,
    expected_cash_snapshot numeric(12,2),
    counted_cash numeric(12,2),
    variance_snapshot numeric(12,2),
    opened_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    local_closed_at timestamp(6) with time zone,
    server_finalized_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    active_terminal_key uuid,
    closing_count_attempts integer DEFAULT 0 NOT NULL,
    closing_explanation character varying(1000),
    closing_submitted_at timestamp(6) with time zone
);


--
-- Name: pos_sync_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_sync_events (
    id uuid NOT NULL,
    terminal_id uuid NOT NULL,
    pos_transaction_id uuid,
    event_type character varying(80) NOT NULL,
    outcome character varying(40) NOT NULL,
    request_checksum character varying(128),
    details jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pos_terminal_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_terminal_enrollments (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    created_by_id text NOT NULL,
    terminal_name character varying(120) NOT NULL,
    code_hash character varying(64) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    used_at timestamp(6) with time zone,
    revoked_at timestamp(6) with time zone,
    enrolled_terminal_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pos_terminals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_terminals (
    id uuid NOT NULL,
    owner_id text NOT NULL,
    installation_id character varying(120) NOT NULL,
    name character varying(120) NOT NULL,
    platform character varying(80),
    is_active boolean DEFAULT true NOT NULL,
    last_catalog_at timestamp(6) with time zone,
    last_inventory_at timestamp(6) with time zone,
    last_synced_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    receipt_code character varying(7) NOT NULL,
    receipt_sequence_next integer DEFAULT 1 NOT NULL
);


--
-- Name: pos_transaction_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_transaction_items (
    id uuid NOT NULL,
    pos_transaction_id uuid NOT NULL,
    product_id text NOT NULL,
    product_name_snapshot text NOT NULL,
    product_type_snapshot character varying(40) NOT NULL,
    quantity integer NOT NULL,
    unit_price_snapshot numeric(12,2) NOT NULL,
    unit_cost_snapshot numeric(12,2) NOT NULL,
    pu_value_snapshot integer DEFAULT 0 NOT NULL,
    subtotal_snapshot numeric(12,2) NOT NULL,
    local_stock_before integer NOT NULL,
    local_stock_after integer NOT NULL
);


--
-- Name: pos_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_transactions (
    id uuid NOT NULL,
    client_transaction_id uuid NOT NULL,
    owner_id text NOT NULL,
    terminal_id uuid NOT NULL,
    shift_id uuid,
    cashier_id text NOT NULL,
    transaction_type public."PosTransactionType" NOT NULL,
    status public."PosTransactionStatus" DEFAULT 'pending_sync'::public."PosTransactionStatus" NOT NULL,
    member_id text,
    customer_name_snapshot text,
    payment_method_snapshot character varying(120) NOT NULL,
    payment_reference character varying(160),
    subtotal_snapshot numeric(12,2) NOT NULL,
    discount_snapshot numeric(12,2) DEFAULT 0 NOT NULL,
    total_snapshot numeric(12,2) NOT NULL,
    amount_received_snapshot numeric(12,2) NOT NULL,
    change_snapshot numeric(12,2) DEFAULT 0 NOT NULL,
    order_id text,
    registration_id uuid,
    registration_payload jsonb,
    notes text,
    local_created_at timestamp(6) with time zone NOT NULL,
    server_received_at timestamp(6) with time zone,
    finalized_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    receipt_number character varying(80) NOT NULL,
    receipt_sequence integer,
    payment_method_id text,
    reviewed_by_id text,
    reviewed_at timestamp(6) with time zone,
    review_notes character varying(500)
);


--
-- Name: product_area_visibility; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_area_visibility (
    id text NOT NULL,
    product_id text NOT NULL,
    distributor_id text NOT NULL,
    is_visible boolean DEFAULT true NOT NULL
);


--
-- Name: product_binary_account_holds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_account_holds (
    user_id text NOT NULL,
    inactive_since timestamp with time zone,
    forfeited_before timestamp with time zone
);


--
-- Name: product_binary_funding_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_funding_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    funding_lot_id uuid,
    commission_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    is_unfunded boolean DEFAULT false NOT NULL,
    consumed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_funding_consumption_positive CHECK ((amount > (0)::numeric))
);


--
-- Name: product_binary_funding_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_funding_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    inventory_movement_id uuid,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    snapshot_source character varying NOT NULL,
    allocated_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    order_id text,
    payment_status_snapshot character varying(20),
    paid_at_snapshot timestamp(6) with time zone,
    delivered_at_snapshot timestamp(6) with time zone,
    eligible_units_snapshot integer,
    total_pu_snapshot integer,
    gross_margin_snapshot numeric(12,2),
    snapshot_version character varying(40),
    reconciliation_status character varying(40) DEFAULT 'exact'::character varying NOT NULL,
    CONSTRAINT product_binary_funding_nonnegative CHECK (((original_amount >= (0)::numeric) AND (remaining_amount >= (0)::numeric)))
);


--
-- Name: product_binary_inventory_reserve_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_inventory_reserve_transfers (
    order_event_id uuid CONSTRAINT product_binary_inventory_reserve_transf_order_event_id_not_null NOT NULL,
    source_order_item_id text CONSTRAINT product_binary_inventory_reserve__source_order_item_id_not_null NOT NULL,
    units integer NOT NULL,
    CONSTRAINT product_binary_inventory_reserve_transfers_units_check CHECK ((units > 0))
);


--
-- Name: product_binary_inventory_reserves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_inventory_reserves (
    source_order_item_id text NOT NULL,
    distributor_id text NOT NULL,
    product_id text NOT NULL,
    funded_units integer NOT NULL,
    remaining_units integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source_movement_id uuid,
    city_order_item_id text GENERATED ALWAYS AS (
CASE
    WHEN (source_movement_id IS NULL) THEN source_order_item_id
    ELSE NULL::text
END) STORED,
    CONSTRAINT product_binary_branch_lot_key CHECK (((source_movement_id IS NULL) OR (source_order_item_id = ('branch:'::text || (source_movement_id)::text)))),
    CONSTRAINT product_binary_inventory_reserves_check CHECK (((remaining_units >= 0) AND (remaining_units <= funded_units))),
    CONSTRAINT product_binary_inventory_reserves_funded_units_check CHECK ((funded_units > 0))
);


--
-- Name: product_binary_non_member_reserve_processed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_non_member_reserve_processed (
    order_id text NOT NULL
);


--
-- Name: product_binary_non_member_reserve_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_non_member_reserve_releases (
    order_id text NOT NULL,
    source_order_item_id text CONSTRAINT product_binary_non_member_reserve_source_order_item_id_not_null NOT NULL,
    units integer NOT NULL,
    released_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_non_member_reserve_releases_units_check CHECK ((units > 0))
);


--
-- Name: product_binary_non_member_reserve_restorations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_non_member_reserve_restorations (
    adjustment_id uuid CONSTRAINT product_binary_non_member_reserve_restor_adjustment_id_not_null NOT NULL,
    order_id text CONSTRAINT product_binary_non_member_reserve_restoration_order_id_not_null NOT NULL,
    source_order_item_id text CONSTRAINT product_binary_non_member_reserv_source_order_item_id_not_null1 NOT NULL,
    units integer NOT NULL,
    restored_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT product_binary_non_member_reserve_restorat_restored_at_not_null NOT NULL,
    CONSTRAINT product_binary_non_member_reserve_restorations_units_check CHECK ((units > 0))
);


--
-- Name: product_binary_order_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_order_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id text NOT NULL,
    buyer_user_id text NOT NULL,
    eligible_units integer NOT NULL,
    total_pu integer NOT NULL,
    recorded_gross_margin numeric(12,2) NOT NULL,
    processed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    settlement_job_id uuid,
    payment_status_snapshot character varying(20),
    paid_at_snapshot timestamp(6) with time zone,
    delivered_at_snapshot timestamp(6) with time zone,
    snapshot_version character varying(40)
);


--
-- Name: product_binary_package_reserve_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_package_reserve_releases (
    reference_type text NOT NULL,
    reference_id text NOT NULL,
    product_id text NOT NULL,
    released_units integer DEFAULT 0 NOT NULL,
    CONSTRAINT product_binary_package_reserve_releases_released_units_check CHECK ((released_units >= 0))
);


--
-- Name: product_binary_pair_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pair_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_event_id uuid NOT NULL,
    recipient_user_id text NOT NULL,
    source_user_id text NOT NULL,
    source_leg character varying NOT NULL,
    source_pu integer NOT NULL,
    opening_left_pu integer NOT NULL,
    opening_right_pu integer NOT NULL,
    completed_pairs integer NOT NULL,
    payable_pairs integer NOT NULL,
    cap_flashout_pairs integer NOT NULL,
    inactive_flashout_pairs integer NOT NULL,
    closing_left_pu integer NOT NULL,
    closing_right_pu integer NOT NULL,
    package_id_snapshot text,
    package_name_snapshot character varying NOT NULL,
    rank_id_snapshot text,
    rank_name_snapshot character varying NOT NULL,
    pair_rate_points numeric(12,2) NOT NULL,
    peso_per_point numeric(8,4) NOT NULL,
    pair_rate_amount numeric(12,2) NOT NULL,
    payable_amount numeric(12,2) NOT NULL,
    flashout_amount numeric(12,2) NOT NULL,
    cap_enabled boolean NOT NULL,
    cap_limit integer,
    normal_commission_id text,
    flashout_commission_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    opening_lifetime_pairs integer,
    opening_lifetime_payable integer,
    opening_lifetime_flashout integer,
    closing_lifetime_pairs integer,
    closing_lifetime_payable integer,
    closing_lifetime_flashout integer,
    CONSTRAINT product_binary_pair_counts CHECK ((completed_pairs = ((payable_pairs + cap_flashout_pairs) + inactive_flashout_pairs))),
    CONSTRAINT product_binary_pair_events_lifetime_snapshot_check CHECK ((((opening_lifetime_pairs IS NULL) AND (opening_lifetime_payable IS NULL) AND (opening_lifetime_flashout IS NULL) AND (closing_lifetime_pairs IS NULL) AND (closing_lifetime_payable IS NULL) AND (closing_lifetime_flashout IS NULL)) OR ((opening_lifetime_pairs IS NOT NULL) AND (opening_lifetime_payable IS NOT NULL) AND (opening_lifetime_flashout IS NOT NULL) AND (closing_lifetime_pairs IS NOT NULL) AND (closing_lifetime_payable IS NOT NULL) AND (closing_lifetime_flashout IS NOT NULL) AND (opening_lifetime_pairs >= 0) AND (opening_lifetime_payable >= 0) AND (opening_lifetime_flashout >= 0) AND (closing_lifetime_pairs >= 0) AND (closing_lifetime_payable >= 0) AND (closing_lifetime_flashout >= 0)))),
    CONSTRAINT product_binary_pair_nonnegative CHECK (((completed_pairs >= 0) AND (payable_amount >= (0)::numeric) AND (flashout_amount >= (0)::numeric)))
);


--
-- Name: product_binary_payable_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_payable_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    commission_id text NOT NULL,
    user_id text NOT NULL,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    allocated_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_lot_nonnegative CHECK (((original_amount >= (0)::numeric) AND (remaining_amount >= (0)::numeric)))
);


--
-- Name: product_binary_payout_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_payout_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payout_id text NOT NULL,
    payable_lot_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    allocated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_consumption_positive CHECK ((amount > (0)::numeric))
);


--
-- Name: product_binary_pool_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pool_allocations (
    week_start date NOT NULL,
    recipient_user_id text NOT NULL,
    payable_pairs bigint NOT NULL,
    amount_centavos bigint NOT NULL,
    commission_id text,
    retained_at timestamp with time zone,
    retained_reason text,
    partial_retained_centavos bigint DEFAULT 0 CONSTRAINT product_binary_pool_allocati_partial_retained_centavos_not_null NOT NULL,
    CONSTRAINT product_binary_allocation_retained_state CHECK ((((retained_at IS NULL) AND ((retained_reason IS NULL) OR (partial_retained_centavos > 0))) OR ((retained_at IS NOT NULL) AND (retained_reason IS NOT NULL) AND (commission_id IS NULL) AND (partial_retained_centavos = 0)))),
    CONSTRAINT product_binary_pool_allocations_amount_centavos_check CHECK ((amount_centavos >= 0)),
    CONSTRAINT product_binary_pool_allocations_check CHECK (((commission_id IS NULL) OR (amount_centavos > 0))),
    CONSTRAINT product_binary_pool_allocations_check1 CHECK (((partial_retained_centavos >= 0) AND (partial_retained_centavos < GREATEST(amount_centavos, (1)::bigint)))),
    CONSTRAINT product_binary_pool_allocations_payable_pairs_check CHECK ((payable_pairs > 0))
);


--
-- Name: product_binary_pool_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pool_orders (
    order_event_id uuid NOT NULL,
    week_start date NOT NULL,
    funded_units integer,
    CONSTRAINT product_binary_pool_orders_funded_units_check CHECK ((funded_units >= 0))
);


--
-- Name: product_binary_pool_pairs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pool_pairs (
    pair_event_id uuid NOT NULL,
    order_event_id uuid NOT NULL,
    week_start date NOT NULL
);


--
-- Name: product_binary_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_positions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    left_carryover_pu integer DEFAULT 0 NOT NULL,
    right_carryover_pu integer DEFAULT 0 NOT NULL,
    lifetime_pairs integer DEFAULT 0 NOT NULL,
    lifetime_payable integer DEFAULT 0 NOT NULL,
    lifetime_flashout integer DEFAULT 0 NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_position_nonnegative CHECK (((left_carryover_pu >= 0) AND (right_carryover_pu >= 0)))
);


--
-- Name: product_binary_prepared_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_prepared_recipients (
    week_start date NOT NULL,
    recipient_user_id text NOT NULL,
    payable_pairs bigint NOT NULL,
    CONSTRAINT product_binary_prepared_recipients_payable_pairs_check CHECK ((payable_pairs > 0))
);


--
-- Name: product_binary_pu_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_pu_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipient_user_id text NOT NULL,
    order_event_id uuid NOT NULL,
    leg text NOT NULL,
    original_pu integer NOT NULL,
    remaining_pu integer NOT NULL,
    consumed_pu integer DEFAULT 0 NOT NULL,
    expired_pu integer DEFAULT 0 NOT NULL,
    earned_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    expired_at timestamp with time zone,
    CONSTRAINT product_binary_pu_lots_check CHECK ((original_pu = ((remaining_pu + consumed_pu) + expired_pu))),
    CONSTRAINT product_binary_pu_lots_check1 CHECK ((expires_at > earned_at)),
    CONSTRAINT product_binary_pu_lots_consumed_pu_check CHECK ((consumed_pu >= 0)),
    CONSTRAINT product_binary_pu_lots_expired_pu_check CHECK ((expired_pu >= 0)),
    CONSTRAINT product_binary_pu_lots_leg_check CHECK ((leg = ANY (ARRAY['left'::text, 'right'::text]))),
    CONSTRAINT product_binary_pu_lots_original_pu_check CHECK ((original_pu > 0)),
    CONSTRAINT product_binary_pu_lots_remaining_pu_check CHECK ((remaining_pu >= 0))
);


--
-- Name: product_binary_replacement_reserve_processed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_replacement_reserve_processed (
    dispatch_id uuid CONSTRAINT product_binary_replacement_reserve_process_dispatch_id_not_null NOT NULL
);


--
-- Name: product_binary_replacement_reserve_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_replacement_reserve_releases (
    dispatch_id uuid CONSTRAINT product_binary_replacement_reserve_release_dispatch_id_not_null NOT NULL,
    source_order_item_id text CONSTRAINT product_binary_replacement_reserv_source_order_item_id_not_null NOT NULL,
    units integer NOT NULL,
    CONSTRAINT product_binary_replacement_reserve_releases_units_check CHECK ((units > 0))
);


--
-- Name: product_binary_settlement_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_settlement_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id text NOT NULL,
    status character varying(48) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    qualification_status character varying(48) DEFAULT 'awaiting_qualification'::character varying NOT NULL,
    buyer_user_id text,
    payment_status_snapshot character varying(20),
    paid_at_snapshot timestamp(6) with time zone,
    delivered_at_snapshot timestamp(6) with time zone,
    eligible_units_snapshot integer,
    total_pu_snapshot integer,
    gross_margin_snapshot numeric(12,2),
    snapshot_version character varying(40),
    qualified_at timestamp(6) with time zone,
    CONSTRAINT product_binary_settlement_jobs_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT product_binary_settlement_jobs_qualification_check CHECK (((qualification_status)::text = ANY (ARRAY[('awaiting_qualification'::character varying)::text, ('waiting_for_paid_delivery'::character varying)::text, ('qualified_paid_delivery'::character varying)::text, ('ineligible_zero_pu'::character varying)::text, ('legacy_snapshot_reconciliation'::character varying)::text, ('legacy_completed'::character varying)::text]))),
    CONSTRAINT product_binary_settlement_jobs_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('failed'::character varying)::text, ('completed'::character varying)::text, ('waiting_payment'::character varying)::text, ('reconciliation_required'::character varying)::text])))
);


--
-- Name: product_binary_week_funding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_week_funding (
    week_start date NOT NULL,
    allocated_centavos bigint NOT NULL,
    retained_centavos bigint NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_binary_week_funding_allocated_centavos_check CHECK ((allocated_centavos >= 0)),
    CONSTRAINT product_binary_week_funding_retained_centavos_check CHECK ((retained_centavos >= 0))
);


--
-- Name: product_binary_week_preparation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_binary_week_preparation (
    week_start date NOT NULL,
    stage text DEFAULT 'orders'::text NOT NULL,
    order_cursor uuid,
    pair_cursor uuid,
    recipient_cursor text,
    pool_centavos bigint DEFAULT 0 NOT NULL,
    total_pairs bigint DEFAULT 0 NOT NULL,
    allocated_centavos bigint DEFAULT 0 NOT NULL,
    verification_cursor text,
    verified_pairs bigint DEFAULT 0 NOT NULL,
    verified_centavos bigint DEFAULT 0 NOT NULL,
    verified_recipients bigint DEFAULT 0 NOT NULL,
    verification_completed_at timestamp with time zone,
    CONSTRAINT product_binary_week_preparation_allocated_centavos_check CHECK ((allocated_centavos >= 0)),
    CONSTRAINT product_binary_week_preparation_pool_centavos_check CHECK ((pool_centavos >= 0)),
    CONSTRAINT product_binary_week_preparation_stage_check CHECK ((stage = ANY (ARRAY['orders'::text, 'pairs'::text, 'allocations'::text, 'complete'::text]))),
    CONSTRAINT product_binary_week_preparation_total_pairs_check CHECK ((total_pairs >= 0))
);


--
-- Name: product_reward_claim_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reward_claim_allocations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    claim_id uuid NOT NULL,
    reward_id uuid NOT NULL,
    unit_number integer NOT NULL,
    CONSTRAINT product_reward_claim_allocations_unit_number_check CHECK ((unit_number > 0))
);


--
-- Name: product_reward_claim_proofs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reward_claim_proofs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_hash text NOT NULL,
    owner_id text NOT NULL,
    actor_id text NOT NULL,
    reseller_id text NOT NULL,
    terminal_id uuid NOT NULL,
    shift_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_reward_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reward_claims (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_request_id uuid NOT NULL,
    proof_id uuid NOT NULL,
    owner_id text NOT NULL,
    actor_id text NOT NULL,
    reseller_id text NOT NULL,
    product_id text NOT NULL,
    terminal_id uuid NOT NULL,
    shift_id uuid NOT NULL,
    quantity integer NOT NULL,
    product_name_snapshot text DEFAULT ''::text NOT NULL,
    outlet_name_snapshot text DEFAULT ''::text NOT NULL,
    actor_name_snapshot text DEFAULT ''::text NOT NULL,
    unit_cost_snapshot numeric(12,2) DEFAULT 0 NOT NULL,
    stock_before integer DEFAULT 0 NOT NULL,
    stock_after integer DEFAULT 0 NOT NULL,
    released_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_reward_claims_quantity_check CHECK (((quantity >= 1) AND (quantity <= 100)))
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    type public."ProductType" NOT NULL,
    price numeric(10,2) NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cost_price numeric(10,2) DEFAULT 0 NOT NULL,
    regional_price numeric(10,2) DEFAULT 0 NOT NULL,
    provincial_price numeric(10,2) DEFAULT 0 NOT NULL,
    city_price numeric(10,2) DEFAULT 0 NOT NULL,
    reseller_price numeric(10,2) DEFAULT 0 NOT NULL,
    binary_eligible boolean DEFAULT true NOT NULL,
    pu_value integer DEFAULT 0 NOT NULL,
    branch_price numeric(10,2) DEFAULT 0 NOT NULL,
    barcode text
);


--
-- Name: public_verification_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_verification_rate_limits (
    bucket_key character varying(80) NOT NULL,
    window_start timestamp(6) with time zone NOT NULL,
    request_count integer NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT public_verification_rate_limits_count_check CHECK (((request_count >= 1) AND (request_count <= 31)))
);


--
-- Name: rank_bonus_awards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rank_bonus_awards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    quarter_start timestamp with time zone NOT NULL,
    user_id text NOT NULL,
    milestone text NOT NULL,
    bottles integer NOT NULL,
    referrals integer NOT NULL,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    commission_id text NOT NULL,
    allocated_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT rank_bonus_awards_check CHECK (((remaining_amount >= (0)::numeric) AND (remaining_amount <= original_amount))),
    CONSTRAINT rank_bonus_awards_original_amount_check CHECK ((original_amount > (0)::numeric))
);


--
-- Name: rank_bonus_funding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rank_bonus_funding (
    reference text NOT NULL,
    quarter_start timestamp with time zone NOT NULL,
    amount numeric(12,2) NOT NULL,
    funded_by text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT rank_bonus_funding_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT rank_bonus_funding_reference_check CHECK (((length(btrim(reference)) >= 1) AND (length(btrim(reference)) <= 120)))
);


--
-- Name: rank_bonus_payout_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rank_bonus_payout_consumptions (
    payout_id text NOT NULL,
    award_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    CONSTRAINT rank_bonus_payout_consumptions_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: rank_bonus_programs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rank_bonus_programs (
    quarter_start timestamp with time zone NOT NULL,
    quarter_end timestamp with time zone NOT NULL,
    milestones jsonb NOT NULL,
    CONSTRAINT rank_bonus_programs_check CHECK ((quarter_end > quarter_start)),
    CONSTRAINT rank_bonus_programs_milestones_check CHECK (((jsonb_typeof(milestones) = 'array'::text) AND (jsonb_array_length(milestones) > 0)))
);


--
-- Name: rank_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rank_periods (
    id text NOT NULL,
    package_id text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ranks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ranks (
    id text NOT NULL,
    name text NOT NULL,
    required_pu integer NOT NULL,
    pair_income numeric(10,2) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    package_id text NOT NULL,
    sequence integer NOT NULL
);


--
-- Name: registration_financials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_financials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pin_id text NOT NULL,
    city_dist_id text NOT NULL,
    reseller_id text NOT NULL,
    package_id text NOT NULL,
    customer_payment numeric(12,2) NOT NULL,
    product_acquisition_cost numeric(12,2) NOT NULL,
    reseller_value numeric(12,2) NOT NULL,
    pin_allocation numeric(12,2) NOT NULL,
    registration_profit numeric(12,2) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    payment_status character varying DEFAULT 'paid'::character varying NOT NULL,
    paid_at timestamp(3) without time zone,
    package_name_snapshot text NOT NULL,
    direct_referral_allocation numeric(12,2) NOT NULL,
    binary_commission_allocation numeric(12,2) NOT NULL,
    binary_points_per_pair integer NOT NULL,
    binary_point_peso_rate numeric(8,4) NOT NULL,
    registration_channel character varying DEFAULT 'legacy'::character varying NOT NULL,
    allocation_snapshot_source character varying DEFAULT 'estimated_legacy'::character varying NOT NULL,
    package_units_snapshot integer
);


--
-- Name: request_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_receipts (
    request_key text NOT NULL,
    fingerprint character(64) NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: reseller_deactivation_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reseller_deactivation_events (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    reseller_id text NOT NULL,
    processed_by text NOT NULL,
    flushed_points integer NOT NULL,
    points_value numeric(12,2) NOT NULL,
    wallet_value numeric(12,2) NOT NULL,
    total_flushed numeric(12,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    liability_liquidation_version character varying(40) DEFAULT 'deactivation-liability-v1'::character varying,
    CONSTRAINT reseller_deactivation_values_check CHECK (((flushed_points >= 0) AND (points_value >= (0)::numeric) AND (wallet_value >= (0)::numeric) AND (total_flushed = (points_value + wallet_value))))
);


--
-- Name: reseller_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reseller_profiles (
    id text NOT NULL,
    user_id text NOT NULL,
    package_id text NOT NULL,
    city_dist_id text NOT NULL,
    pin_id text NOT NULL,
    total_points integer DEFAULT 0 NOT NULL,
    points_reset_at timestamp(3) without time zone,
    daily_referral_count integer DEFAULT 0 NOT NULL,
    last_referral_date timestamp(3) without time zone,
    daily_pairs_count integer DEFAULT 0 NOT NULL,
    last_pairs_date timestamp(3) without time zone,
    pending_pairing_balance numeric(10,2) DEFAULT 0 NOT NULL,
    left_points integer DEFAULT 0,
    right_points integer DEFAULT 0,
    daily_pairing_count integer DEFAULT 0 NOT NULL,
    daily_pairing_date date,
    rank text DEFAULT 'default'::text NOT NULL,
    total_pu integer DEFAULT 0 NOT NULL,
    qualification_quarter_start timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: reward_stock_dispatch_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reward_stock_dispatch_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dispatch_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    cycle integer NOT NULL
);


--
-- Name: reward_stock_dispatches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reward_stock_dispatches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_request_id uuid NOT NULL,
    supplier_id text NOT NULL,
    recipient_id text NOT NULL,
    actor_id text NOT NULL,
    product_id text NOT NULL,
    kind text NOT NULL,
    quantity integer NOT NULL,
    supplier_name text DEFAULT ''::text NOT NULL,
    recipient_name text DEFAULT ''::text NOT NULL,
    actor_name text DEFAULT ''::text NOT NULL,
    product_name text DEFAULT ''::text NOT NULL,
    supplier_role text DEFAULT ''::text NOT NULL,
    unit_cost_snapshot numeric(12,2) DEFAULT 0 NOT NULL,
    stock_before integer DEFAULT 0 NOT NULL,
    stock_after integer DEFAULT 0 NOT NULL,
    dispatched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reward_stock_dispatches_check CHECK ((supplier_id <> recipient_id)),
    CONSTRAINT reward_stock_dispatches_kind_check CHECK ((kind = ANY (ARRAY['distributor_replacement'::text, 'internal_replenishment'::text]))),
    CONSTRAINT reward_stock_dispatches_quantity_check CHECK (((quantity >= 1) AND (quantity <= 100)))
);


--
-- Name: reward_stock_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reward_stock_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dispatch_id uuid NOT NULL,
    actor_id text NOT NULL,
    actor_name text DEFAULT ''::text NOT NULL,
    stock_before integer DEFAULT 0 NOT NULL,
    stock_after integer DEFAULT 0 NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reward_stock_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reward_stock_units (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    claim_allocation_id uuid NOT NULL,
    origin_outlet_id text NOT NULL,
    product_id text NOT NULL,
    kind text NOT NULL,
    classification_source text DEFAULT 'claim'::text NOT NULL,
    holder_id text,
    current_dispatch_id uuid,
    cycle integer DEFAULT 0 NOT NULL,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reward_stock_units_check CHECK ((((settled_at IS NULL) AND (holder_id IS NOT NULL)) OR ((settled_at IS NOT NULL) AND (holder_id IS NULL) AND (current_dispatch_id IS NULL)))),
    CONSTRAINT reward_stock_units_cycle_check CHECK ((cycle >= 0)),
    CONSTRAINT reward_stock_units_kind_check CHECK ((kind = ANY (ARRAY['distributor_replacement'::text, 'internal_replenishment'::text])))
);


--
-- Name: staff_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_profiles (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text NOT NULL,
    owner_id text NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    staff_type text DEFAULT 'custom'::text NOT NULL
);


--
-- Name: support_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_attachments (
    id text NOT NULL,
    request_id text NOT NULL,
    storage_path text NOT NULL,
    filename text NOT NULL,
    mime_type text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_captcha_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_captcha_challenges (
    id uuid NOT NULL,
    answer_digest text NOT NULL,
    client_fingerprint text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    used_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id text NOT NULL,
    request_id text NOT NULL,
    author_id text,
    author_name text NOT NULL,
    author_role text NOT NULL,
    message text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_requests (
    id text NOT NULL,
    user_id text,
    source public."SupportRequestSource" DEFAULT 'public'::public."SupportRequestSource" NOT NULL,
    category public."SupportRequestCategory" NOT NULL,
    name text,
    email text,
    subject text NOT NULL,
    message text NOT NULL,
    status public."SupportRequestStatus" DEFAULT 'new'::public."SupportRequestStatus" NOT NULL,
    admin_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    ticket_number text NOT NULL,
    priority public."SupportRequestPriority" DEFAULT 'normal'::public."SupportRequestPriority" NOT NULL,
    assigned_to text,
    category_detail text,
    submitter_fingerprint text,
    email_fingerprint text
);


--
-- Name: support_ticket_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.support_ticket_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: support_typing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_typing (
    request_id text NOT NULL,
    actor_id text NOT NULL,
    name text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    updated_by text,
    CONSTRAINT product_binary_pair_amount_valid CHECK (
CASE
    WHEN (key = 'product_binary_pair_amount'::text) THEN (((value)::numeric >= 0.5) AND ((value)::numeric <= (20)::numeric) AND (mod((value)::numeric, 0.5) = (0)::numeric))
    ELSE true
END),
    CONSTRAINT unilevel_levels_valid CHECK (
CASE
    WHEN (key = 'unilevel_levels'::text) THEN ((value ~ '^[0-9]+$'::text) AND (((value)::numeric >= (1)::numeric) AND ((value)::numeric <= (10)::numeric)))
    ELSE true
END)
);


--
-- Name: unilevel_inventory_earmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_inventory_earmarks (
    source_order_item_id text NOT NULL,
    funded_units integer NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    levels integer DEFAULT 5 NOT NULL,
    amount numeric(12,2) GENERATED ALWAYS AS (((funded_units)::numeric * (levels)::numeric)) STORED,
    CONSTRAINT unilevel_inventory_earmarks_funded_units_check CHECK ((funded_units > 0)),
    CONSTRAINT unilevel_inventory_earmarks_levels_check CHECK (((levels >= 1) AND (levels <= 10)))
);


--
-- Name: unilevel_order_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_order_allocations (
    order_event_id uuid NOT NULL,
    level integer NOT NULL,
    user_id text,
    bottle_count integer NOT NULL,
    disposition text NOT NULL,
    CONSTRAINT unilevel_order_allocations_bottle_count_check CHECK ((bottle_count > 0)),
    CONSTRAINT unilevel_order_allocations_check CHECK (((disposition <> 'qualified'::text) OR (user_id IS NOT NULL))),
    CONSTRAINT unilevel_order_allocations_disposition_check CHECK ((disposition = ANY (ARRAY['qualified'::text, 'no_sponsor'::text, 'inactive_account'::text, 'monthly_purchase_required'::text]))),
    CONSTRAINT unilevel_order_allocations_level_check CHECK (((level >= 1) AND (level <= 10)))
);


--
-- Name: unilevel_order_funding; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.unilevel_order_funding AS
 SELECT movement.order_event_id,
    (sum(movement.units))::integer AS funded_units,
    sum(((movement.units)::numeric * (earmark.levels)::numeric)) AS funded_amount
   FROM (public.product_binary_inventory_reserve_transfers movement
     JOIN public.unilevel_inventory_earmarks earmark USING (source_order_item_id))
  GROUP BY movement.order_event_id;


--
-- Name: unilevel_order_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_order_settlements (
    order_event_id uuid NOT NULL,
    funded_amount numeric(12,2) NOT NULL,
    credited_amount numeric(12,2) NOT NULL,
    retained_amount numeric(12,2) NOT NULL,
    settled_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT unilevel_order_settlements_check CHECK ((funded_amount = (credited_amount + retained_amount))),
    CONSTRAINT unilevel_order_settlements_credited_amount_check CHECK ((credited_amount >= (0)::numeric)),
    CONSTRAINT unilevel_order_settlements_funded_amount_check CHECK ((funded_amount >= (0)::numeric)),
    CONSTRAINT unilevel_order_settlements_retained_amount_check CHECK ((retained_amount >= (0)::numeric))
);


--
-- Name: unilevel_payable_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_payable_lots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_event_id uuid NOT NULL,
    level integer NOT NULL,
    user_id text NOT NULL,
    original_amount numeric(12,2) NOT NULL,
    remaining_amount numeric(12,2) NOT NULL,
    commission_id text NOT NULL,
    allocated_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT unilevel_payable_lots_check CHECK (((remaining_amount >= (0)::numeric) AND (remaining_amount <= original_amount))),
    CONSTRAINT unilevel_payable_lots_original_amount_check CHECK ((original_amount > (0)::numeric))
);


--
-- Name: unilevel_payout_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_payout_consumptions (
    payout_id text NOT NULL,
    lot_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    CONSTRAINT unilevel_payout_consumptions_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: unilevel_qualified_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_qualified_orders (
    settlement_job_id uuid NOT NULL,
    levels integer NOT NULL,
    qualified_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT unilevel_qualified_orders_levels_check CHECK (((levels >= 1) AND (levels <= 10)))
);


--
-- Name: unilevel_qualified_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_qualified_recipients (
    settlement_job_id uuid NOT NULL,
    level integer NOT NULL,
    user_id text,
    disposition text NOT NULL,
    CONSTRAINT unilevel_qualified_recipients_check CHECK (((disposition <> 'qualified'::text) OR (user_id IS NOT NULL))),
    CONSTRAINT unilevel_qualified_recipients_disposition_check CHECK ((disposition = ANY (ARRAY['qualified'::text, 'no_sponsor'::text, 'inactive_account'::text, 'monthly_purchase_required'::text]))),
    CONSTRAINT unilevel_qualified_recipients_level_check CHECK (((level >= 1) AND (level <= 10)))
);


--
-- Name: unilevel_retention_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unilevel_retention_entries (
    order_event_id uuid NOT NULL,
    level integer NOT NULL,
    user_id text,
    reason text NOT NULL,
    amount numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT unilevel_retention_entries_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT unilevel_retention_entries_level_check CHECK (((level >= 0) AND (level <= 10))),
    CONSTRAINT unilevel_retention_entries_reason_check CHECK ((reason = ANY (ARRAY['no_sponsor'::text, 'inactive_account'::text, 'monthly_purchase_required'::text, 'recipient_unavailable_at_credit'::text, 'rounding_or_excess_funding'::text])))
);


--
-- Name: upgrade_financials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upgrade_financials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upgrade_pin_id text NOT NULL,
    city_dist_id text NOT NULL,
    reseller_id text NOT NULL,
    from_package_id text NOT NULL,
    to_package_id text NOT NULL,
    customer_payment numeric(12,2) NOT NULL,
    product_acquisition_cost numeric(12,2) NOT NULL,
    reseller_value numeric(12,2) NOT NULL,
    pin_allocation numeric(12,2) NOT NULL,
    registration_profit numeric(12,2) NOT NULL,
    direct_referral_allocation numeric(12,2) NOT NULL,
    direct_referral_paid numeric(12,2) DEFAULT 0 NOT NULL,
    direct_referral_retained numeric(12,2) NOT NULL,
    binary_commission_allocation numeric(12,2) NOT NULL,
    binary_points_difference integer NOT NULL,
    from_package_name_snapshot text NOT NULL,
    to_package_name_snapshot text NOT NULL,
    allocation_snapshot_source character varying DEFAULT 'upgrade_pin_snapshot'::character varying NOT NULL,
    payment_status character varying DEFAULT 'paid'::character varying NOT NULL,
    paid_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    full_name text NOT NULL,
    email text,
    mobile text NOT NULL,
    password_hash text NOT NULL,
    role public."Role" NOT NULL,
    status public."UserStatus" DEFAULT 'active'::public."UserStatus" NOT NULL,
    address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by text,
    birthday date,
    birthplace text,
    two_factor_enabled boolean DEFAULT false NOT NULL,
    two_factor_pin_hash text,
    two_factor_failed_attempts integer DEFAULT 0 NOT NULL,
    two_factor_locked_until timestamp(3) without time zone,
    profile_photo text,
    zip_code text,
    password_change_required boolean DEFAULT false NOT NULL,
    temporary_password_retained_at timestamp(3) without time zone,
    password_is_temporary boolean DEFAULT false NOT NULL,
    password_retention_stage integer DEFAULT 0 NOT NULL,
    password_prompt_due_at timestamp(3) without time zone,
    password_changed_at timestamp(3) without time zone,
    login_disabled boolean DEFAULT false NOT NULL,
    identity_document_type character varying(40),
    identity_document_hash character varying(64),
    member_id text NOT NULL,
    passkey_test_enabled boolean DEFAULT false NOT NULL,
    street_address text,
    region_code text,
    region_name text,
    province_code text,
    province_name text,
    city_muni_code text,
    city_muni_name text,
    barangay_code text,
    barangay_name text,
    first_name text,
    middle_name text,
    last_name text,
    name_suffix text,
    CONSTRAINT users_zip_code_format_check CHECK (((zip_code IS NULL) OR (zip_code ~ '^[0-9]{4}$'::text)))
);


--
-- Name: walk_in_member_scan_proofs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.walk_in_member_scan_proofs (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    token_hash character varying(64) NOT NULL,
    reseller_id text NOT NULL,
    distributor_id text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    used_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    id text NOT NULL,
    user_id text NOT NULL,
    balance numeric(10,2) DEFAULT 0 NOT NULL,
    total_earned numeric(10,2) DEFAULT 0 NOT NULL,
    total_withdrawn numeric(10,2) DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    reserved_balance numeric(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT wallet_non_negative_reserved_balance_check CHECK (((balance >= (0)::numeric) AND (reserved_balance >= (0)::numeric) AND (reserved_balance <= balance)))
);


--
-- Name: wallet_funding_reconciliation; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.wallet_funding_reconciliation AS
 SELECT w.user_id,
    w.balance,
    w.reserved_balance,
    (((((COALESCE(d.amount, (0)::numeric) + COALESCE(b.amount, (0)::numeric)) + COALESCE(pb.amount, (0)::numeric)) + COALESCE(rb.amount, (0)::numeric)) + COALESCE(ul.amount, (0)::numeric)) + COALESCE(ap.amount, (0)::numeric)) AS source_backed_liability,
    (w.balance - (((((COALESCE(d.amount, (0)::numeric) + COALESCE(b.amount, (0)::numeric)) + COALESCE(pb.amount, (0)::numeric)) + COALESCE(rb.amount, (0)::numeric)) + COALESCE(ul.amount, (0)::numeric)) + COALESCE(ap.amount, (0)::numeric))) AS unreconciled_balance
   FROM ((((((public.wallets w
     LEFT JOIN ( SELECT direct_referral_reserve_lots.user_id,
            sum(direct_referral_reserve_lots.remaining_amount) AS amount
           FROM public.direct_referral_reserve_lots
          GROUP BY direct_referral_reserve_lots.user_id) d ON ((d.user_id = w.user_id)))
     LEFT JOIN ( SELECT binary_payable_lots.user_id,
            sum(binary_payable_lots.remaining_amount) AS amount
           FROM public.binary_payable_lots
          GROUP BY binary_payable_lots.user_id) b ON ((b.user_id = w.user_id)))
     LEFT JOIN ( SELECT product_binary_payable_lots.user_id,
            sum(product_binary_payable_lots.remaining_amount) AS amount
           FROM public.product_binary_payable_lots
          GROUP BY product_binary_payable_lots.user_id) pb ON ((pb.user_id = w.user_id)))
     LEFT JOIN ( SELECT rank_bonus_awards.user_id,
            sum(rank_bonus_awards.remaining_amount) AS amount
           FROM public.rank_bonus_awards
          GROUP BY rank_bonus_awards.user_id) rb ON ((rb.user_id = w.user_id)))
     LEFT JOIN ( SELECT unilevel_payable_lots.user_id,
            sum(unilevel_payable_lots.remaining_amount) AS amount
           FROM public.unilevel_payable_lots
          GROUP BY unilevel_payable_lots.user_id) ul ON ((ul.user_id = w.user_id)))
     LEFT JOIN ( SELECT payouts.user_id,
            sum(payouts.amount) AS amount
           FROM public.payouts
          WHERE (payouts.status = 'approved'::public."PayoutStatus")
          GROUP BY payouts.user_id) ap ON ((ap.user_id = w.user_id)));


--
-- Name: wallet_ledger_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_ledger_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_key character varying(255) NOT NULL,
    user_id text NOT NULL,
    entry_type character varying(40) NOT NULL,
    balance_delta numeric(12,2) DEFAULT 0 NOT NULL,
    reserved_delta numeric(12,2) DEFAULT 0 NOT NULL,
    total_earned_delta numeric(12,2) DEFAULT 0 NOT NULL,
    total_withdrawn_delta numeric(12,2) DEFAULT 0 NOT NULL,
    commission_id text,
    payout_id text,
    source_kind character varying(40) NOT NULL,
    source_event_id character varying(255) NOT NULL,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT wallet_ledger_entries_nonempty_key CHECK ((length(btrim((event_key)::text)) > 0)),
    CONSTRAINT wallet_ledger_entries_nonempty_source CHECK (((length(btrim((source_kind)::text)) > 0) AND (length(btrim((source_event_id)::text)) > 0)))
);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: address_geocode_cache address_geocode_cache_address_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_geocode_cache
    ADD CONSTRAINT address_geocode_cache_address_hash_key UNIQUE (address_hash);


--
-- Name: address_geocode_cache address_geocode_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_geocode_cache
    ADD CONSTRAINT address_geocode_cache_pkey PRIMARY KEY (id);


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipt_items
    ADD CONSTRAINT admin_stock_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_receipt_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipt_items
    ADD CONSTRAINT admin_stock_receipt_items_receipt_id_product_id_key UNIQUE (receipt_id, product_id);


--
-- Name: admin_stock_receipts admin_stock_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipts
    ADD CONSTRAINT admin_stock_receipts_pkey PRIMARY KEY (id);


--
-- Name: admin_stock_receipts admin_stock_receipts_reference_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipts
    ADD CONSTRAINT admin_stock_receipts_reference_number_key UNIQUE (reference_number);


--
-- Name: admin_stock_receipts admin_stock_receipts_source_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipts
    ADD CONSTRAINT admin_stock_receipts_source_reference_key UNIQUE (admin_id, source_type, source_reference_key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: binary_daily_cap_usage binary_daily_cap_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_daily_cap_usage
    ADD CONSTRAINT binary_daily_cap_usage_pkey PRIMARY KEY (user_id, pairing_day);


--
-- Name: binary_pair_events binary_pair_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_pkey PRIMARY KEY (id);


--
-- Name: binary_payable_lots binary_payable_lots_commission_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payable_lots
    ADD CONSTRAINT binary_payable_lots_commission_key UNIQUE (commission_id);


--
-- Name: binary_payable_lots binary_payable_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payable_lots
    ADD CONSTRAINT binary_payable_lots_pkey PRIMARY KEY (id);


--
-- Name: binary_payout_consumptions binary_payout_consumptions_payout_lot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payout_consumptions
    ADD CONSTRAINT binary_payout_consumptions_payout_lot_key UNIQUE (payout_id, payable_lot_id);


--
-- Name: binary_payout_consumptions binary_payout_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payout_consumptions
    ADD CONSTRAINT binary_payout_consumptions_pkey PRIMARY KEY (id);


--
-- Name: binary_point_consumptions binary_point_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_consumptions
    ADD CONSTRAINT binary_point_consumptions_pkey PRIMARY KEY (id);


--
-- Name: binary_point_expirations binary_point_expirations_lot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_expirations
    ADD CONSTRAINT binary_point_expirations_lot_key UNIQUE (point_lot_id);


--
-- Name: binary_point_expirations binary_point_expirations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_expirations
    ADD CONSTRAINT binary_point_expirations_pkey PRIMARY KEY (id);


--
-- Name: binary_point_lots binary_point_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_lots
    ADD CONSTRAINT binary_point_lots_pkey PRIMARY KEY (id);


--
-- Name: binary_reserve_consumptions binary_reserve_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_consumptions
    ADD CONSTRAINT binary_reserve_consumptions_pkey PRIMARY KEY (id);


--
-- Name: binary_reserve_lots binary_reserve_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_lots
    ADD CONSTRAINT binary_reserve_lots_pkey PRIMARY KEY (id);


--
-- Name: binary_reserve_lots binary_reserve_lots_registration_financial_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_lots
    ADD CONSTRAINT binary_reserve_lots_registration_financial_id_key UNIQUE (registration_financial_id);


--
-- Name: binary_settlement_events binary_settlement_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_settlement_events
    ADD CONSTRAINT binary_settlement_events_pkey PRIMARY KEY (id);


--
-- Name: binary_tree_nodes binary_tree_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_tree_nodes
    ADD CONSTRAINT binary_tree_nodes_pkey PRIMARY KEY (id);


--
-- Name: branch_cash_deposits branch_cash_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch_cash_deposits
    ADD CONSTRAINT branch_cash_deposits_pkey PRIMARY KEY (id);


--
-- Name: commissions commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_pkey PRIMARY KEY (id);


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_payout_lot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_payout_consumptions
    ADD CONSTRAINT direct_referral_payout_consumptions_payout_lot_key UNIQUE (payout_id, reserve_lot_id);


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_payout_consumptions
    ADD CONSTRAINT direct_referral_payout_consumptions_pkey PRIMARY KEY (id);


--
-- Name: direct_referral_reserve_lots direct_referral_reserve_lots_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_reserve_lots
    ADD CONSTRAINT direct_referral_reserve_lots_commission_id_key UNIQUE (commission_id);


--
-- Name: direct_referral_reserve_lots direct_referral_reserve_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_reserve_lots
    ADD CONSTRAINT direct_referral_reserve_lots_pkey PRIMARY KEY (id);


--
-- Name: direct_referral_settlement_events direct_referral_settlement_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_settlement_events
    ADD CONSTRAINT direct_referral_settlement_events_pkey PRIMARY KEY (id);


--
-- Name: distributor_profiles distributor_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_profiles
    ADD CONSTRAINT distributor_profiles_pkey PRIMARY KEY (id);


--
-- Name: financial_operation_receipts financial_operation_receipts_kind_source_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_operation_receipts
    ADD CONSTRAINT financial_operation_receipts_kind_source_id_key UNIQUE (kind, source_id);


--
-- Name: financial_operation_receipts financial_operation_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_operation_receipts
    ADD CONSTRAINT financial_operation_receipts_pkey PRIMARY KEY (id);


--
-- Name: hiro_conversations hiro_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hiro_conversations
    ADD CONSTRAINT hiro_conversations_pkey PRIMARY KEY (id);


--
-- Name: hiro_messages hiro_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hiro_messages
    ADD CONSTRAINT hiro_messages_pkey PRIMARY KEY (id);


--
-- Name: identity_account_limits identity_account_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_account_limits
    ADD CONSTRAINT identity_account_limits_pkey PRIMARY KEY (identity_hash);


--
-- Name: inventory_audit_events inventory_audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_audit_events
    ADD CONSTRAINT inventory_audit_events_pkey PRIMARY KEY (id);


--
-- Name: inventory_audit_items inventory_audit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_audit_items
    ADD CONSTRAINT inventory_audit_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_audit_sessions inventory_audit_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_audit_sessions
    ADD CONSTRAINT inventory_audit_sessions_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_transfers inventory_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_pkey PRIMARY KEY (id);


--
-- Name: login_rate_limits login_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_rate_limits
    ADD CONSTRAINT login_rate_limits_pkey PRIMARY KEY (bucket_key, window_start);


--
-- Name: member_id_issuances member_id_issuances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_id_issuances
    ADD CONSTRAINT member_id_issuances_pkey PRIMARY KEY (member_id);


--
-- Name: member_id_issuances member_id_issuances_year_sequence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_id_issuances
    ADD CONSTRAINT member_id_issuances_year_sequence_key UNIQUE (year, sequence);


--
-- Name: member_id_sequences member_id_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_id_sequences
    ADD CONSTRAINT member_id_sequences_pkey PRIMARY KEY (year);


--
-- Name: name_cap_registry name_cap_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.name_cap_registry
    ADD CONSTRAINT name_cap_registry_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_messages order_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_messages
    ADD CONSTRAINT order_messages_pkey PRIMARY KEY (id);


--
-- Name: order_payment_evidence order_payment_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_payment_evidence
    ADD CONSTRAINT order_payment_evidence_pkey PRIMARY KEY (id);


--
-- Name: order_replacement_requests order_replacement_requests_order_id_product_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_requests
    ADD CONSTRAINT order_replacement_requests_order_id_product_id_kind_key UNIQUE (order_id, product_id, kind);


--
-- Name: order_replacement_requests order_replacement_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_requests
    ADD CONSTRAINT order_replacement_requests_pkey PRIMARY KEY (id);


--
-- Name: order_replacement_units order_replacement_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_units
    ADD CONSTRAINT order_replacement_units_pkey PRIMARY KEY (request_id, unit_id);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: package_binary_cap_policies package_binary_cap_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_cap_policies
    ADD CONSTRAINT package_binary_cap_policies_pkey PRIMARY KEY (id);


--
-- Name: package_binary_cap_policies package_binary_cap_policies_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_cap_policies
    ADD CONSTRAINT package_binary_cap_policies_revision_key UNIQUE (revision);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_cap_policy_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_cap_policy_id_key UNIQUE (cap_policy_id);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_pkey PRIMARY KEY (id);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_revision_key UNIQUE (revision);


--
-- Name: package_binary_product_rewards package_binary_product_rewards_pair_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_product_rewards
    ADD CONSTRAINT package_binary_product_rewards_pair_event_id_key UNIQUE (pair_event_id);


--
-- Name: package_binary_product_rewards package_binary_product_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_product_rewards
    ADD CONSTRAINT package_binary_product_rewards_pkey PRIMARY KEY (id);


--
-- Name: package_products package_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_products
    ADD CONSTRAINT package_products_pkey PRIMARY KEY (id);


--
-- Name: package_upgrade_paths package_upgrade_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_paths
    ADD CONSTRAINT package_upgrade_paths_pkey PRIMARY KEY (id);


--
-- Name: package_upgrade_products package_upgrade_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_products
    ADD CONSTRAINT package_upgrade_products_pkey PRIMARY KEY (id);


--
-- Name: packages packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_pkey PRIMARY KEY (id);


--
-- Name: pairing_logs pairing_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pairing_logs
    ADD CONSTRAINT pairing_logs_pkey PRIMARY KEY (id);


--
-- Name: passkey_challenges passkey_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_challenges
    ADD CONSTRAINT passkey_challenges_pkey PRIMARY KEY (id);


--
-- Name: passkey_credentials passkey_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_credentials
    ADD CONSTRAINT passkey_credentials_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_pkey PRIMARY KEY (id);


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_rank_bonus_lot_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_rank_bonus_lot_id_key UNIQUE (rank_bonus_lot_id);


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_unilevel_lot_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_unilevel_lot_id_key UNIQUE (unilevel_lot_id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payout_destination_owners payout_destination_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payout_destination_owners
    ADD CONSTRAINT payout_destination_owners_pkey PRIMARY KEY (destination_hash);


--
-- Name: payouts payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT payouts_pkey PRIMARY KEY (id);


--
-- Name: person_account_documents person_account_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_documents
    ADD CONSTRAINT person_account_documents_pkey PRIMARY KEY (document_hash);


--
-- Name: person_account_memberships person_account_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_memberships
    ADD CONSTRAINT person_account_memberships_pkey PRIMARY KEY (user_id);


--
-- Name: person_account_totals person_account_totals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_totals
    ADD CONSTRAINT person_account_totals_pkey PRIMARY KEY (person_key);


--
-- Name: pin_registration_product_snapshots pin_registration_product_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_registration_product_snapshots
    ADD CONSTRAINT pin_registration_product_snapshots_pkey PRIMARY KEY (id);


--
-- Name: pin_request_payment_evidence pin_request_payment_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_request_payment_evidence
    ADD CONSTRAINT pin_request_payment_evidence_pkey PRIMARY KEY (id);


--
-- Name: pin_requests pin_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_requests
    ADD CONSTRAINT pin_requests_pkey PRIMARY KEY (id);


--
-- Name: pin_transfers pin_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_pkey PRIMARY KEY (id);


--
-- Name: pin_transfers pin_transfers_reference_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_reference_number_key UNIQUE (reference_number);


--
-- Name: pin_upgrade_product_snapshots pin_upgrade_product_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_upgrade_product_snapshots
    ADD CONSTRAINT pin_upgrade_product_snapshots_pkey PRIMARY KEY (id);


--
-- Name: pins pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_pkey PRIMARY KEY (id);


--
-- Name: pos_adjustment_items pos_adjustment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_items
    ADD CONSTRAINT pos_adjustment_items_pkey PRIMARY KEY (id);


--
-- Name: pos_adjustment_requests pos_adjustment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_requests
    ADD CONSTRAINT pos_adjustment_requests_pkey PRIMARY KEY (id);


--
-- Name: pos_cash_movements pos_cash_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_pkey PRIMARY KEY (id);


--
-- Name: pos_enrollment_rate_limits pos_enrollment_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_enrollment_rate_limits
    ADD CONSTRAINT pos_enrollment_rate_limits_pkey PRIMARY KEY (bucket_key);


--
-- Name: pos_inventory_allowances pos_inventory_allowances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_inventory_allowances
    ADD CONSTRAINT pos_inventory_allowances_pkey PRIMARY KEY (id);


--
-- Name: pos_registration_events pos_registration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_events
    ADD CONSTRAINT pos_registration_events_pkey PRIMARY KEY (id);


--
-- Name: pos_registration_intakes pos_registration_intakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_pkey PRIMARY KEY (id);


--
-- Name: pos_shifts pos_shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_shifts
    ADD CONSTRAINT pos_shifts_pkey PRIMARY KEY (id);


--
-- Name: pos_sync_events pos_sync_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_sync_events
    ADD CONSTRAINT pos_sync_events_pkey PRIMARY KEY (id);


--
-- Name: pos_terminal_enrollments pos_terminal_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminal_enrollments
    ADD CONSTRAINT pos_terminal_enrollments_pkey PRIMARY KEY (id);


--
-- Name: pos_terminals pos_terminals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminals
    ADD CONSTRAINT pos_terminals_pkey PRIMARY KEY (id);


--
-- Name: pos_transaction_items pos_transaction_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: pos_transactions pos_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_pkey PRIMARY KEY (id);


--
-- Name: product_area_visibility product_area_visibility_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_area_visibility
    ADD CONSTRAINT product_area_visibility_pkey PRIMARY KEY (id);


--
-- Name: product_binary_account_holds product_binary_account_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_account_holds
    ADD CONSTRAINT product_binary_account_holds_pkey PRIMARY KEY (user_id);


--
-- Name: product_binary_funding_consumptions product_binary_funding_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_consumptions
    ADD CONSTRAINT product_binary_funding_consumptions_pkey PRIMARY KEY (id);


--
-- Name: product_binary_funding_lots product_binary_funding_lots_inventory_movement_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_lots
    ADD CONSTRAINT product_binary_funding_lots_inventory_movement_id_key UNIQUE (inventory_movement_id);


--
-- Name: product_binary_funding_lots product_binary_funding_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_lots
    ADD CONSTRAINT product_binary_funding_lots_pkey PRIMARY KEY (id);


--
-- Name: product_binary_inventory_reserve_transfers product_binary_inventory_reserve_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserve_transfers
    ADD CONSTRAINT product_binary_inventory_reserve_transfers_pkey PRIMARY KEY (order_event_id, source_order_item_id);


--
-- Name: product_binary_inventory_reserves product_binary_inventory_reserves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserves
    ADD CONSTRAINT product_binary_inventory_reserves_pkey PRIMARY KEY (source_order_item_id);


--
-- Name: product_binary_non_member_reserve_processed product_binary_non_member_reserve_processed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_processed
    ADD CONSTRAINT product_binary_non_member_reserve_processed_pkey PRIMARY KEY (order_id);


--
-- Name: product_binary_non_member_reserve_releases product_binary_non_member_reserve_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_releases
    ADD CONSTRAINT product_binary_non_member_reserve_releases_pkey PRIMARY KEY (order_id, source_order_item_id);


--
-- Name: product_binary_non_member_reserve_restorations product_binary_non_member_reserve_restorations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_restorations
    ADD CONSTRAINT product_binary_non_member_reserve_restorations_pkey PRIMARY KEY (adjustment_id, source_order_item_id);


--
-- Name: product_binary_order_events product_binary_order_events_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_order_events
    ADD CONSTRAINT product_binary_order_events_order_id_key UNIQUE (order_id);


--
-- Name: product_binary_order_events product_binary_order_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_order_events
    ADD CONSTRAINT product_binary_order_events_pkey PRIMARY KEY (id);


--
-- Name: product_binary_package_reserve_releases product_binary_package_reserve_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_package_reserve_releases
    ADD CONSTRAINT product_binary_package_reserve_releases_pkey PRIMARY KEY (reference_type, reference_id, product_id);


--
-- Name: product_binary_pair_events product_binary_pair_events_id_order_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_events_id_order_unique UNIQUE (id, order_event_id);


--
-- Name: product_binary_pair_events product_binary_pair_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_events_pkey PRIMARY KEY (id);


--
-- Name: product_binary_pair_events product_binary_pair_order_recipient_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_order_recipient_key UNIQUE (order_event_id, recipient_user_id);


--
-- Name: product_binary_payable_lots product_binary_payable_lots_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payable_lots
    ADD CONSTRAINT product_binary_payable_lots_commission_id_key UNIQUE (commission_id);


--
-- Name: product_binary_payable_lots product_binary_payable_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payable_lots
    ADD CONSTRAINT product_binary_payable_lots_pkey PRIMARY KEY (id);


--
-- Name: product_binary_payout_consumptions product_binary_payout_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payout_consumptions
    ADD CONSTRAINT product_binary_payout_consumptions_pkey PRIMARY KEY (id);


--
-- Name: product_binary_payout_consumptions product_binary_payout_lot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payout_consumptions
    ADD CONSTRAINT product_binary_payout_lot_key UNIQUE (payout_id, payable_lot_id);


--
-- Name: product_binary_pool_allocations product_binary_pool_allocations_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_allocations
    ADD CONSTRAINT product_binary_pool_allocations_commission_id_key UNIQUE (commission_id);


--
-- Name: product_binary_pool_allocations product_binary_pool_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_allocations
    ADD CONSTRAINT product_binary_pool_allocations_pkey PRIMARY KEY (week_start, recipient_user_id);


--
-- Name: product_binary_pool_orders product_binary_pool_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_orders
    ADD CONSTRAINT product_binary_pool_orders_pkey PRIMARY KEY (order_event_id);


--
-- Name: product_binary_pool_orders product_binary_pool_orders_week_start_order_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_orders
    ADD CONSTRAINT product_binary_pool_orders_week_start_order_event_id_key UNIQUE (week_start, order_event_id);


--
-- Name: product_binary_pool_pairs product_binary_pool_pairs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_pairs
    ADD CONSTRAINT product_binary_pool_pairs_pkey PRIMARY KEY (pair_event_id);


--
-- Name: product_binary_pool_weeks product_binary_pool_weeks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_weeks
    ADD CONSTRAINT product_binary_pool_weeks_pkey PRIMARY KEY (week_start);


--
-- Name: product_binary_positions product_binary_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_positions
    ADD CONSTRAINT product_binary_positions_pkey PRIMARY KEY (id);


--
-- Name: product_binary_positions product_binary_positions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_positions
    ADD CONSTRAINT product_binary_positions_user_id_key UNIQUE (user_id);


--
-- Name: product_binary_prepared_recipients product_binary_prepared_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_prepared_recipients
    ADD CONSTRAINT product_binary_prepared_recipients_pkey PRIMARY KEY (week_start, recipient_user_id);


--
-- Name: product_binary_pu_lots product_binary_pu_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pu_lots
    ADD CONSTRAINT product_binary_pu_lots_pkey PRIMARY KEY (id);


--
-- Name: product_binary_pu_lots product_binary_pu_lots_recipient_user_id_order_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pu_lots
    ADD CONSTRAINT product_binary_pu_lots_recipient_user_id_order_event_id_key UNIQUE (recipient_user_id, order_event_id);


--
-- Name: product_binary_replacement_reserve_processed product_binary_replacement_reserve_processed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_replacement_reserve_processed
    ADD CONSTRAINT product_binary_replacement_reserve_processed_pkey PRIMARY KEY (dispatch_id);


--
-- Name: product_binary_replacement_reserve_releases product_binary_replacement_reserve_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_replacement_reserve_releases
    ADD CONSTRAINT product_binary_replacement_reserve_releases_pkey PRIMARY KEY (dispatch_id, source_order_item_id);


--
-- Name: product_binary_settlement_jobs product_binary_settlement_jobs_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_settlement_jobs
    ADD CONSTRAINT product_binary_settlement_jobs_order_id_key UNIQUE (order_id);


--
-- Name: product_binary_settlement_jobs product_binary_settlement_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_settlement_jobs
    ADD CONSTRAINT product_binary_settlement_jobs_pkey PRIMARY KEY (id);


--
-- Name: product_binary_week_funding product_binary_week_funding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_week_funding
    ADD CONSTRAINT product_binary_week_funding_pkey PRIMARY KEY (week_start);


--
-- Name: product_binary_week_preparation product_binary_week_preparation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_week_preparation
    ADD CONSTRAINT product_binary_week_preparation_pkey PRIMARY KEY (week_start);


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_allocations
    ADD CONSTRAINT product_reward_claim_allocations_pkey PRIMARY KEY (id);


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_reward_id_unit_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_allocations
    ADD CONSTRAINT product_reward_claim_allocations_reward_id_unit_number_key UNIQUE (reward_id, unit_number);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_pkey PRIMARY KEY (id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_token_hash_key UNIQUE (token_hash);


--
-- Name: product_reward_claims product_reward_claims_client_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_client_request_id_key UNIQUE (client_request_id);


--
-- Name: product_reward_claims product_reward_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_pkey PRIMARY KEY (id);


--
-- Name: product_reward_claims product_reward_claims_proof_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_proof_id_key UNIQUE (proof_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: public_verification_rate_limits public_verification_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_verification_rate_limits
    ADD CONSTRAINT public_verification_rate_limits_pkey PRIMARY KEY (bucket_key, window_start);


--
-- Name: rank_bonus_awards rank_bonus_awards_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_commission_id_key UNIQUE (commission_id);


--
-- Name: rank_bonus_awards rank_bonus_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_pkey PRIMARY KEY (id);


--
-- Name: rank_bonus_awards rank_bonus_awards_quarter_start_user_id_milestone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_quarter_start_user_id_milestone_key UNIQUE (quarter_start, user_id, milestone);


--
-- Name: rank_bonus_funding rank_bonus_funding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_funding
    ADD CONSTRAINT rank_bonus_funding_pkey PRIMARY KEY (reference);


--
-- Name: rank_bonus_payout_consumptions rank_bonus_payout_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_payout_consumptions
    ADD CONSTRAINT rank_bonus_payout_consumptions_pkey PRIMARY KEY (payout_id, award_id);


--
-- Name: rank_bonus_programs rank_bonus_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_programs
    ADD CONSTRAINT rank_bonus_programs_pkey PRIMARY KEY (quarter_start);


--
-- Name: rank_periods rank_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_periods
    ADD CONSTRAINT rank_periods_pkey PRIMARY KEY (id);


--
-- Name: ranks ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranks
    ADD CONSTRAINT ranks_pkey PRIMARY KEY (id);


--
-- Name: registration_financials registration_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_financials
    ADD CONSTRAINT registration_financials_pkey PRIMARY KEY (id);


--
-- Name: request_receipts request_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_receipts
    ADD CONSTRAINT request_receipts_pkey PRIMARY KEY (request_key);


--
-- Name: reseller_deactivation_events reseller_deactivation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_deactivation_events
    ADD CONSTRAINT reseller_deactivation_events_pkey PRIMARY KEY (id);


--
-- Name: reseller_profiles reseller_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_pkey PRIMARY KEY (id);


--
-- Name: reward_stock_dispatch_items reward_stock_dispatch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatch_items
    ADD CONSTRAINT reward_stock_dispatch_items_pkey PRIMARY KEY (id);


--
-- Name: reward_stock_dispatch_items reward_stock_dispatch_items_unit_id_cycle_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatch_items
    ADD CONSTRAINT reward_stock_dispatch_items_unit_id_cycle_key UNIQUE (unit_id, cycle);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_client_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_client_request_id_key UNIQUE (client_request_id);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_pkey PRIMARY KEY (id);


--
-- Name: reward_stock_receipts reward_stock_receipts_dispatch_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_receipts
    ADD CONSTRAINT reward_stock_receipts_dispatch_id_key UNIQUE (dispatch_id);


--
-- Name: reward_stock_receipts reward_stock_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_receipts
    ADD CONSTRAINT reward_stock_receipts_pkey PRIMARY KEY (id);


--
-- Name: reward_stock_units reward_stock_units_claim_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_claim_allocation_id_key UNIQUE (claim_allocation_id);


--
-- Name: reward_stock_units reward_stock_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_pkey PRIMARY KEY (id);


--
-- Name: staff_profiles staff_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_pkey PRIMARY KEY (id);


--
-- Name: support_attachments support_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_attachments
    ADD CONSTRAINT support_attachments_pkey PRIMARY KEY (id);


--
-- Name: support_captcha_challenges support_captcha_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_captcha_challenges
    ADD CONSTRAINT support_captcha_challenges_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_requests support_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_requests
    ADD CONSTRAINT support_requests_pkey PRIMARY KEY (id);


--
-- Name: support_typing support_typing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_typing
    ADD CONSTRAINT support_typing_pkey PRIMARY KEY (request_id, actor_id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: unilevel_inventory_earmarks unilevel_inventory_earmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_inventory_earmarks
    ADD CONSTRAINT unilevel_inventory_earmarks_pkey PRIMARY KEY (source_order_item_id);


--
-- Name: unilevel_order_allocations unilevel_order_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_order_allocations
    ADD CONSTRAINT unilevel_order_allocations_pkey PRIMARY KEY (order_event_id, level);


--
-- Name: unilevel_order_settlements unilevel_order_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_order_settlements
    ADD CONSTRAINT unilevel_order_settlements_pkey PRIMARY KEY (order_event_id);


--
-- Name: unilevel_payable_lots unilevel_payable_lots_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_commission_id_key UNIQUE (commission_id);


--
-- Name: unilevel_payable_lots unilevel_payable_lots_order_event_id_level_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_order_event_id_level_key UNIQUE (order_event_id, level);


--
-- Name: unilevel_payable_lots unilevel_payable_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_pkey PRIMARY KEY (id);


--
-- Name: unilevel_payout_consumptions unilevel_payout_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payout_consumptions
    ADD CONSTRAINT unilevel_payout_consumptions_pkey PRIMARY KEY (payout_id, lot_id);


--
-- Name: unilevel_qualified_orders unilevel_qualified_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_qualified_orders
    ADD CONSTRAINT unilevel_qualified_orders_pkey PRIMARY KEY (settlement_job_id);


--
-- Name: unilevel_qualified_recipients unilevel_qualified_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_qualified_recipients
    ADD CONSTRAINT unilevel_qualified_recipients_pkey PRIMARY KEY (settlement_job_id, level);


--
-- Name: unilevel_retention_entries unilevel_retention_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_retention_entries
    ADD CONSTRAINT unilevel_retention_entries_pkey PRIMARY KEY (order_event_id, level);


--
-- Name: upgrade_financials upgrade_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upgrade_financials
    ADD CONSTRAINT upgrade_financials_pkey PRIMARY KEY (id);


--
-- Name: upgrade_financials upgrade_financials_upgrade_pin_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upgrade_financials
    ADD CONSTRAINT upgrade_financials_upgrade_pin_id_key UNIQUE (upgrade_pin_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: walk_in_member_scan_proofs walk_in_member_scan_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walk_in_member_scan_proofs
    ADD CONSTRAINT walk_in_member_scan_proofs_pkey PRIMARY KEY (id);


--
-- Name: wallet_ledger_entries wallet_ledger_entries_commission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_commission_id_key UNIQUE (commission_id);


--
-- Name: wallet_ledger_entries wallet_ledger_entries_event_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_event_key_key UNIQUE (event_key);


--
-- Name: wallet_ledger_entries wallet_ledger_entries_payout_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_payout_type_key UNIQUE (payout_id, entry_type);


--
-- Name: wallet_ledger_entries wallet_ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: address_geocode_cache_lookup_status_last_lookup_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX address_geocode_cache_lookup_status_last_lookup_at_idx ON public.address_geocode_cache USING btree (lookup_status, last_lookup_at);


--
-- Name: admin_stock_receipt_items_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_stock_receipt_items_product_id_created_at_idx ON public.admin_stock_receipt_items USING btree (product_id, created_at);


--
-- Name: admin_stock_receipts_admin_id_received_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_stock_receipts_admin_id_received_at_idx ON public.admin_stock_receipts USING btree (admin_id, received_at);


--
-- Name: admin_stock_receipts_source_type_source_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_stock_receipts_source_type_source_reference_idx ON public.admin_stock_receipts USING btree (source_type, source_reference);


--
-- Name: audit_logs_activity_type_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_activity_type_created_at_idx ON public.audit_logs USING btree (activity_type, created_at);


--
-- Name: audit_logs_category_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_category_created_at_idx ON public.audit_logs USING btree (category, created_at);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_one_payout_lifecycle_action; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX audit_logs_one_payout_lifecycle_action ON public.audit_logs USING btree (((metadata ->> 'payout_id'::text)), activity_type) WHERE (activity_type = ANY (ARRAY['payout_requested'::text, 'payout_approved'::text, 'payout_rejected'::text, 'payout_released'::text]));


--
-- Name: audit_logs_risk_level_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_risk_level_created_at_idx ON public.audit_logs USING btree (risk_level, created_at);


--
-- Name: audit_logs_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_status_created_at_idx ON public.audit_logs USING btree (status, created_at);


--
-- Name: audit_logs_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_created_at_idx ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: audit_logs_user_role_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_role_created_at_idx ON public.audit_logs USING btree (user_role, created_at);


--
-- Name: binary_pair_events_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_created_at_idx ON public.binary_pair_events USING btree (created_at);


--
-- Name: binary_pair_events_flashout_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_pair_events_flashout_commission_id_key ON public.binary_pair_events USING btree (flashout_commission_id) WHERE (flashout_commission_id IS NOT NULL);


--
-- Name: binary_pair_events_normal_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_pair_events_normal_commission_id_key ON public.binary_pair_events USING btree (normal_commission_id) WHERE (normal_commission_id IS NOT NULL);


--
-- Name: binary_pair_events_package_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_package_created_idx ON public.binary_pair_events USING btree (recipient_package_id, created_at);


--
-- Name: binary_pair_events_recipient_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_recipient_created_idx ON public.binary_pair_events USING btree (recipient_user_id, created_at);


--
-- Name: binary_pair_events_reward_progress_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_reward_progress_idx ON public.binary_pair_events USING btree (recipient_user_id) WHERE (reward_interval IS NOT NULL);


--
-- Name: binary_pair_events_session_usage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_session_usage_idx ON public.binary_pair_events USING btree (recipient_user_id, pairing_day, cap_session);


--
-- Name: binary_pair_events_source_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_pair_events_source_created_idx ON public.binary_pair_events USING btree (source_user_id, created_at);


--
-- Name: binary_pair_events_source_kind_source_event_id_recipient_user_i; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_pair_events_source_kind_source_event_id_recipient_user_i ON public.binary_pair_events USING btree (source_kind, source_event_id, recipient_user_id);


--
-- Name: binary_payable_lots_user_remaining_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_payable_lots_user_remaining_idx ON public.binary_payable_lots USING btree (user_id, remaining_amount, allocated_at);


--
-- Name: binary_payout_consumptions_lot_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_payout_consumptions_lot_idx ON public.binary_payout_consumptions USING btree (payable_lot_id);


--
-- Name: binary_payout_consumptions_payout_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_payout_consumptions_payout_idx ON public.binary_payout_consumptions USING btree (payout_id);


--
-- Name: binary_point_consumptions_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_point_consumptions_event_idx ON public.binary_point_consumptions USING btree (binary_pair_event_id);


--
-- Name: binary_point_consumptions_lot_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_point_consumptions_lot_event_key ON public.binary_point_consumptions USING btree (point_lot_id, binary_pair_event_id);


--
-- Name: binary_point_expirations_expired_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_point_expirations_expired_idx ON public.binary_point_expirations USING btree (expired_at);


--
-- Name: binary_point_expirations_recipient_expired_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_point_expirations_recipient_expired_idx ON public.binary_point_expirations USING btree (recipient_user_id, expired_at);


--
-- Name: binary_point_lots_expiry_remaining_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_point_lots_expiry_remaining_idx ON public.binary_point_lots USING btree (expires_at, remaining_points);


--
-- Name: binary_point_lots_recipient_leg_generated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_point_lots_recipient_leg_generated_idx ON public.binary_point_lots USING btree (recipient_user_id, leg, generated_at);


--
-- Name: binary_point_lots_source_recipient_leg_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_point_lots_source_recipient_leg_key ON public.binary_point_lots USING btree (source_kind, source_event_id, recipient_user_id, leg);


--
-- Name: binary_reserve_consumptions_commission_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_reserve_consumptions_commission_idx ON public.binary_reserve_consumptions USING btree (commission_id);


--
-- Name: binary_reserve_consumptions_lot_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_reserve_consumptions_lot_idx ON public.binary_reserve_consumptions USING btree (reserve_lot_id);


--
-- Name: binary_reserve_lots_remaining_allocated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_reserve_lots_remaining_allocated_idx ON public.binary_reserve_lots USING btree (remaining_amount, allocated_at);


--
-- Name: binary_reserve_lots_upgrade_financial_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_reserve_lots_upgrade_financial_id_key ON public.binary_reserve_lots USING btree (upgrade_financial_id);


--
-- Name: binary_settlement_events_source_kind_source_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_settlement_events_source_kind_source_event_id_key ON public.binary_settlement_events USING btree (source_kind, source_event_id);


--
-- Name: binary_settlement_events_source_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binary_settlement_events_source_user_id_created_at_idx ON public.binary_settlement_events USING btree (source_user_id, created_at);


--
-- Name: binary_tree_nodes_parent_id_position_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_tree_nodes_parent_id_position_key ON public.binary_tree_nodes USING btree (parent_id, "position");


--
-- Name: binary_tree_nodes_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binary_tree_nodes_user_id_key ON public.binary_tree_nodes USING btree (user_id);


--
-- Name: branch_cash_deposits_bank_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX branch_cash_deposits_bank_reference_key ON public.branch_cash_deposits USING btree (bank_reference);


--
-- Name: branch_cash_deposits_branch_id_period_start_period_end_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX branch_cash_deposits_branch_id_period_start_period_end_idx ON public.branch_cash_deposits USING btree (branch_id, period_start, period_end);


--
-- Name: branch_cash_deposits_branch_id_status_deposited_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX branch_cash_deposits_branch_id_status_deposited_at_idx ON public.branch_cash_deposits USING btree (branch_id, status, deposited_at);


--
-- Name: branch_cash_deposits_reference_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX branch_cash_deposits_reference_number_key ON public.branch_cash_deposits USING btree (reference_number);


--
-- Name: commissions_event_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commissions_event_key_key ON public.commissions USING btree (event_key);


--
-- Name: commissions_one_paid_direct_per_registration; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commissions_one_paid_direct_per_registration ON public.commissions USING btree (source_event_id) WHERE ((type = 'direct_referral'::public."CommissionType") AND (is_pair_overflow = false) AND ((source_event_kind)::text = 'registration'::text));


--
-- Name: commissions_one_retained_direct_per_registration; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commissions_one_retained_direct_per_registration ON public.commissions USING btree (source_event_id) WHERE ((type = 'direct_referral'::public."CommissionType") AND (is_pair_overflow = true) AND ((source_event_kind)::text = 'registration'::text));


--
-- Name: commissions_source_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commissions_source_event_idx ON public.commissions USING btree (source_event_kind, source_event_id);


--
-- Name: direct_referral_payout_consumptions_lot_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX direct_referral_payout_consumptions_lot_idx ON public.direct_referral_payout_consumptions USING btree (reserve_lot_id);


--
-- Name: direct_referral_payout_consumptions_payout_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX direct_referral_payout_consumptions_payout_idx ON public.direct_referral_payout_consumptions USING btree (payout_id);


--
-- Name: direct_referral_reserve_lots_member_remaining_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX direct_referral_reserve_lots_member_remaining_idx ON public.direct_referral_reserve_lots USING btree (user_id, remaining_amount, allocated_at);


--
-- Name: direct_referral_settlement_events_normal_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX direct_referral_settlement_events_normal_commission_id_key ON public.direct_referral_settlement_events USING btree (normal_commission_id) WHERE (normal_commission_id IS NOT NULL);


--
-- Name: direct_referral_settlement_events_referred_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX direct_referral_settlement_events_referred_created_idx ON public.direct_referral_settlement_events USING btree (referred_user_id, created_at);


--
-- Name: direct_referral_settlement_events_registration_financial_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX direct_referral_settlement_events_registration_financial_id_key ON public.direct_referral_settlement_events USING btree (registration_financial_id);


--
-- Name: direct_referral_settlement_events_retained_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX direct_referral_settlement_events_retained_commission_id_key ON public.direct_referral_settlement_events USING btree (retained_commission_id) WHERE (retained_commission_id IS NOT NULL);


--
-- Name: direct_referral_settlement_events_source_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX direct_referral_settlement_events_source_event_id_key ON public.direct_referral_settlement_events USING btree (source_event_id);


--
-- Name: direct_referral_settlement_events_sponsor_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX direct_referral_settlement_events_sponsor_day_idx ON public.direct_referral_settlement_events USING btree (sponsor_user_id, settlement_day);


--
-- Name: distributor_active_city_branch_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_active_city_branch_unique ON public.distributor_profiles USING btree (btrim(city_muni_code)) WHERE (is_active AND (dist_level = ANY (ARRAY['city'::public."DistributorLevel", 'branch'::public."DistributorLevel"])) AND (NULLIF(btrim(city_muni_code), ''::text) IS NOT NULL));


--
-- Name: distributor_active_province_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_active_province_unique ON public.distributor_profiles USING btree (btrim(province_code)) WHERE (is_active AND (dist_level = 'provincial'::public."DistributorLevel") AND (NULLIF(btrim(province_code), ''::text) IS NOT NULL));


--
-- Name: distributor_active_region_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_active_region_unique ON public.distributor_profiles USING btree (btrim(region_code)) WHERE (is_active AND (dist_level = 'regional'::public."DistributorLevel") AND (NULLIF(btrim(region_code), ''::text) IS NOT NULL));


--
-- Name: distributor_profiles_level_active_city_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distributor_profiles_level_active_city_idx ON public.distributor_profiles USING btree (dist_level, is_active, city_muni_code);


--
-- Name: distributor_profiles_level_active_province_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distributor_profiles_level_active_province_idx ON public.distributor_profiles USING btree (dist_level, is_active, province_code);


--
-- Name: distributor_profiles_level_active_region_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distributor_profiles_level_active_region_idx ON public.distributor_profiles USING btree (dist_level, is_active, region_code);


--
-- Name: distributor_profiles_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_profiles_user_id_key ON public.distributor_profiles USING btree (user_id);


--
-- Name: financial_operation_receipts_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_operation_receipts_owner_idx ON public.financial_operation_receipts USING btree (owner_id, created_at);


--
-- Name: hiro_conversations_user_id_status_last_activity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hiro_conversations_user_id_status_last_activity_idx ON public.hiro_conversations USING btree (user_id, status, last_activity);


--
-- Name: hiro_messages_conversation_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hiro_messages_conversation_id_created_at_idx ON public.hiro_messages USING btree (conversation_id, created_at);


--
-- Name: idx_audit_logs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_category ON public.audit_logs USING btree (category);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_risk_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_risk_level ON public.audit_logs USING btree (risk_level);


--
-- Name: idx_audit_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_status ON public.audit_logs USING btree (status);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_users_birthday_birthplace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_birthday_birthplace ON public.users USING btree (birthday, birthplace) WHERE ((birthday IS NOT NULL) AND (birthplace IS NOT NULL));


--
-- Name: inventory_audit_events_owner_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_events_owner_id_created_at_idx ON public.inventory_audit_events USING btree (owner_id, created_at DESC);


--
-- Name: inventory_audit_events_owner_id_event_type_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_events_owner_id_event_type_created_at_idx ON public.inventory_audit_events USING btree (owner_id, event_type, created_at DESC);


--
-- Name: inventory_audit_events_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_events_product_id_created_at_idx ON public.inventory_audit_events USING btree (product_id, created_at DESC);


--
-- Name: inventory_audit_items_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_items_product_id_created_at_idx ON public.inventory_audit_items USING btree (product_id, created_at DESC);


--
-- Name: inventory_audit_items_session_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_audit_items_session_id_product_id_key ON public.inventory_audit_items USING btree (session_id, product_id);


--
-- Name: inventory_audit_items_session_id_variance_quantity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_items_session_id_variance_quantity_idx ON public.inventory_audit_items USING btree (session_id, variance_quantity);


--
-- Name: inventory_audit_sessions_owner_id_status_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_audit_sessions_owner_id_status_started_at_idx ON public.inventory_audit_sessions USING btree (owner_id, status, started_at DESC);


--
-- Name: inventory_audit_sessions_pos_shift_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_audit_sessions_pos_shift_id_key ON public.inventory_audit_sessions USING btree (pos_shift_id);


--
-- Name: inventory_audit_sessions_reference_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_audit_sessions_reference_number_key ON public.inventory_audit_sessions USING btree (reference_number);


--
-- Name: inventory_movements_admin_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_admin_id_created_at_idx ON public.inventory_movements USING btree (admin_id, created_at);


--
-- Name: inventory_movements_recipient_id_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_recipient_id_product_id_created_at_idx ON public.inventory_movements USING btree (recipient_id, product_id, created_at);


--
-- Name: inventory_movements_transfer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_transfer_id_idx ON public.inventory_movements USING btree (transfer_id);


--
-- Name: inventory_owner_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_owner_id_product_id_key ON public.inventory USING btree (owner_id, product_id);


--
-- Name: inventory_transfers_admin_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_transfers_admin_id_created_at_idx ON public.inventory_transfers USING btree (admin_id, created_at DESC);


--
-- Name: inventory_transfers_recipient_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_transfers_recipient_id_status_created_at_idx ON public.inventory_transfers USING btree (recipient_id, status, created_at DESC);


--
-- Name: inventory_transfers_reference_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_transfers_reference_number_key ON public.inventory_transfers USING btree (reference_number);


--
-- Name: login_rate_limits_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX login_rate_limits_expires_at_idx ON public.login_rate_limits USING btree (expires_at);


--
-- Name: member_id_issuances_allocated_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_id_issuances_allocated_at_idx ON public.member_id_issuances USING btree (allocated_at);


--
-- Name: name_cap_registry_normalized_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX name_cap_registry_normalized_name_key ON public.name_cap_registry USING btree (normalized_name);


--
-- Name: notifications_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_id_created_at_idx ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: notifications_user_id_read_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_id_read_at_idx ON public.notifications USING btree (user_id, read_at);


--
-- Name: order_messages_order_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_messages_order_id_created_at_idx ON public.order_messages USING btree (order_id, created_at);


--
-- Name: order_payment_evidence_order_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_payment_evidence_order_id_created_at_idx ON public.order_payment_evidence USING btree (order_id, created_at);


--
-- Name: order_payment_evidence_order_id_reference_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX order_payment_evidence_order_id_reference_number_key ON public.order_payment_evidence USING btree (order_id, reference_number);


--
-- Name: order_replacement_units_unit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_replacement_units_unit_idx ON public.order_replacement_units USING btree (unit_id);


--
-- Name: orders_cancelled_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_cancelled_at_idx ON public.orders USING btree (cancelled_at DESC) WHERE (status = 'cancelled'::public."OrderStatus");


--
-- Name: orders_fulfillment_method_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_fulfillment_method_status_idx ON public.orders USING btree (fulfillment_method, status);


--
-- Name: orders_market_location_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_market_location_idx ON public.orders USING btree (market_region_code, market_province_code, market_city_muni_code);


--
-- Name: orders_payment_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_payment_expiry_idx ON public.orders USING btree (payment_due_at, payment_status, status);


--
-- Name: orders_seller_id_delivered_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_seller_id_delivered_at_idx ON public.orders USING btree (seller_id, delivered_at);


--
-- Name: orders_seller_id_paid_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_seller_id_paid_at_idx ON public.orders USING btree (seller_id, paid_at);


--
-- Name: orders_seller_pickup_schedule_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_seller_pickup_schedule_idx ON public.orders USING btree (seller_id, pickup_scheduled_at) WHERE (((fulfillment_method)::text = 'partner_pickup'::text) AND (status <> ALL (ARRAY['delivered'::public."OrderStatus", 'cancelled'::public."OrderStatus"])));


--
-- Name: package_binary_cap_policies_effective_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX package_binary_cap_policies_effective_idx ON public.package_binary_cap_policies USING btree (package_id, effective_day DESC, revision DESC);


--
-- Name: package_binary_carryover_effective_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX package_binary_carryover_effective_idx ON public.package_binary_carryover_policies USING btree (package_id, effective_day DESC, revision DESC);


--
-- Name: package_binary_product_rewards_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX package_binary_product_rewards_user_id_created_at_idx ON public.package_binary_product_rewards USING btree (user_id, created_at);


--
-- Name: package_upgrade_paths_from_package_id_to_package_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX package_upgrade_paths_from_package_id_to_package_id_key ON public.package_upgrade_paths USING btree (from_package_id, to_package_id);


--
-- Name: package_upgrade_paths_to_package_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX package_upgrade_paths_to_package_id_is_active_idx ON public.package_upgrade_paths USING btree (to_package_id, is_active);


--
-- Name: package_upgrade_products_upgrade_path_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX package_upgrade_products_upgrade_path_id_product_id_key ON public.package_upgrade_products USING btree (upgrade_path_id, product_id);


--
-- Name: passkey_challenges_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passkey_challenges_expires_at_idx ON public.passkey_challenges USING btree (expires_at);


--
-- Name: passkey_challenges_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passkey_challenges_user_id_idx ON public.passkey_challenges USING btree (user_id);


--
-- Name: passkey_credentials_credential_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX passkey_credentials_credential_id_key ON public.passkey_credentials USING btree (credential_id);


--
-- Name: passkey_credentials_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passkey_credentials_user_id_idx ON public.passkey_credentials USING btree (user_id);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_tokens_user_id_expires_at_idx ON public.password_reset_tokens USING btree (user_id, expires_at);


--
-- Name: payable_lot_forfeitures_binary_lot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payable_lot_forfeitures_binary_lot_key ON public.payable_lot_forfeitures USING btree (binary_lot_id);


--
-- Name: payable_lot_forfeitures_direct_lot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payable_lot_forfeitures_direct_lot_key ON public.payable_lot_forfeitures USING btree (direct_lot_id);


--
-- Name: payable_lot_forfeitures_event_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payable_lot_forfeitures_event_source_idx ON public.payable_lot_forfeitures USING btree (deactivation_event_id, source_type);


--
-- Name: payable_lot_forfeitures_product_binary_lot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payable_lot_forfeitures_product_binary_lot_key ON public.payable_lot_forfeitures USING btree (product_binary_lot_id);


--
-- Name: payout_destination_owners_identity_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payout_destination_owners_identity_hash_idx ON public.payout_destination_owners USING btree (identity_hash);


--
-- Name: payouts_batch_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payouts_batch_id_status_idx ON public.payouts USING btree (batch_id, status);


--
-- Name: payouts_disbursement_provider_external_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payouts_disbursement_provider_external_reference_key ON public.payouts USING btree (disbursement_provider, external_reference);


--
-- Name: payouts_normalized_disbursement_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payouts_normalized_disbursement_reference_key ON public.payouts USING btree (lower(regexp_replace(btrim((disbursement_provider)::text), '[[:space:]]+'::text, ' '::text, 'g'::text)), upper(regexp_replace(btrim((external_reference)::text), '[[:space:]]+'::text, ' '::text, 'g'::text))) WHERE ((disbursement_provider IS NOT NULL) AND (external_reference IS NOT NULL));


--
-- Name: payouts_one_pending_per_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payouts_one_pending_per_user ON public.payouts USING btree (user_id) WHERE (status = 'pending'::public."PayoutStatus");


--
-- Name: payouts_released_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payouts_released_at_idx ON public.payouts USING btree (released_at) WHERE (status = 'released'::public."PayoutStatus");


--
-- Name: payouts_transaction_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payouts_transaction_number_key ON public.payouts USING btree (transaction_number);


--
-- Name: person_account_memberships_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_account_memberships_person ON public.person_account_memberships USING btree (person_key);


--
-- Name: pin_registration_product_snapshots_pin_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pin_registration_product_snapshots_pin_id_product_id_key ON public.pin_registration_product_snapshots USING btree (pin_id, product_id);


--
-- Name: pin_request_payment_evidence_method_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pin_request_payment_evidence_method_reference_key ON public.pin_request_payment_evidence USING btree (payment_method_id, lower((reference_number)::text));


--
-- Name: pin_request_payment_evidence_request_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_request_payment_evidence_request_created_idx ON public.pin_request_payment_evidence USING btree (pin_request_id, created_at DESC);


--
-- Name: pin_request_payment_evidence_status_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_request_payment_evidence_status_created_idx ON public.pin_request_payment_evidence USING btree (status, created_at);


--
-- Name: pin_requests_payment_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_requests_payment_due_idx ON public.pin_requests USING btree (payment_due_at) WHERE ((status)::text = 'pending'::text);


--
-- Name: pin_transfers_admin_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_transfers_admin_id_created_at_idx ON public.pin_transfers USING btree (admin_id, created_at);


--
-- Name: pin_transfers_recipient_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_transfers_recipient_id_status_created_at_idx ON public.pin_transfers USING btree (recipient_id, status, created_at);


--
-- Name: pin_upgrade_product_snapshots_pin_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pin_upgrade_product_snapshots_pin_id_product_id_key ON public.pin_upgrade_product_snapshots USING btree (pin_id, product_id);


--
-- Name: pins_city_dist_id_pin_type_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pins_city_dist_id_pin_type_status_idx ON public.pins USING btree (city_dist_id, pin_type, status);


--
-- Name: pins_funding_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pins_funding_order_id_idx ON public.pins USING btree (funding_order_id);


--
-- Name: pins_funding_pin_request_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pins_funding_pin_request_id_idx ON public.pins USING btree (funding_pin_request_id);


--
-- Name: pins_funding_pin_transfer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pins_funding_pin_transfer_id_idx ON public.pins USING btree (funding_pin_transfer_id);


--
-- Name: pins_pin_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pins_pin_code_key ON public.pins USING btree (pin_code);


--
-- Name: pos_adjustment_items_request_item_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_adjustment_items_request_item_key ON public.pos_adjustment_items USING btree (adjustment_request_id, pos_transaction_item_id);


--
-- Name: pos_adjustment_items_transaction_item_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_adjustment_items_transaction_item_id_idx ON public.pos_adjustment_items USING btree (pos_transaction_item_id);


--
-- Name: pos_adjustment_requests_owner_id_status_requested_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_adjustment_requests_owner_id_status_requested_at_idx ON public.pos_adjustment_requests USING btree (owner_id, status, requested_at);


--
-- Name: pos_adjustment_requests_pos_transaction_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_adjustment_requests_pos_transaction_id_status_idx ON public.pos_adjustment_requests USING btree (pos_transaction_id, status);


--
-- Name: pos_cash_movements_client_request_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_cash_movements_client_request_id_key ON public.pos_cash_movements USING btree (client_request_id);


--
-- Name: pos_cash_movements_owner_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_cash_movements_owner_id_status_idx ON public.pos_cash_movements USING btree (owner_id, status);


--
-- Name: pos_cash_movements_shift_id_status_requested_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_cash_movements_shift_id_status_requested_at_idx ON public.pos_cash_movements USING btree (shift_id, status, requested_at);


--
-- Name: pos_enrollment_rate_limits_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_enrollment_rate_limits_expires_at_idx ON public.pos_enrollment_rate_limits USING btree (expires_at);


--
-- Name: pos_inventory_allowances_owner_id_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_inventory_allowances_owner_id_expires_at_idx ON public.pos_inventory_allowances USING btree (owner_id, expires_at);


--
-- Name: pos_inventory_allowances_terminal_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_inventory_allowances_terminal_id_product_id_key ON public.pos_inventory_allowances USING btree (terminal_id, product_id);


--
-- Name: pos_registration_events_actor_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_events_actor_id_created_at_idx ON public.pos_registration_events USING btree (actor_id, created_at);


--
-- Name: pos_registration_events_intake_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_events_intake_id_created_at_idx ON public.pos_registration_events USING btree (intake_id, created_at);


--
-- Name: pos_registration_intakes_cashier_id_shift_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_intakes_cashier_id_shift_id_idx ON public.pos_registration_intakes USING btree (cashier_id, shift_id);


--
-- Name: pos_registration_intakes_client_intake_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_registration_intakes_client_intake_id_key ON public.pos_registration_intakes USING btree (client_intake_id);


--
-- Name: pos_registration_intakes_completed_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_registration_intakes_completed_user_id_key ON public.pos_registration_intakes USING btree (completed_user_id);


--
-- Name: pos_registration_intakes_owner_id_identity_document_hash_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_intakes_owner_id_identity_document_hash_status ON public.pos_registration_intakes USING btree (owner_id, identity_document_hash, status);


--
-- Name: pos_registration_intakes_owner_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_intakes_owner_id_status_created_at_idx ON public.pos_registration_intakes USING btree (owner_id, status, created_at);


--
-- Name: pos_registration_intakes_payment_method_id_payment_reference_ke; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_registration_intakes_payment_method_id_payment_reference_ke ON public.pos_registration_intakes USING btree (payment_method_id, payment_reference);


--
-- Name: pos_registration_intakes_pin_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_registration_intakes_pin_id_key ON public.pos_registration_intakes USING btree (pin_id);


--
-- Name: pos_registration_intakes_receipt_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_registration_intakes_receipt_number_key ON public.pos_registration_intakes USING btree (receipt_number);


--
-- Name: pos_registration_intakes_terminal_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_registration_intakes_terminal_id_created_at_idx ON public.pos_registration_intakes USING btree (terminal_id, created_at);


--
-- Name: pos_shifts_active_terminal_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_shifts_active_terminal_key_key ON public.pos_shifts USING btree (active_terminal_key);


--
-- Name: pos_shifts_owner_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_shifts_owner_id_status_idx ON public.pos_shifts USING btree (owner_id, status);


--
-- Name: pos_shifts_terminal_id_opened_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_shifts_terminal_id_opened_at_idx ON public.pos_shifts USING btree (terminal_id, opened_at);


--
-- Name: pos_sync_events_pos_transaction_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_sync_events_pos_transaction_id_created_at_idx ON public.pos_sync_events USING btree (pos_transaction_id, created_at);


--
-- Name: pos_sync_events_terminal_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_sync_events_terminal_id_created_at_idx ON public.pos_sync_events USING btree (terminal_id, created_at);


--
-- Name: pos_terminal_enrollments_code_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_terminal_enrollments_code_hash_key ON public.pos_terminal_enrollments USING btree (code_hash);


--
-- Name: pos_terminal_enrollments_created_by_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_terminal_enrollments_created_by_id_created_at_idx ON public.pos_terminal_enrollments USING btree (created_by_id, created_at);


--
-- Name: pos_terminal_enrollments_enrolled_terminal_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_terminal_enrollments_enrolled_terminal_id_key ON public.pos_terminal_enrollments USING btree (enrolled_terminal_id);


--
-- Name: pos_terminal_enrollments_owner_id_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_terminal_enrollments_owner_id_expires_at_idx ON public.pos_terminal_enrollments USING btree (owner_id, expires_at);


--
-- Name: pos_terminals_installation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_terminals_installation_id_key ON public.pos_terminals USING btree (installation_id);


--
-- Name: pos_terminals_owner_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_terminals_owner_id_is_active_idx ON public.pos_terminals USING btree (owner_id, is_active);


--
-- Name: pos_terminals_owner_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_terminals_owner_id_name_key ON public.pos_terminals USING btree (owner_id, name);


--
-- Name: pos_terminals_receipt_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_terminals_receipt_code_key ON public.pos_terminals USING btree (receipt_code);


--
-- Name: pos_transaction_items_pos_transaction_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transaction_items_pos_transaction_id_idx ON public.pos_transaction_items USING btree (pos_transaction_id);


--
-- Name: pos_transaction_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transaction_items_product_id_idx ON public.pos_transaction_items USING btree (product_id);


--
-- Name: pos_transactions_client_transaction_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_client_transaction_id_key ON public.pos_transactions USING btree (client_transaction_id);


--
-- Name: pos_transactions_order_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_order_id_key ON public.pos_transactions USING btree (order_id);


--
-- Name: pos_transactions_owner_id_status_local_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transactions_owner_id_status_local_created_at_idx ON public.pos_transactions USING btree (owner_id, status, local_created_at);


--
-- Name: pos_transactions_owner_id_status_reviewed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transactions_owner_id_status_reviewed_at_idx ON public.pos_transactions USING btree (owner_id, status, reviewed_at);


--
-- Name: pos_transactions_payment_method_id_payment_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_payment_method_id_payment_reference_key ON public.pos_transactions USING btree (payment_method_id, payment_reference);


--
-- Name: pos_transactions_receipt_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_receipt_number_key ON public.pos_transactions USING btree (receipt_number);


--
-- Name: pos_transactions_registration_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_registration_id_key ON public.pos_transactions USING btree (registration_id);


--
-- Name: pos_transactions_shift_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transactions_shift_id_idx ON public.pos_transactions USING btree (shift_id);


--
-- Name: pos_transactions_terminal_id_receipt_sequence_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pos_transactions_terminal_id_receipt_sequence_key ON public.pos_transactions USING btree (terminal_id, receipt_sequence);


--
-- Name: pos_transactions_terminal_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_transactions_terminal_id_status_idx ON public.pos_transactions USING btree (terminal_id, status);


--
-- Name: product_area_visibility_product_id_distributor_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_area_visibility_product_id_distributor_id_key ON public.product_area_visibility USING btree (product_id, distributor_id);


--
-- Name: product_binary_allocations_retained_week_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_allocations_retained_week_idx ON public.product_binary_pool_allocations USING btree (week_start) WHERE ((retained_at IS NOT NULL) AND (commission_id IS NULL));


--
-- Name: product_binary_consumption_payout_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_consumption_payout_idx ON public.product_binary_payout_consumptions USING btree (payout_id);


--
-- Name: product_binary_funding_consumption_commission_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_funding_consumption_commission_idx ON public.product_binary_funding_consumptions USING btree (commission_id);


--
-- Name: product_binary_funding_consumption_lot_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_funding_consumption_lot_idx ON public.product_binary_funding_consumptions USING btree (funding_lot_id);


--
-- Name: product_binary_funding_fifo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_funding_fifo_idx ON public.product_binary_funding_lots USING btree (allocated_at, id);


--
-- Name: product_binary_funding_lots_order_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_binary_funding_lots_order_id_key ON public.product_binary_funding_lots USING btree (order_id);


--
-- Name: product_binary_inventory_reserves_distributor_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_inventory_reserves_distributor_product_idx ON public.product_binary_inventory_reserves USING btree (distributor_id, product_id, created_at) WHERE (remaining_units > 0);


--
-- Name: product_binary_lot_user_remaining_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_lot_user_remaining_idx ON public.product_binary_payable_lots USING btree (user_id, remaining_amount, allocated_at);


--
-- Name: product_binary_order_events_buyer_processed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_order_events_buyer_processed_idx ON public.product_binary_order_events USING btree (buyer_user_id, processed_at);


--
-- Name: product_binary_order_events_processed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_order_events_processed_idx ON public.product_binary_order_events USING btree (processed_at);


--
-- Name: product_binary_order_events_settlement_job_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_binary_order_events_settlement_job_id_key ON public.product_binary_order_events USING btree (settlement_job_id);


--
-- Name: product_binary_pair_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pair_created_idx ON public.product_binary_pair_events USING btree (created_at);


--
-- Name: product_binary_pair_events_flashout_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_binary_pair_events_flashout_commission_id_key ON public.product_binary_pair_events USING btree (flashout_commission_id) WHERE (flashout_commission_id IS NOT NULL);


--
-- Name: product_binary_pair_events_normal_commission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_binary_pair_events_normal_commission_id_key ON public.product_binary_pair_events USING btree (normal_commission_id) WHERE (normal_commission_id IS NOT NULL);


--
-- Name: product_binary_pair_rank_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pair_rank_created_idx ON public.product_binary_pair_events USING btree (rank_name_snapshot, created_at);


--
-- Name: product_binary_pair_recipient_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pair_recipient_created_idx ON public.product_binary_pair_events USING btree (recipient_user_id, created_at);


--
-- Name: product_binary_pending_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pending_recipient_idx ON public.product_binary_pool_allocations USING btree (recipient_user_id) WHERE ((commission_id IS NULL) AND (retained_at IS NULL) AND (amount_centavos > 0));


--
-- Name: product_binary_pending_release_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pending_release_idx ON public.product_binary_pool_allocations USING btree (week_start, recipient_user_id) WHERE ((commission_id IS NULL) AND (retained_at IS NULL) AND (amount_centavos > 0));


--
-- Name: product_binary_pool_orders_scan_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pool_orders_scan_idx ON public.product_binary_pool_orders USING btree (week_start, order_event_id);


--
-- Name: product_binary_pool_orders_week_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pool_orders_week_idx ON public.product_binary_pool_orders USING btree (week_start);


--
-- Name: product_binary_pool_pairs_scan_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pool_pairs_scan_idx ON public.product_binary_pool_pairs USING btree (week_start, pair_event_id);


--
-- Name: product_binary_pool_pairs_week_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pool_pairs_week_idx ON public.product_binary_pool_pairs USING btree (week_start);


--
-- Name: product_binary_pu_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pu_expiry ON public.product_binary_pu_lots USING btree (expires_at, recipient_user_id) WHERE (remaining_pu > 0);


--
-- Name: product_binary_pu_fifo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_pu_fifo ON public.product_binary_pu_lots USING btree (recipient_user_id, leg, earned_at, id) WHERE (remaining_pu > 0);


--
-- Name: product_binary_settlement_jobs_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_binary_settlement_jobs_due_idx ON public.product_binary_settlement_jobs USING btree (status, next_attempt_at);


--
-- Name: product_reward_claim_allocations_claim_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_reward_claim_allocations_claim_idx ON public.product_reward_claim_allocations USING btree (claim_id);


--
-- Name: product_reward_claims_member_released_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_reward_claims_member_released_idx ON public.product_reward_claims USING btree (reseller_id, released_at);


--
-- Name: product_reward_claims_owner_released_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_reward_claims_owner_released_idx ON public.product_reward_claims USING btree (owner_id, released_at);


--
-- Name: products_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_barcode_key ON public.products USING btree (barcode);


--
-- Name: public_verification_rate_limits_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX public_verification_rate_limits_expires_at_idx ON public.public_verification_rate_limits USING btree (expires_at);


--
-- Name: rank_bonus_awards_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rank_bonus_awards_user_idx ON public.rank_bonus_awards USING btree (user_id, allocated_at, id) WHERE (remaining_amount > (0)::numeric);


--
-- Name: rank_bonus_funding_quarter_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rank_bonus_funding_quarter_idx ON public.rank_bonus_funding USING btree (quarter_start);


--
-- Name: rank_bonus_qualified_orders_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rank_bonus_qualified_orders_idx ON public.product_binary_settlement_jobs USING btree (buyer_user_id, qualified_at) WHERE ((qualification_status)::text = 'qualified_paid_delivery'::text);


--
-- Name: rank_bonus_quarter_orders_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rank_bonus_quarter_orders_idx ON public.product_binary_settlement_jobs USING btree (qualified_at, buyer_user_id) WHERE ((qualification_status)::text = 'qualified_paid_delivery'::text);


--
-- Name: rank_bonus_referral_sponsor_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rank_bonus_referral_sponsor_idx ON public.direct_referral_settlement_events USING btree (sponsor_user_id);


--
-- Name: ranks_package_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ranks_package_id_name_key ON public.ranks USING btree (package_id, name);


--
-- Name: ranks_package_id_sequence_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ranks_package_id_sequence_key ON public.ranks USING btree (package_id, sequence);


--
-- Name: registration_financials_channel_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registration_financials_channel_created_at_idx ON public.registration_financials USING btree (registration_channel, created_at);


--
-- Name: registration_financials_city_dist_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registration_financials_city_dist_id_created_at_idx ON public.registration_financials USING btree (city_dist_id, created_at);


--
-- Name: registration_financials_city_dist_id_paid_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registration_financials_city_dist_id_paid_at_idx ON public.registration_financials USING btree (city_dist_id, paid_at);


--
-- Name: registration_financials_pin_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX registration_financials_pin_id_key ON public.registration_financials USING btree (pin_id);


--
-- Name: registration_financials_reseller_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registration_financials_reseller_id_idx ON public.registration_financials USING btree (reseller_id);


--
-- Name: reseller_deactivation_events_reseller_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reseller_deactivation_events_reseller_id_created_at_idx ON public.reseller_deactivation_events USING btree (reseller_id, created_at);


--
-- Name: reseller_profiles_pin_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reseller_profiles_pin_id_key ON public.reseller_profiles USING btree (pin_id);


--
-- Name: reseller_profiles_qualification_quarter_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reseller_profiles_qualification_quarter_idx ON public.reseller_profiles USING btree (qualification_quarter_start);


--
-- Name: reseller_profiles_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reseller_profiles_user_id_key ON public.reseller_profiles USING btree (user_id);


--
-- Name: reward_stock_dispatch_items_dispatch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reward_stock_dispatch_items_dispatch_idx ON public.reward_stock_dispatch_items USING btree (dispatch_id);


--
-- Name: reward_stock_dispatches_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reward_stock_dispatches_recipient_idx ON public.reward_stock_dispatches USING btree (recipient_id, dispatched_at);


--
-- Name: reward_stock_dispatches_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reward_stock_dispatches_supplier_idx ON public.reward_stock_dispatches USING btree (supplier_id, dispatched_at);


--
-- Name: reward_stock_units_holder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reward_stock_units_holder_idx ON public.reward_stock_units USING btree (holder_id, product_id, kind) WHERE (settled_at IS NULL);


--
-- Name: staff_profiles_owner_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX staff_profiles_owner_id_idx ON public.staff_profiles USING btree (owner_id);


--
-- Name: staff_profiles_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX staff_profiles_user_id_key ON public.staff_profiles USING btree (user_id);


--
-- Name: support_attachments_request_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_attachments_request_id_idx ON public.support_attachments USING btree (request_id);


--
-- Name: support_captcha_challenges_client_fingerprint_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_captcha_challenges_client_fingerprint_created_at_idx ON public.support_captcha_challenges USING btree (client_fingerprint, created_at);


--
-- Name: support_captcha_challenges_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_captcha_challenges_expires_at_idx ON public.support_captcha_challenges USING btree (expires_at);


--
-- Name: support_messages_request_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_messages_request_id_created_at_idx ON public.support_messages USING btree (request_id, created_at);


--
-- Name: support_requests_assigned_to_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_assigned_to_status_idx ON public.support_requests USING btree (assigned_to, status);


--
-- Name: support_requests_email_fingerprint_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_email_fingerprint_created_at_idx ON public.support_requests USING btree (email_fingerprint, created_at);


--
-- Name: support_requests_source_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_source_created_at_idx ON public.support_requests USING btree (source, created_at);


--
-- Name: support_requests_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_status_created_at_idx ON public.support_requests USING btree (status, created_at);


--
-- Name: support_requests_submitter_fingerprint_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_submitter_fingerprint_created_at_idx ON public.support_requests USING btree (submitter_fingerprint, created_at);


--
-- Name: support_requests_ticket_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX support_requests_ticket_number_key ON public.support_requests USING btree (ticket_number);


--
-- Name: support_requests_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_requests_user_id_created_at_idx ON public.support_requests USING btree (user_id, created_at);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: unilevel_payable_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unilevel_payable_user_idx ON public.unilevel_payable_lots USING btree (user_id, allocated_at, id) WHERE (remaining_amount > (0)::numeric);


--
-- Name: upgrade_financials_city_dist_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upgrade_financials_city_dist_id_created_at_idx ON public.upgrade_financials USING btree (city_dist_id, created_at);


--
-- Name: upgrade_financials_reseller_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upgrade_financials_reseller_id_created_at_idx ON public.upgrade_financials USING btree (reseller_id, created_at);


--
-- Name: users_identity_document_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_identity_document_hash_idx ON public.users USING btree (identity_document_hash) WHERE (identity_document_hash IS NOT NULL);


--
-- Name: users_market_location_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_market_location_idx ON public.users USING btree (region_code, province_code, city_muni_code) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_member_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_member_id_key ON public.users USING btree (member_id);


--
-- Name: users_reseller_created_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_created_at_id_idx ON public.users USING btree (created_at DESC, id) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_reseller_full_name_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_full_name_trgm_idx ON public.users USING gin (lower(full_name) public.gin_trgm_ops) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_reseller_last_name_first_name_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_last_name_first_name_id_idx ON public.users USING btree (last_name, first_name, id) WHERE ((role = 'reseller'::public."Role") AND (last_name IS NOT NULL));


--
-- Name: users_reseller_mobile_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_mobile_trgm_idx ON public.users USING gin (mobile public.gin_trgm_ops) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_reseller_status_created_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_status_created_at_id_idx ON public.users USING btree (status, created_at DESC, id) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_reseller_username_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reseller_username_trgm_idx ON public.users USING gin (lower(username) public.gin_trgm_ops) WHERE (role = 'reseller'::public."Role");


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: walk_in_member_scan_proofs_distributor_id_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX walk_in_member_scan_proofs_distributor_id_expires_at_idx ON public.walk_in_member_scan_proofs USING btree (distributor_id, expires_at);


--
-- Name: walk_in_member_scan_proofs_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX walk_in_member_scan_proofs_expires_at_idx ON public.walk_in_member_scan_proofs USING btree (expires_at);


--
-- Name: walk_in_member_scan_proofs_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX walk_in_member_scan_proofs_token_hash_key ON public.walk_in_member_scan_proofs USING btree (token_hash);


--
-- Name: wallet_ledger_entries_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wallet_ledger_entries_source_idx ON public.wallet_ledger_entries USING btree (source_kind, source_event_id);


--
-- Name: wallet_ledger_entries_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wallet_ledger_entries_user_created_idx ON public.wallet_ledger_entries USING btree (user_id, created_at);


--
-- Name: wallets_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wallets_user_id_key ON public.wallets USING btree (user_id);


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER admin_stock_receipt_items_append_only BEFORE INSERT OR DELETE OR UPDATE ON public.admin_stock_receipt_items FOR EACH ROW EXECUTE FUNCTION public.protect_admin_stock_receipt_item();


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_validate_total; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER admin_stock_receipt_items_validate_total AFTER INSERT ON public.admin_stock_receipt_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_admin_stock_receipt_total();


--
-- Name: admin_stock_receipts admin_stock_receipts_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER admin_stock_receipts_append_only BEFORE INSERT OR DELETE OR UPDATE ON public.admin_stock_receipts FOR EACH ROW EXECUTE FUNCTION public.protect_admin_stock_receipt();


--
-- Name: admin_stock_receipts admin_stock_receipts_validate_total; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER admin_stock_receipts_validate_total AFTER INSERT ON public.admin_stock_receipts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_admin_stock_receipt_header_total();


--
-- Name: audit_logs audit_logs_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_logs_append_only BEFORE DELETE OR UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: audit_logs audit_logs_require_valid_payout_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER audit_logs_require_valid_payout_evidence AFTER INSERT ON public.audit_logs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_valid_payout_audit_evidence();


--
-- Name: audit_logs audit_logs_stamp_evidence_time; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_logs_stamp_evidence_time BEFORE INSERT ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.stamp_audit_log_evidence_time();


--
-- Name: binary_daily_cap_usage binary_daily_cap_usage_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_daily_cap_usage_no_truncate BEFORE TRUNCATE ON public.binary_daily_cap_usage FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: binary_daily_cap_usage binary_daily_cap_usage_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_daily_cap_usage_protect BEFORE INSERT OR DELETE OR UPDATE ON public.binary_daily_cap_usage FOR EACH ROW EXECUTE FUNCTION public.protect_binary_daily_cap_usage();


--
-- Name: binary_pair_events binary_pair_events_accumulate_daily_cap; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_pair_events_accumulate_daily_cap AFTER INSERT ON public.binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.accumulate_binary_daily_cap_usage();


--
-- Name: binary_pair_events binary_pair_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_pair_events_append_only BEFORE DELETE OR UPDATE ON public.binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: binary_pair_events binary_pair_events_credit_product_reward; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_pair_events_credit_product_reward AFTER INSERT ON public.binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.credit_package_binary_product_reward();


--
-- Name: binary_pair_events binary_pair_events_validate_closing_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_pair_events_validate_closing_state AFTER INSERT ON public.binary_pair_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_pair_event_closing_state();


--
-- Name: binary_pair_events binary_pair_events_validate_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_pair_events_validate_entitlement BEFORE INSERT ON public.binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.validate_binary_pair_event_entitlement();


--
-- Name: binary_pair_events binary_pair_events_verify_session; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_pair_events_verify_session AFTER INSERT ON public.binary_pair_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_session_closing_state();


--
-- Name: binary_payable_lots binary_payable_lots_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_payable_lots_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.binary_payable_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: binary_payout_consumptions binary_payout_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_payout_consumptions_append_only BEFORE DELETE OR UPDATE ON public.binary_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: binary_payout_consumptions binary_payout_consumptions_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_payout_consumptions_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.binary_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: binary_point_consumptions binary_point_consumptions_balance_check; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_point_consumptions_balance_check AFTER INSERT ON public.binary_point_consumptions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_point_evidence_balance();


--
-- Name: binary_point_consumptions binary_point_consumptions_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_point_consumptions_protect BEFORE DELETE OR UPDATE ON public.binary_point_consumptions FOR EACH ROW EXECUTE FUNCTION public.protect_binary_point_evidence();


--
-- Name: binary_point_expirations binary_point_expirations_balance_check; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_point_expirations_balance_check AFTER INSERT ON public.binary_point_expirations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_point_evidence_balance();


--
-- Name: binary_point_expirations binary_point_expirations_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_point_expirations_protect BEFORE DELETE OR UPDATE ON public.binary_point_expirations FOR EACH ROW EXECUTE FUNCTION public.protect_binary_point_evidence();


--
-- Name: binary_point_lots binary_point_lots_balance_check; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_point_lots_balance_check AFTER INSERT OR UPDATE ON public.binary_point_lots DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_point_lot_balance();


--
-- Name: binary_point_lots binary_point_lots_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_point_lots_protect BEFORE DELETE OR UPDATE ON public.binary_point_lots FOR EACH ROW EXECUTE FUNCTION public.protect_binary_point_lot();


--
-- Name: binary_reserve_consumptions binary_reserve_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_reserve_consumptions_append_only BEFORE DELETE OR UPDATE ON public.binary_reserve_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: binary_reserve_consumptions binary_reserve_consumptions_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_reserve_consumptions_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.binary_reserve_consumptions FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: binary_reserve_lots binary_reserve_lots_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_reserve_lots_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.binary_reserve_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: binary_settlement_events binary_settlement_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_settlement_events_append_only BEFORE DELETE OR UPDATE ON public.binary_settlement_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: binary_settlement_events binary_settlement_events_validate_completeness; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER binary_settlement_events_validate_completeness AFTER INSERT ON public.binary_settlement_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_binary_settlement_event_completeness();


--
-- Name: binary_settlement_events binary_settlement_events_validate_source_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_settlement_events_validate_source_entitlement BEFORE INSERT ON public.binary_settlement_events FOR EACH ROW EXECUTE FUNCTION public.validate_binary_settlement_source_entitlement();


--
-- Name: binary_tree_nodes binary_tree_nodes_block_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_tree_nodes_block_truncate BEFORE TRUNCATE ON public.binary_tree_nodes FOR EACH STATEMENT EXECUTE FUNCTION public.protect_binary_tree_placement_identity();

ALTER TABLE public.binary_tree_nodes ENABLE ALWAYS TRIGGER binary_tree_nodes_block_truncate;


--
-- Name: binary_tree_nodes binary_tree_nodes_maintain_ancestor_counts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_tree_nodes_maintain_ancestor_counts AFTER INSERT ON public.binary_tree_nodes FOR EACH ROW EXECUTE FUNCTION public.maintain_binary_tree_ancestor_counts();

ALTER TABLE public.binary_tree_nodes ENABLE ALWAYS TRIGGER binary_tree_nodes_maintain_ancestor_counts;


--
-- Name: binary_tree_nodes binary_tree_nodes_seal_placement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_tree_nodes_seal_placement BEFORE DELETE OR UPDATE ON public.binary_tree_nodes FOR EACH ROW EXECUTE FUNCTION public.protect_binary_tree_placement_identity();

ALTER TABLE public.binary_tree_nodes ENABLE ALWAYS TRIGGER binary_tree_nodes_seal_placement;


--
-- Name: binary_tree_nodes binary_tree_nodes_validate_leaf_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER binary_tree_nodes_validate_leaf_insert BEFORE INSERT ON public.binary_tree_nodes FOR EACH ROW EXECUTE FUNCTION public.validate_binary_tree_leaf_insert();

ALTER TABLE public.binary_tree_nodes ENABLE ALWAYS TRIGGER binary_tree_nodes_validate_leaf_insert;


--
-- Name: commissions commissions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_append_only BEFORE DELETE OR UPDATE ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: commissions commissions_consume_binary_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_consume_binary_reserve AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.consume_binary_reserve();


--
-- Name: commissions commissions_create_binary_payable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_create_binary_payable AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.create_binary_payable_lot();


--
-- Name: commissions commissions_create_direct_referral_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_create_direct_referral_reserve AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.create_direct_referral_reserve_lot();


--
-- Name: commissions commissions_create_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_create_notification AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.notify_all_account_commission();


--
-- Name: commissions commissions_create_product_binary_payable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_create_product_binary_payable AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.create_product_binary_payable_lot();


--
-- Name: commissions commissions_fund_product_binary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_fund_product_binary AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.fund_product_binary_commission();


--
-- Name: commissions commissions_require_direct_referral_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER commissions_require_direct_referral_event AFTER INSERT ON public.commissions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_direct_referral_commission_event();


--
-- Name: commissions commissions_validate_exact_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER commissions_validate_exact_entitlement AFTER INSERT ON public.commissions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_exact_commission_entitlement();


--
-- Name: commissions commissions_validate_provenance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER commissions_validate_provenance BEFORE INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.validate_new_commission_provenance();


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER direct_referral_payout_consumptions_append_only BEFORE DELETE OR UPDATE ON public.direct_referral_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER direct_referral_payout_consumptions_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.direct_referral_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: direct_referral_reserve_lots direct_referral_reserve_lots_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER direct_referral_reserve_lots_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.direct_referral_reserve_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: direct_referral_settlement_events direct_referral_settlement_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER direct_referral_settlement_append_only BEFORE DELETE OR UPDATE ON public.direct_referral_settlement_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: direct_referral_settlement_events direct_referral_settlement_validate_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER direct_referral_settlement_validate_insert BEFORE INSERT ON public.direct_referral_settlement_events FOR EACH ROW EXECUTE FUNCTION public.validate_direct_referral_settlement_insert();


--
-- Name: direct_referral_settlement_events direct_referral_settlement_verify_commit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER direct_referral_settlement_verify_commit AFTER INSERT ON public.direct_referral_settlement_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_direct_referral_settlement_commit();


--
-- Name: distributor_profiles distributor_parent_territory; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER distributor_parent_territory BEFORE INSERT OR UPDATE OF parent_dist_id, region_code, province_code, city_muni_code, dist_level, is_active ON public.distributor_profiles FOR EACH ROW EXECUTE FUNCTION public.validate_distributor_parent_territory();


--
-- Name: distributor_profiles distributor_profiles_exclusive_territory; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER distributor_profiles_exclusive_territory BEFORE INSERT OR UPDATE OF is_active, dist_level, region_code, province_code, city_muni_code ON public.distributor_profiles FOR EACH ROW EXECUTE FUNCTION public.enforce_exclusive_distributor_territory();


--
-- Name: payment_methods enforce_reseller_payout_destination_owner_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER enforce_reseller_payout_destination_owner_trigger BEFORE INSERT OR UPDATE OF user_id, type, bank_name, account_number ON public.payment_methods FOR EACH ROW EXECUTE FUNCTION public.enforce_reseller_payout_destination_owner();


--
-- Name: financial_operation_receipts financial_operation_receipt_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER financial_operation_receipt_immutable BEFORE DELETE OR UPDATE ON public.financial_operation_receipts FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: financial_operation_receipts financial_operation_receipt_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER financial_operation_receipt_no_truncate BEFORE TRUNCATE ON public.financial_operation_receipts FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: financial_operation_receipts financial_operation_receipt_validate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER financial_operation_receipt_validate BEFORE INSERT ON public.financial_operation_receipts FOR EACH ROW EXECUTE FUNCTION public.validate_financial_operation_receipt();


--
-- Name: inventory_audit_events inventory_audit_events_no_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_audit_events_no_delete BEFORE DELETE ON public.inventory_audit_events FOR EACH ROW EXECUTE FUNCTION public.prevent_inventory_audit_event_mutation();


--
-- Name: inventory_audit_events inventory_audit_events_no_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_audit_events_no_update BEFORE UPDATE ON public.inventory_audit_events FOR EACH ROW EXECUTE FUNCTION public.prevent_inventory_audit_event_mutation();


--
-- Name: inventory_audit_events inventory_audit_retain_product_binary_package; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_audit_retain_product_binary_package AFTER INSERT ON public.inventory_audit_events FOR EACH ROW EXECUTE FUNCTION public.retain_product_binary_package_stock();


--
-- Name: inventory_audit_events inventory_audit_retain_product_binary_replacement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_audit_retain_product_binary_replacement AFTER INSERT ON public.inventory_audit_events FOR EACH ROW EXECUTE FUNCTION public.retain_product_binary_replacement_stock();


--
-- Name: inventory_movements inventory_movements_seal_financial_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_movements_seal_financial_identity BEFORE DELETE OR UPDATE ON public.inventory_movements FOR EACH ROW EXECUTE FUNCTION public.seal_inventory_movement_financial_identity();


--
-- Name: inventory_transfers inventory_transfers_earmark_product_binary_branch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_transfers_earmark_product_binary_branch AFTER UPDATE OF status ON public.inventory_transfers FOR EACH ROW EXECUTE FUNCTION public.earmark_product_binary_branch_receipt();


--
-- Name: inventory_transfers inventory_transfers_protect_custody; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_transfers_protect_custody BEFORE INSERT OR DELETE OR UPDATE ON public.inventory_transfers FOR EACH ROW EXECUTE FUNCTION public.protect_inventory_transfer_custody();


--
-- Name: member_id_issuances member_id_issuances_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER member_id_issuances_append_only BEFORE DELETE OR UPDATE ON public.member_id_issuances FOR EACH ROW EXECUTE FUNCTION public.reject_member_id_issuance_change();


--
-- Name: member_id_issuances member_id_issuances_validate_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER member_id_issuances_validate_insert BEFORE INSERT ON public.member_id_issuances FOR EACH ROW EXECUTE FUNCTION public.validate_member_id_issuance_insert();


--
-- Name: order_items order_items_reject_pin_sale_order; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_items_reject_pin_sale_order BEFORE INSERT OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.reject_commerce_link_to_pin_sale_order();


--
-- Name: order_items order_items_seal_product_binary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_items_seal_product_binary BEFORE DELETE OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.seal_product_binary_order_item();


--
-- Name: order_items order_items_snapshot_product_binary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_items_snapshot_product_binary BEFORE INSERT ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.snapshot_product_binary_order_item();


--
-- Name: order_messages order_messages_immutable_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_messages_immutable_guard BEFORE DELETE OR UPDATE ON public.order_messages FOR EACH ROW EXECUTE FUNCTION public.reject_order_message_mutation();


--
-- Name: order_messages order_messages_participant_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_messages_participant_guard BEFORE INSERT ON public.order_messages FOR EACH ROW EXECUTE FUNCTION public.enforce_order_message_participants();


--
-- Name: order_replacement_requests order_replacement_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_replacement_no_truncate BEFORE TRUNCATE ON public.order_replacement_requests FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: order_replacement_requests order_replacement_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_replacement_protect BEFORE INSERT OR DELETE OR UPDATE ON public.order_replacement_requests FOR EACH ROW EXECUTE FUNCTION public.protect_combined_order_replacement();


--
-- Name: order_replacement_requests order_replacement_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_replacement_reserve AFTER INSERT ON public.order_replacement_requests FOR EACH ROW EXECUTE FUNCTION public.reserve_combined_order_replacement();


--
-- Name: order_replacement_units order_replacement_units_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_replacement_units_no_truncate BEFORE TRUNCATE ON public.order_replacement_units FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: order_replacement_units order_replacement_units_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_replacement_units_protect BEFORE INSERT OR DELETE OR UPDATE ON public.order_replacement_units FOR EACH ROW EXECUTE FUNCTION public.protect_combined_order_unit();


--
-- Name: orders orders_combined_replacements; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_combined_replacements AFTER UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.settle_combined_order_replacements();


--
-- Name: orders orders_create_buyer_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_create_buyer_notification AFTER INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.notify_all_order_parties();


--
-- Name: orders orders_enforce_reseller_pickup_schedule; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_enforce_reseller_pickup_schedule BEFORE INSERT OR UPDATE OF pickup_scheduled_at, pickup_schedule_timezone ON public.orders FOR EACH ROW EXECUTE FUNCTION public.enforce_reseller_pickup_schedule();


--
-- Name: orders orders_protect_cancellation_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_protect_cancellation_evidence BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.protect_order_cancellation_evidence();


--
-- Name: orders orders_protect_paid_pin_sale; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_protect_paid_pin_sale BEFORE INSERT OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.protect_paid_pin_sale_order();


--
-- Name: orders orders_qualify_product_binary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER orders_qualify_product_binary AFTER INSERT OR UPDATE ON public.orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.qualify_product_binary_order_trigger();


--
-- Name: orders orders_retain_product_binary_non_member_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER orders_retain_product_binary_non_member_reserve AFTER INSERT OR UPDATE OF payment_status, status ON public.orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.retain_product_binary_non_member_reserve();


--
-- Name: orders orders_seal_product_binary_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_seal_product_binary_identity BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.seal_product_binary_order_identity();


--
-- Name: orders orders_snapshot_geography_before_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_snapshot_geography_before_insert BEFORE INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.snapshot_order_geography();


--
-- Name: orders orders_stamp_product_binary_times; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_stamp_product_binary_times BEFORE INSERT OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.stamp_product_binary_order_times();


--
-- Name: orders orders_update_buyer_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_update_buyer_notification AFTER UPDATE OF status, payment_status ON public.orders FOR EACH ROW EXECUTE FUNCTION public.notify_all_order_parties();


--
-- Name: orders orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: package_binary_cap_policies package_binary_cap_policy_audit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER package_binary_cap_policy_audit AFTER INSERT ON public.package_binary_cap_policies DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_package_binary_cap_policy_audit();


--
-- Name: package_binary_cap_policies package_binary_cap_policy_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_cap_policy_no_truncate BEFORE TRUNCATE ON public.package_binary_cap_policies FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: package_binary_cap_policies package_binary_cap_policy_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_cap_policy_protect BEFORE INSERT OR DELETE OR UPDATE ON public.package_binary_cap_policies FOR EACH ROW EXECUTE FUNCTION public.protect_package_binary_cap_policy();


--
-- Name: package_binary_carryover_policies package_binary_carryover_audit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER package_binary_carryover_audit AFTER INSERT ON public.package_binary_carryover_policies DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_package_binary_carryover_audit();


--
-- Name: package_binary_carryover_policies package_binary_carryover_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_carryover_no_truncate BEFORE TRUNCATE ON public.package_binary_carryover_policies FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: package_binary_carryover_policies package_binary_carryover_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_carryover_protect BEFORE INSERT OR DELETE OR UPDATE ON public.package_binary_carryover_policies FOR EACH ROW EXECUTE FUNCTION public.protect_package_binary_carryover_policy();


--
-- Name: package_binary_product_rewards package_binary_product_rewards_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_product_rewards_append_only BEFORE DELETE OR UPDATE ON public.package_binary_product_rewards FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: package_binary_product_rewards package_binary_product_rewards_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_product_rewards_no_truncate BEFORE TRUNCATE ON public.package_binary_product_rewards FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: package_binary_product_rewards package_binary_product_rewards_validate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_binary_product_rewards_validate BEFORE INSERT ON public.package_binary_product_rewards FOR EACH ROW EXECUTE FUNCTION public.validate_package_binary_product_reward();


--
-- Name: package_upgrade_paths package_upgrade_paths_validate_ordering; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_upgrade_paths_validate_ordering BEFORE INSERT OR UPDATE OF from_package_id, to_package_id, pin_price, is_active ON public.package_upgrade_paths FOR EACH ROW EXECUTE FUNCTION public.validate_package_upgrade_path_ordering();


--
-- Name: packages packages_enforce_product_binary_plan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER packages_enforce_product_binary_plan BEFORE INSERT OR UPDATE OF name, point_php_value, product_binary_cap_enabled, daily_product_pairing_cap ON public.packages FOR EACH ROW EXECUTE FUNCTION public.enforce_fixed_product_binary_package_plan();


--
-- Name: packages packages_initialize_carryover; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER packages_initialize_carryover AFTER INSERT ON public.packages FOR EACH ROW EXECUTE FUNCTION public.initialize_package_binary_carryover();


--
-- Name: packages packages_protect_binary_cap; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER packages_protect_binary_cap BEFORE INSERT OR UPDATE ON public.packages FOR EACH ROW EXECUTE FUNCTION public.reject_legacy_package_cap_edit();


--
-- Name: packages packages_revalidate_upgrade_paths; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER packages_revalidate_upgrade_paths AFTER UPDATE OF price, direct_referral_bonus, pairing_bonus_value, is_active ON public.packages DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.revalidate_package_upgrade_paths();


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payable_lot_forfeitures_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.payable_lot_forfeitures FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: payment_methods payment_methods_update_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payment_methods_update_notification AFTER UPDATE OF status ON public.payment_methods FOR EACH ROW EXECUTE FUNCTION public.notify_all_account_payment_method();


--
-- Name: payouts payouts_allocate_direct_referral_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payouts_allocate_direct_referral_reserve AFTER INSERT OR UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.allocate_approved_direct_referral_payout();


--
-- Name: payouts payouts_enforce_identity_and_transitions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payouts_enforce_identity_and_transitions BEFORE INSERT OR UPDATE ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.enforce_payout_identity_and_status_transition();


--
-- Name: payouts payouts_require_complete_audit_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER payouts_require_complete_audit_evidence AFTER INSERT OR UPDATE OF status ON public.payouts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_complete_payout_audit_evidence();


--
-- Name: payouts payouts_require_complete_ledger_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER payouts_require_complete_ledger_state AFTER INSERT OR UPDATE OF status ON public.payouts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_complete_payout_ledger_state();


--
-- Name: payouts payouts_require_reseller_recipient; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payouts_require_reseller_recipient BEFORE INSERT OR UPDATE ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.enforce_reseller_payout_recipient();


--
-- Name: payouts payouts_update_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payouts_update_notification AFTER UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.notify_all_account_payout();


--
-- Name: person_account_documents person_documents_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_documents_no_truncate BEFORE TRUNCATE ON public.person_account_documents FOR EACH STATEMENT EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: person_account_documents person_documents_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_documents_protected BEFORE INSERT OR DELETE OR UPDATE ON public.person_account_documents FOR EACH ROW EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: person_account_memberships person_memberships_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_memberships_no_truncate BEFORE TRUNCATE ON public.person_account_memberships FOR EACH STATEMENT EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: person_account_memberships person_memberships_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_memberships_protected BEFORE INSERT OR DELETE OR UPDATE ON public.person_account_memberships FOR EACH ROW EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: person_account_totals person_totals_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_totals_no_truncate BEFORE TRUNCATE ON public.person_account_totals FOR EACH STATEMENT EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: person_account_totals person_totals_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER person_totals_protected BEFORE INSERT OR DELETE OR UPDATE ON public.person_account_totals FOR EACH ROW EXECUTE FUNCTION public.protect_person_account_registry();


--
-- Name: pin_registration_product_snapshots pin_registration_product_snapshots_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_registration_product_snapshots_append_only BEFORE DELETE OR UPDATE ON public.pin_registration_product_snapshots FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: pin_registration_product_snapshots pin_registration_products_validate_totals; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pin_registration_products_validate_totals AFTER INSERT ON public.pin_registration_product_snapshots DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_registration_pin_after_product_snapshot();


--
-- Name: pin_request_payment_evidence pin_request_payment_evidence_protect_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_request_payment_evidence_protect_delete BEFORE DELETE ON public.pin_request_payment_evidence FOR EACH ROW EXECUTE FUNCTION public.protect_pin_request_payment_evidence();


--
-- Name: pin_request_payment_evidence pin_request_payment_evidence_protect_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_request_payment_evidence_protect_update BEFORE UPDATE ON public.pin_request_payment_evidence FOR EACH ROW EXECUTE FUNCTION public.protect_pin_request_payment_evidence();


--
-- Name: pin_requests pin_requests_protect_registration_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_requests_protect_registration_snapshot BEFORE UPDATE ON public.pin_requests FOR EACH ROW EXECUTE FUNCTION public.protect_pin_request_registration_snapshot();


--
-- Name: pin_requests pin_requests_require_decision_actor; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_requests_require_decision_actor BEFORE UPDATE ON public.pin_requests FOR EACH ROW EXECUTE FUNCTION public.require_pin_request_decision_actor();


--
-- Name: pin_requests pin_requests_validate_and_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_requests_validate_and_protect BEFORE INSERT OR UPDATE ON public.pin_requests FOR EACH ROW EXECUTE FUNCTION public.validate_and_protect_pin_request();


--
-- Name: pin_requests pin_requests_validate_new_payment_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_requests_validate_new_payment_evidence BEFORE INSERT ON public.pin_requests FOR EACH ROW EXECUTE FUNCTION public.validate_new_pin_request_payment_evidence();


--
-- Name: pin_transfers pin_transfers_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_transfers_protect BEFORE INSERT OR DELETE OR UPDATE ON public.pin_transfers FOR EACH ROW EXECUTE FUNCTION public.protect_pin_transfer();


--
-- Name: pin_transfers pin_transfers_validate_batch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pin_transfers_validate_batch AFTER INSERT OR UPDATE ON public.pin_transfers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_pin_transfer_batch();


--
-- Name: pin_upgrade_product_snapshots pin_upgrade_product_snapshots_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_upgrade_product_snapshots_append_only BEFORE DELETE OR UPDATE ON public.pin_upgrade_product_snapshots FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: pin_upgrade_product_snapshots pin_upgrade_products_validate_totals; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pin_upgrade_products_validate_totals AFTER INSERT ON public.pin_upgrade_product_snapshots DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_upgrade_pin_after_product_snapshot();


--
-- Name: pins pins_protect_registration_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pins_protect_registration_snapshot BEFORE UPDATE ON public.pins FOR EACH ROW EXECUTE FUNCTION public.protect_registration_snapshot_identity();


--
-- Name: pins pins_protect_upgrade_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pins_protect_upgrade_snapshot BEFORE UPDATE ON public.pins FOR EACH ROW EXECUTE FUNCTION public.protect_upgrade_snapshot_identity();


--
-- Name: pins pins_validate_paid_source; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pins_validate_paid_source AFTER INSERT OR UPDATE ON public.pins DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_pin_paid_source();


--
-- Name: pins pins_validate_registration_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pins_validate_registration_snapshot AFTER INSERT OR UPDATE ON public.pins DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_registration_pin_snapshot();


--
-- Name: pins pins_validate_upgrade_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pins_validate_upgrade_snapshot AFTER INSERT OR UPDATE ON public.pins DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_upgrade_pin_snapshot();


--
-- Name: pos_adjustment_requests pos_adjustment_restore_product_binary_inventory_reserve; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER pos_adjustment_restore_product_binary_inventory_reserve AFTER UPDATE OF status ON public.pos_adjustment_requests DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.restore_product_binary_reserve_on_pos_return();


--
-- Name: pos_registration_intakes pos_registration_intakes_identity_write_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pos_registration_intakes_identity_write_lock BEFORE INSERT OR UPDATE OF identity_document_hash, released_at ON public.pos_registration_intakes FOR EACH ROW EXECUTE FUNCTION public.lock_pos_registration_intake_identity_write();


--
-- Name: pos_registration_intakes pos_registration_intakes_protect_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pos_registration_intakes_protect_snapshot BEFORE INSERT OR UPDATE ON public.pos_registration_intakes FOR EACH ROW EXECUTE FUNCTION public.validate_and_protect_pos_registration_snapshot();


--
-- Name: pos_transactions pos_transactions_reject_pin_sale_order; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pos_transactions_reject_pin_sale_order BEFORE INSERT OR UPDATE ON public.pos_transactions FOR EACH ROW EXECUTE FUNCTION public.reject_commerce_link_to_pin_sale_order();


--
-- Name: product_binary_pool_allocations product_binary_allocations_seal_closed_amount; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_allocations_seal_closed_amount BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_pool_allocations FOR EACH ROW EXECUTE FUNCTION public.seal_closed_product_binary_allocation();


--
-- Name: product_binary_funding_consumptions product_binary_funding_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_consumptions_append_only BEFORE DELETE OR UPDATE ON public.product_binary_funding_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_funding_consumptions product_binary_funding_consumptions_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_consumptions_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_funding_consumptions FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: product_binary_funding_lots product_binary_funding_lot_earmark_inventory; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_lot_earmark_inventory AFTER INSERT ON public.product_binary_funding_lots FOR EACH ROW EXECUTE FUNCTION public.earmark_product_binary_inventory_funding();


--
-- Name: product_binary_funding_lots product_binary_funding_lots_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_lots_immutable BEFORE DELETE OR UPDATE ON public.product_binary_funding_lots FOR EACH ROW EXECUTE FUNCTION public.seal_product_binary_funding_lot();


--
-- Name: product_binary_funding_lots product_binary_funding_lots_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_lots_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_funding_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: product_binary_funding_lots product_binary_funding_lots_validate_balance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER product_binary_funding_lots_validate_balance AFTER INSERT OR UPDATE ON public.product_binary_funding_lots DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_funding_lot_balance();


--
-- Name: product_binary_funding_lots product_binary_funding_lots_validate_source; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_funding_lots_validate_source BEFORE INSERT ON public.product_binary_funding_lots FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_funding_lot_source();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_capture_unilevel; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_jobs_capture_unilevel AFTER INSERT OR UPDATE OF qualification_status, qualified_at ON public.product_binary_settlement_jobs FOR EACH ROW EXECUTE FUNCTION public.capture_unilevel_qualification();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_protect_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_jobs_protect_identity BEFORE DELETE OR UPDATE ON public.product_binary_settlement_jobs FOR EACH ROW EXECUTE FUNCTION public.protect_product_binary_job_identity();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_seal_snapshots; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_jobs_seal_snapshots BEFORE UPDATE ON public.product_binary_settlement_jobs FOR EACH ROW EXECUTE FUNCTION public.seal_product_binary_job_snapshots();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_settle_unilevel; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_jobs_settle_unilevel AFTER UPDATE OF status ON public.product_binary_settlement_jobs FOR EACH ROW EXECUTE FUNCTION public.settle_unilevel_order();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_validate_completion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER product_binary_jobs_validate_completion AFTER INSERT OR UPDATE ON public.product_binary_settlement_jobs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_job_completion();


--
-- Name: product_binary_settlement_jobs product_binary_jobs_validate_source; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_jobs_validate_source BEFORE INSERT OR UPDATE ON public.product_binary_settlement_jobs FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_job_source();


--
-- Name: product_binary_order_events product_binary_order_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_order_events_append_only BEFORE DELETE OR UPDATE ON public.product_binary_order_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_order_events product_binary_order_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_order_events_immutable BEFORE DELETE OR UPDATE ON public.product_binary_order_events FOR EACH ROW EXECUTE FUNCTION public.seal_product_binary_source_rows();


--
-- Name: product_binary_order_events product_binary_order_events_validate_completeness; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER product_binary_order_events_validate_completeness AFTER INSERT ON public.product_binary_order_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_order_event_completeness();


--
-- Name: product_binary_order_events product_binary_order_events_validate_source; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_order_events_validate_source BEFORE INSERT ON public.product_binary_order_events FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_order_event_source();


--
-- Name: product_binary_pair_events product_binary_pair_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pair_events_append_only BEFORE DELETE OR UPDATE ON public.product_binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_pair_events product_binary_pair_events_validate_closing_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER product_binary_pair_events_validate_closing_state AFTER INSERT ON public.product_binary_pair_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_pair_event_closing_state();


--
-- Name: product_binary_pair_events product_binary_pair_events_validate_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pair_events_validate_entitlement BEFORE INSERT ON public.product_binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.validate_product_binary_pair_event_entitlement();


--
-- Name: product_binary_payable_lots product_binary_payable_lots_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_payable_lots_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_payable_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: product_binary_payout_consumptions product_binary_payout_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_payout_consumptions_append_only BEFORE DELETE OR UPDATE ON public.product_binary_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_payout_consumptions product_binary_payout_consumptions_protected_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_payout_consumptions_protected_write BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: product_binary_pool_orders product_binary_pool_order_allocate_funding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_order_allocate_funding BEFORE INSERT ON public.product_binary_pool_orders FOR EACH ROW EXECUTE FUNCTION public.allocate_product_binary_pool_order_funding();


--
-- Name: product_binary_pool_orders product_binary_pool_orders_require_full_funding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_orders_require_full_funding AFTER INSERT ON public.product_binary_pool_orders FOR EACH ROW EXECUTE FUNCTION public.require_fully_funded_product_binary_pool_order();


--
-- Name: product_binary_pool_orders product_binary_pool_orders_require_open_week; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_orders_require_open_week BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_pool_orders FOR EACH ROW EXECUTE FUNCTION public.require_open_product_binary_pool_week();


--
-- Name: product_binary_pool_pairs product_binary_pool_pairs_require_open_week; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_pairs_require_open_week BEFORE INSERT OR DELETE OR UPDATE ON public.product_binary_pool_pairs FOR EACH ROW EXECUTE FUNCTION public.require_open_product_binary_pool_week();


--
-- Name: product_binary_pair_events product_binary_pool_queue_pair; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_queue_pair AFTER INSERT ON public.product_binary_pair_events FOR EACH ROW EXECUTE FUNCTION public.queue_product_binary_pool_pair();


--
-- Name: product_binary_pool_weeks product_binary_pool_weeks_reserve_funding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_pool_weeks_reserve_funding BEFORE UPDATE OF closed_at ON public.product_binary_pool_weeks FOR EACH ROW EXECUTE FUNCTION public.reserve_closed_product_binary_week_funding();


--
-- Name: system_settings product_binary_sync_open_week_rate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_binary_sync_open_week_rate AFTER INSERT OR UPDATE OF value ON public.system_settings FOR EACH ROW WHEN ((new.key = 'product_binary_pair_amount'::text)) EXECUTE FUNCTION public.sync_open_product_binary_week_rate();


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claim_allocations_no_truncate BEFORE TRUNCATE ON public.product_reward_claim_allocations FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claim_allocations_protect BEFORE INSERT OR DELETE OR UPDATE ON public.product_reward_claim_allocations FOR EACH ROW EXECUTE FUNCTION public.protect_product_reward_claim_data();


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claim_proofs_no_truncate BEFORE TRUNCATE ON public.product_reward_claim_proofs FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claim_proofs_protect BEFORE DELETE OR UPDATE ON public.product_reward_claim_proofs FOR EACH ROW EXECUTE FUNCTION public.protect_product_reward_claim_data();


--
-- Name: product_reward_claims product_reward_claims_fulfill; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claims_fulfill AFTER INSERT ON public.product_reward_claims FOR EACH ROW EXECUTE FUNCTION public.fulfill_product_reward_claim();


--
-- Name: product_reward_claims product_reward_claims_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claims_immutable BEFORE DELETE OR UPDATE ON public.product_reward_claims FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_reward_claims product_reward_claims_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claims_no_truncate BEFORE TRUNCATE ON public.product_reward_claims FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_reward_claims product_reward_claims_validate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_reward_claims_validate BEFORE INSERT ON public.product_reward_claims FOR EACH ROW EXECUTE FUNCTION public.release_product_reward_claim();


--
-- Name: payouts protect_payout_batch_identity_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER protect_payout_batch_identity_trigger BEFORE INSERT OR UPDATE OF batch_id ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.protect_payout_batch_identity();


--
-- Name: payouts protect_payout_disbursement_evidence_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER protect_payout_disbursement_evidence_trigger BEFORE INSERT OR UPDATE ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.protect_payout_disbursement_evidence();


--
-- Name: rank_bonus_awards rank_bonus_awards_protected_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rank_bonus_awards_protected_update BEFORE DELETE OR UPDATE ON public.rank_bonus_awards FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: rank_bonus_payout_consumptions rank_bonus_consumptions_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rank_bonus_consumptions_append_only BEFORE DELETE OR UPDATE ON public.rank_bonus_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: rank_bonus_funding rank_bonus_funding_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rank_bonus_funding_append_only BEFORE DELETE OR UPDATE ON public.rank_bonus_funding FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: rank_bonus_programs rank_bonus_programs_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rank_bonus_programs_append_only BEFORE DELETE OR UPDATE ON public.rank_bonus_programs FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: ranks ranks_enforce_product_binary_rate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ranks_enforce_product_binary_rate BEFORE INSERT OR UPDATE OF pair_income ON public.ranks FOR EACH ROW EXECUTE FUNCTION public.enforce_fixed_product_binary_rank_rate();


--
-- Name: registration_financials registration_financials_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER registration_financials_append_only BEFORE DELETE OR UPDATE ON public.registration_financials FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: registration_financials registration_financials_create_binary_reserve_lot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER registration_financials_create_binary_reserve_lot AFTER INSERT ON public.registration_financials FOR EACH ROW EXECUTE FUNCTION public.create_binary_reserve_lot_for_registration();


--
-- Name: registration_financials registration_financials_match_pin_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER registration_financials_match_pin_snapshot BEFORE INSERT ON public.registration_financials FOR EACH ROW EXECUTE FUNCTION public.validate_registration_financial_against_pin();


--
-- Name: registration_financials registration_financials_require_binary_settlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER registration_financials_require_binary_settlement AFTER INSERT ON public.registration_financials DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_registration_binary_settlement();


--
-- Name: registration_financials registration_financials_require_direct_referral_settlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER registration_financials_require_direct_referral_settlement AFTER INSERT ON public.registration_financials DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_direct_referral_settlement_for_registration();


--
-- Name: registration_financials registration_financials_validate_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER registration_financials_validate_snapshot BEFORE INSERT ON public.registration_financials FOR EACH ROW EXECUTE FUNCTION public.validate_financial_snapshot();


--
-- Name: request_receipts request_receipts_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER request_receipts_immutable BEFORE DELETE OR UPDATE ON public.request_receipts FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: request_receipts request_receipts_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER request_receipts_no_truncate BEFORE TRUNCATE ON public.request_receipts FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reseller_deactivation_events reseller_deactivation_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reseller_deactivation_events_append_only BEFORE DELETE OR UPDATE ON public.reseller_deactivation_events FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reseller_deactivation_events reseller_deactivation_events_liquidate_payables; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reseller_deactivation_events_liquidate_payables AFTER INSERT ON public.reseller_deactivation_events FOR EACH ROW EXECUTE FUNCTION public.liquidate_deactivation_payable_lots();


--
-- Name: reseller_deactivation_events reseller_deactivation_events_stamp_liability_version; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reseller_deactivation_events_stamp_liability_version BEFORE INSERT ON public.reseller_deactivation_events FOR EACH ROW EXECUTE FUNCTION public.stamp_deactivation_liability_version();


--
-- Name: reseller_deactivation_events reseller_deactivation_events_verify_fresh_zero_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER reseller_deactivation_events_verify_fresh_zero_state AFTER INSERT ON public.reseller_deactivation_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_deactivation_fresh_zero_state();


--
-- Name: reseller_deactivation_events reseller_deactivation_events_verify_liquidation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER reseller_deactivation_events_verify_liquidation AFTER INSERT ON public.reseller_deactivation_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_deactivation_financial_liquidation();


--
-- Name: product_reward_claim_allocations reward_claim_allocations_seed_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_claim_allocations_seed_stock AFTER INSERT ON public.product_reward_claim_allocations FOR EACH ROW EXECUTE FUNCTION public.seed_reward_stock_unit();


--
-- Name: reward_stock_dispatch_items reward_stock_dispatch_items_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_dispatch_items_protect BEFORE INSERT OR DELETE OR UPDATE ON public.reward_stock_dispatch_items FOR EACH ROW EXECUTE FUNCTION public.protect_reward_stock_dispatch_item();


--
-- Name: reward_stock_dispatches reward_stock_dispatches_fulfill; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_dispatches_fulfill AFTER INSERT ON public.reward_stock_dispatches FOR EACH ROW EXECUTE FUNCTION public.fulfill_reward_stock_dispatch();


--
-- Name: reward_stock_dispatches reward_stock_dispatches_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_dispatches_immutable BEFORE DELETE OR UPDATE ON public.reward_stock_dispatches FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_dispatches reward_stock_dispatches_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_dispatches_no_truncate BEFORE TRUNCATE ON public.reward_stock_dispatches FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_dispatches reward_stock_dispatches_validate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_dispatches_validate BEFORE INSERT ON public.reward_stock_dispatches FOR EACH ROW EXECUTE FUNCTION public.validate_reward_stock_dispatch();


--
-- Name: reward_stock_dispatch_items reward_stock_items_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_items_no_truncate BEFORE TRUNCATE ON public.reward_stock_dispatch_items FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_receipts reward_stock_receipts_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_receipts_immutable BEFORE DELETE OR UPDATE ON public.reward_stock_receipts FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_receipts reward_stock_receipts_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_receipts_no_truncate BEFORE TRUNCATE ON public.reward_stock_receipts FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_receipts reward_stock_receipts_receive; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_receipts_receive BEFORE INSERT ON public.reward_stock_receipts FOR EACH ROW EXECUTE FUNCTION public.receive_reward_stock_dispatch();


--
-- Name: reward_stock_units reward_stock_units_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_units_no_truncate BEFORE TRUNCATE ON public.reward_stock_units FOR EACH STATEMENT EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: reward_stock_units reward_stock_units_protect; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reward_stock_units_protect BEFORE INSERT OR DELETE OR UPDATE ON public.reward_stock_units FOR EACH ROW EXECUTE FUNCTION public.protect_reward_stock_unit();


--
-- Name: orders set_order_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_order_number BEFORE INSERT ON public.orders FOR EACH ROW WHEN ((new.order_number IS NULL)) EXECUTE FUNCTION public.generate_order_number();


--
-- Name: unilevel_payout_consumptions unilevel_consumptions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_consumptions_immutable BEFORE DELETE OR UPDATE ON public.unilevel_payout_consumptions FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_inventory_reserves unilevel_earmark_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_earmark_stock AFTER INSERT ON public.product_binary_inventory_reserves FOR EACH ROW EXECUTE FUNCTION public.earmark_unilevel_stock();


--
-- Name: unilevel_inventory_earmarks unilevel_inventory_earmarks_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_inventory_earmarks_append_only BEFORE DELETE OR UPDATE ON public.unilevel_inventory_earmarks FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: unilevel_order_allocations unilevel_order_allocations_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_order_allocations_append_only BEFORE DELETE OR UPDATE ON public.unilevel_order_allocations FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: unilevel_payable_lots unilevel_payable_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_payable_protected BEFORE DELETE OR UPDATE ON public.unilevel_payable_lots FOR EACH ROW EXECUTE FUNCTION public.require_internal_financial_ledger_write();


--
-- Name: unilevel_qualified_orders unilevel_qualified_orders_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_qualified_orders_immutable BEFORE DELETE OR UPDATE ON public.unilevel_qualified_orders FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: unilevel_qualified_recipients unilevel_qualified_recipients_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_qualified_recipients_immutable BEFORE DELETE OR UPDATE ON public.unilevel_qualified_recipients FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: unilevel_retention_entries unilevel_retention_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_retention_immutable BEFORE DELETE OR UPDATE ON public.unilevel_retention_entries FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: unilevel_order_settlements unilevel_settlements_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_settlements_immutable BEFORE DELETE OR UPDATE ON public.unilevel_order_settlements FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: product_binary_order_events unilevel_snapshot_order_allocations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER unilevel_snapshot_order_allocations AFTER INSERT ON public.product_binary_order_events FOR EACH ROW EXECUTE FUNCTION public.snapshot_unilevel_order_allocations();


--
-- Name: upgrade_financials upgrade_financials_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER upgrade_financials_append_only BEFORE DELETE OR UPDATE ON public.upgrade_financials FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: upgrade_financials upgrade_financials_create_binary_reserve_lot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER upgrade_financials_create_binary_reserve_lot AFTER INSERT ON public.upgrade_financials FOR EACH ROW EXECUTE FUNCTION public.create_binary_reserve_lot_for_upgrade();


--
-- Name: upgrade_financials upgrade_financials_match_pin_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER upgrade_financials_match_pin_snapshot BEFORE INSERT ON public.upgrade_financials FOR EACH ROW EXECUTE FUNCTION public.validate_upgrade_financial_against_pin();


--
-- Name: upgrade_financials upgrade_financials_require_binary_settlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER upgrade_financials_require_binary_settlement AFTER INSERT ON public.upgrade_financials DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.require_upgrade_binary_settlement();


--
-- Name: upgrade_financials upgrade_financials_validate_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER upgrade_financials_validate_snapshot BEFORE INSERT ON public.upgrade_financials FOR EACH ROW EXECUTE FUNCTION public.validate_financial_snapshot();


--
-- Name: users users_lifetime_person_accounts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER users_lifetime_person_accounts AFTER INSERT OR UPDATE ON public.users DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.enforce_lifetime_person_accounts();


--
-- Name: users users_preserve_reseller_payout_recipient; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER users_preserve_reseller_payout_recipient BEFORE UPDATE OF role ON public.users FOR EACH ROW EXECUTE FUNCTION public.prevent_payout_recipient_role_change();


--
-- Name: users users_require_member_id_issuance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER users_require_member_id_issuance BEFORE INSERT OR UPDATE OF member_id ON public.users FOR EACH ROW EXECUTE FUNCTION public.validate_user_member_id();


--
-- Name: users users_track_product_binary_account_hold; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER users_track_product_binary_account_hold BEFORE UPDATE OF status ON public.users FOR EACH ROW WHEN (((old.role = 'reseller'::public."Role") AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.track_product_binary_account_hold();


--
-- Name: users users_verify_reseller_status_transition; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER users_verify_reseller_status_transition AFTER UPDATE OF status ON public.users DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_reseller_status_transition();


--
-- Name: wallet_ledger_entries wallet_ledger_entries_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wallet_ledger_entries_append_only BEFORE DELETE OR UPDATE ON public.wallet_ledger_entries FOR EACH ROW EXECUTE FUNCTION public.reject_financial_history_change();


--
-- Name: wallet_ledger_entries wallet_ledger_entries_apply; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wallet_ledger_entries_apply AFTER INSERT ON public.wallet_ledger_entries FOR EACH ROW EXECUTE FUNCTION public.apply_wallet_ledger_entry();


--
-- Name: wallet_ledger_entries wallet_ledger_entries_author_timestamp; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wallet_ledger_entries_author_timestamp BEFORE INSERT ON public.wallet_ledger_entries FOR EACH ROW EXECUTE FUNCTION public.author_wallet_ledger_timestamp();


--
-- Name: wallets wallets_protect_balances; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wallets_protect_balances BEFORE INSERT OR DELETE OR UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.protect_wallet_balances();


--
-- Name: payouts zz_payouts_allocate_binary_payable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_payouts_allocate_binary_payable AFTER INSERT OR UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.allocate_approved_binary_payout();


--
-- Name: payouts zzz_payouts_allocate_product_binary; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzz_payouts_allocate_product_binary AFTER INSERT OR UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.allocate_approved_product_binary_payout();


--
-- Name: payouts zzz_payouts_allocate_rank_bonus; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzz_payouts_allocate_rank_bonus AFTER INSERT OR UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.allocate_rank_bonus_payout();


--
-- Name: payouts zzzz_payouts_allocate_unilevel; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_payouts_allocate_unilevel AFTER INSERT OR UPDATE OF status ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.allocate_unilevel_payout();


--
-- Name: payouts zzzz_payouts_require_full_source_allocation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_payouts_require_full_source_allocation AFTER INSERT OR UPDATE OF status, user_id, amount ON public.payouts FOR EACH ROW EXECUTE FUNCTION public.require_fully_allocated_approved_payout();


--
-- Name: commissions zzzzzz_commissions_apply_wallet_credit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzzz_commissions_apply_wallet_credit AFTER INSERT ON public.commissions FOR EACH ROW EXECUTE FUNCTION public.apply_commission_wallet_credit();


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipt_items
    ADD CONSTRAINT admin_stock_receipt_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: admin_stock_receipt_items admin_stock_receipt_items_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipt_items
    ADD CONSTRAINT admin_stock_receipt_items_receipt_id_fkey FOREIGN KEY (receipt_id) REFERENCES public.admin_stock_receipts(id) ON DELETE RESTRICT;


--
-- Name: admin_stock_receipts admin_stock_receipts_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_stock_receipts
    ADD CONSTRAINT admin_stock_receipts_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: binary_daily_cap_usage binary_daily_cap_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_daily_cap_usage
    ADD CONSTRAINT binary_daily_cap_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: binary_pair_events binary_pair_events_cap_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_cap_policy_id_fkey FOREIGN KEY (cap_policy_id) REFERENCES public.package_binary_cap_policies(id);


--
-- Name: binary_pair_events binary_pair_events_carryover_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_carryover_policy_id_fkey FOREIGN KEY (carryover_policy_id) REFERENCES public.package_binary_carryover_policies(id);


--
-- Name: binary_pair_events binary_pair_events_flashout_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_flashout_commission_fkey FOREIGN KEY (flashout_commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_pair_events binary_pair_events_normal_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_normal_commission_fkey FOREIGN KEY (normal_commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_pair_events binary_pair_events_reward_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_pair_events
    ADD CONSTRAINT binary_pair_events_reward_product_id_fkey FOREIGN KEY (reward_product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: binary_payable_lots binary_payable_lots_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payable_lots
    ADD CONSTRAINT binary_payable_lots_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_payout_consumptions binary_payout_consumptions_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payout_consumptions
    ADD CONSTRAINT binary_payout_consumptions_lot_fkey FOREIGN KEY (payable_lot_id) REFERENCES public.binary_payable_lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_payout_consumptions binary_payout_consumptions_payout_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_payout_consumptions
    ADD CONSTRAINT binary_payout_consumptions_payout_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_consumptions binary_point_consumptions_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_consumptions
    ADD CONSTRAINT binary_point_consumptions_event_fkey FOREIGN KEY (binary_pair_event_id) REFERENCES public.binary_pair_events(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_consumptions binary_point_consumptions_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_consumptions
    ADD CONSTRAINT binary_point_consumptions_lot_fkey FOREIGN KEY (point_lot_id) REFERENCES public.binary_point_lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_expirations binary_point_expirations_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_expirations
    ADD CONSTRAINT binary_point_expirations_lot_fkey FOREIGN KEY (point_lot_id) REFERENCES public.binary_point_lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_expirations binary_point_expirations_recipient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_expirations
    ADD CONSTRAINT binary_point_expirations_recipient_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_lots binary_point_lots_recipient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_lots
    ADD CONSTRAINT binary_point_lots_recipient_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_point_lots binary_point_lots_source_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_point_lots
    ADD CONSTRAINT binary_point_lots_source_fkey FOREIGN KEY (source_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_reserve_consumptions binary_reserve_consumptions_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_consumptions
    ADD CONSTRAINT binary_reserve_consumptions_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_reserve_consumptions binary_reserve_consumptions_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_consumptions
    ADD CONSTRAINT binary_reserve_consumptions_lot_fkey FOREIGN KEY (reserve_lot_id) REFERENCES public.binary_reserve_lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_reserve_lots binary_reserve_lots_registration_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_lots
    ADD CONSTRAINT binary_reserve_lots_registration_fkey FOREIGN KEY (registration_financial_id) REFERENCES public.registration_financials(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_reserve_lots binary_reserve_lots_upgrade_financial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_reserve_lots
    ADD CONSTRAINT binary_reserve_lots_upgrade_financial_id_fkey FOREIGN KEY (upgrade_financial_id) REFERENCES public.upgrade_financials(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: binary_tree_nodes binary_tree_nodes_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_tree_nodes
    ADD CONSTRAINT binary_tree_nodes_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.binary_tree_nodes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: binary_tree_nodes binary_tree_nodes_sponsor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_tree_nodes
    ADD CONSTRAINT binary_tree_nodes_sponsor_id_fkey FOREIGN KEY (sponsor_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: binary_tree_nodes binary_tree_nodes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_tree_nodes
    ADD CONSTRAINT binary_tree_nodes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commissions commissions_overflow_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_overflow_to_fkey FOREIGN KEY (overflow_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: commissions commissions_source_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_source_user_id_fkey FOREIGN KEY (source_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: commissions commissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_payout_consumptions
    ADD CONSTRAINT direct_referral_payout_consumptions_lot_fkey FOREIGN KEY (reserve_lot_id) REFERENCES public.direct_referral_reserve_lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: direct_referral_payout_consumptions direct_referral_payout_consumptions_payout_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_payout_consumptions
    ADD CONSTRAINT direct_referral_payout_consumptions_payout_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: direct_referral_reserve_lots direct_referral_reserve_lots_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_reserve_lots
    ADD CONSTRAINT direct_referral_reserve_lots_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: direct_referral_settlement_events direct_referral_settlement_normal_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_settlement_events
    ADD CONSTRAINT direct_referral_settlement_normal_commission_fkey FOREIGN KEY (normal_commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: direct_referral_settlement_events direct_referral_settlement_registration_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_settlement_events
    ADD CONSTRAINT direct_referral_settlement_registration_fkey FOREIGN KEY (registration_financial_id) REFERENCES public.registration_financials(id) ON DELETE RESTRICT;


--
-- Name: direct_referral_settlement_events direct_referral_settlement_retained_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.direct_referral_settlement_events
    ADD CONSTRAINT direct_referral_settlement_retained_commission_fkey FOREIGN KEY (retained_commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: distributor_profiles distributor_profiles_parent_dist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_profiles
    ADD CONSTRAINT distributor_profiles_parent_dist_id_fkey FOREIGN KEY (parent_dist_id) REFERENCES public.distributor_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: distributor_profiles distributor_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_profiles
    ADD CONSTRAINT distributor_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: financial_operation_receipts financial_operation_receipts_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_operation_receipts
    ADD CONSTRAINT financial_operation_receipts_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: financial_operation_receipts financial_operation_receipts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_operation_receipts
    ADD CONSTRAINT financial_operation_receipts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: financial_operation_receipts financial_operation_receipts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_operation_receipts
    ADD CONSTRAINT financial_operation_receipts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.pins(id);


--
-- Name: hiro_conversations hiro_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hiro_conversations
    ADD CONSTRAINT hiro_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hiro_messages hiro_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hiro_messages
    ADD CONSTRAINT hiro_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.hiro_conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_audit_items inventory_audit_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_audit_items
    ADD CONSTRAINT inventory_audit_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.inventory_audit_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_audit_sessions inventory_audit_sessions_pos_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_audit_sessions
    ADD CONSTRAINT inventory_audit_sessions_pos_shift_id_fkey FOREIGN KEY (pos_shift_id) REFERENCES public.pos_shifts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory inventory_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_messages order_messages_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_messages
    ADD CONSTRAINT order_messages_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_messages order_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_messages
    ADD CONSTRAINT order_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_payment_evidence order_payment_evidence_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_payment_evidence
    ADD CONSTRAINT order_payment_evidence_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_replacement_requests order_replacement_requests_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_requests
    ADD CONSTRAINT order_replacement_requests_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: order_replacement_requests order_replacement_requests_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_requests
    ADD CONSTRAINT order_replacement_requests_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_replacement_requests order_replacement_requests_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_requests
    ADD CONSTRAINT order_replacement_requests_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_replacement_units order_replacement_units_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_units
    ADD CONSTRAINT order_replacement_units_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.order_replacement_requests(id);


--
-- Name: order_replacement_units order_replacement_units_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_replacement_units
    ADD CONSTRAINT order_replacement_units_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.reward_stock_units(id);


--
-- Name: orders orders_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: package_binary_cap_policies package_binary_cap_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_cap_policies
    ADD CONSTRAINT package_binary_cap_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: package_binary_cap_policies package_binary_cap_policies_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_cap_policies
    ADD CONSTRAINT package_binary_cap_policies_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_cap_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_cap_policy_id_fkey FOREIGN KEY (cap_policy_id) REFERENCES public.package_binary_cap_policies(id);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: package_binary_carryover_policies package_binary_carryover_policies_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_carryover_policies
    ADD CONSTRAINT package_binary_carryover_policies_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id);


--
-- Name: package_binary_product_rewards package_binary_product_rewards_pair_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_product_rewards
    ADD CONSTRAINT package_binary_product_rewards_pair_event_id_fkey FOREIGN KEY (pair_event_id) REFERENCES public.binary_pair_events(id) ON DELETE RESTRICT;


--
-- Name: package_binary_product_rewards package_binary_product_rewards_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_product_rewards
    ADD CONSTRAINT package_binary_product_rewards_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: package_binary_product_rewards package_binary_product_rewards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_binary_product_rewards
    ADD CONSTRAINT package_binary_product_rewards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: package_products package_products_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_products
    ADD CONSTRAINT package_products_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: package_products package_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_products
    ADD CONSTRAINT package_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: package_upgrade_paths package_upgrade_paths_from_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_paths
    ADD CONSTRAINT package_upgrade_paths_from_package_id_fkey FOREIGN KEY (from_package_id) REFERENCES public.packages(id) ON DELETE CASCADE;


--
-- Name: package_upgrade_paths package_upgrade_paths_to_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_paths
    ADD CONSTRAINT package_upgrade_paths_to_package_id_fkey FOREIGN KEY (to_package_id) REFERENCES public.packages(id) ON DELETE CASCADE;


--
-- Name: package_upgrade_products package_upgrade_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_products
    ADD CONSTRAINT package_upgrade_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: package_upgrade_products package_upgrade_products_upgrade_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_upgrade_products
    ADD CONSTRAINT package_upgrade_products_upgrade_path_id_fkey FOREIGN KEY (upgrade_path_id) REFERENCES public.package_upgrade_paths(id) ON DELETE CASCADE;


--
-- Name: pairing_logs pairing_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pairing_logs
    ADD CONSTRAINT pairing_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: passkey_challenges passkey_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_challenges
    ADD CONSTRAINT passkey_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passkey_credentials passkey_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_credentials
    ADD CONSTRAINT passkey_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_binary_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_binary_lot_fkey FOREIGN KEY (binary_lot_id) REFERENCES public.binary_payable_lots(id) ON DELETE RESTRICT;


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_direct_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_direct_lot_fkey FOREIGN KEY (direct_lot_id) REFERENCES public.direct_referral_reserve_lots(id) ON DELETE RESTRICT;


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_event_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_event_fkey FOREIGN KEY (deactivation_event_id) REFERENCES public.reseller_deactivation_events(id) ON DELETE RESTRICT;


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_product_binary_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_product_binary_lot_fkey FOREIGN KEY (product_binary_lot_id) REFERENCES public.product_binary_payable_lots(id) ON DELETE RESTRICT;


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_rank_bonus_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_rank_bonus_lot_id_fkey FOREIGN KEY (rank_bonus_lot_id) REFERENCES public.rank_bonus_awards(id);


--
-- Name: payable_lot_forfeitures payable_lot_forfeitures_unilevel_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payable_lot_forfeitures
    ADD CONSTRAINT payable_lot_forfeitures_unilevel_lot_id_fkey FOREIGN KEY (unilevel_lot_id) REFERENCES public.unilevel_payable_lots(id);


--
-- Name: payment_methods payment_methods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payouts payouts_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT payouts_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payouts payouts_released_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT payouts_released_by_fkey FOREIGN KEY (released_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payouts payouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT payouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: person_account_documents person_account_documents_person_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_documents
    ADD CONSTRAINT person_account_documents_person_key_fkey FOREIGN KEY (person_key) REFERENCES public.person_account_totals(person_key);


--
-- Name: person_account_memberships person_account_memberships_person_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_memberships
    ADD CONSTRAINT person_account_memberships_person_key_fkey FOREIGN KEY (person_key) REFERENCES public.person_account_totals(person_key);


--
-- Name: person_account_memberships person_account_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_account_memberships
    ADD CONSTRAINT person_account_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: pin_registration_product_snapshots pin_registration_product_snapshots_pin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_registration_product_snapshots
    ADD CONSTRAINT pin_registration_product_snapshots_pin_id_fkey FOREIGN KEY (pin_id) REFERENCES public.pins(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pin_registration_product_snapshots pin_registration_product_snapshots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_registration_product_snapshots
    ADD CONSTRAINT pin_registration_product_snapshots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pin_request_payment_evidence pin_request_payment_evidence_pin_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_request_payment_evidence
    ADD CONSTRAINT pin_request_payment_evidence_pin_request_id_fkey FOREIGN KEY (pin_request_id) REFERENCES public.pin_requests(id) ON DELETE RESTRICT;


--
-- Name: pin_requests pin_requests_city_dist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_requests
    ADD CONSTRAINT pin_requests_city_dist_id_fkey FOREIGN KEY (city_dist_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pin_requests pin_requests_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_requests
    ADD CONSTRAINT pin_requests_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pin_transfers pin_transfers_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: pin_transfers pin_transfers_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON DELETE RESTRICT;


--
-- Name: pin_transfers pin_transfers_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: pin_transfers pin_transfers_upgrade_from_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_transfers
    ADD CONSTRAINT pin_transfers_upgrade_from_package_id_fkey FOREIGN KEY (upgrade_from_package_id) REFERENCES public.packages(id) ON DELETE RESTRICT;


--
-- Name: pin_upgrade_product_snapshots pin_upgrade_product_snapshots_pin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_upgrade_product_snapshots
    ADD CONSTRAINT pin_upgrade_product_snapshots_pin_id_fkey FOREIGN KEY (pin_id) REFERENCES public.pins(id) ON DELETE CASCADE;


--
-- Name: pin_upgrade_product_snapshots pin_upgrade_product_snapshots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_upgrade_product_snapshots
    ADD CONSTRAINT pin_upgrade_product_snapshots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: pins pins_city_dist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_city_dist_id_fkey FOREIGN KEY (city_dist_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pins pins_funding_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_funding_order_id_fkey FOREIGN KEY (funding_order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pins pins_funding_pin_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_funding_pin_request_id_fkey FOREIGN KEY (funding_pin_request_id) REFERENCES public.pin_requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pins pins_funding_pin_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_funding_pin_transfer_id_fkey FOREIGN KEY (funding_pin_transfer_id) REFERENCES public.pin_transfers(id) ON DELETE RESTRICT;


--
-- Name: pins pins_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pins pins_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pins pins_used_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pins
    ADD CONSTRAINT pins_used_by_fkey FOREIGN KEY (used_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pos_adjustment_items pos_adjustment_items_request_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_items
    ADD CONSTRAINT pos_adjustment_items_request_fkey FOREIGN KEY (adjustment_request_id) REFERENCES public.pos_adjustment_requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_adjustment_items pos_adjustment_items_transaction_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_items
    ADD CONSTRAINT pos_adjustment_items_transaction_item_fkey FOREIGN KEY (pos_transaction_item_id) REFERENCES public.pos_transaction_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_adjustment_requests pos_adjustment_requests_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_requests
    ADD CONSTRAINT pos_adjustment_requests_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_adjustment_requests pos_adjustment_requests_pos_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_requests
    ADD CONSTRAINT pos_adjustment_requests_pos_transaction_id_fkey FOREIGN KEY (pos_transaction_id) REFERENCES public.pos_transactions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_adjustment_requests pos_adjustment_requests_requested_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_requests
    ADD CONSTRAINT pos_adjustment_requests_requested_by_id_fkey FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_adjustment_requests pos_adjustment_requests_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_adjustment_requests
    ADD CONSTRAINT pos_adjustment_requests_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_cash_movements pos_cash_movements_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_cash_movements pos_cash_movements_requested_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_requested_by_id_fkey FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_cash_movements pos_cash_movements_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_cash_movements pos_cash_movements_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.pos_shifts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_cash_movements pos_cash_movements_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cash_movements
    ADD CONSTRAINT pos_cash_movements_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_inventory_allowances pos_inventory_allowances_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_inventory_allowances
    ADD CONSTRAINT pos_inventory_allowances_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_inventory_allowances pos_inventory_allowances_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_inventory_allowances
    ADD CONSTRAINT pos_inventory_allowances_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_registration_events pos_registration_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_events
    ADD CONSTRAINT pos_registration_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_events pos_registration_events_intake_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_events
    ADD CONSTRAINT pos_registration_events_intake_id_fkey FOREIGN KEY (intake_id) REFERENCES public.pos_registration_intakes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_registration_intakes pos_registration_intakes_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_cashier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_cashier_id_fkey FOREIGN KEY (cashier_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_completed_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_completed_user_id_fkey FOREIGN KEY (completed_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_encoder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_encoder_id_fkey FOREIGN KEY (encoder_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_pin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_pin_id_fkey FOREIGN KEY (pin_id) REFERENCES public.pins(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_released_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_released_by_id_fkey FOREIGN KEY (released_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.pos_shifts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_registration_intakes pos_registration_intakes_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_registration_intakes
    ADD CONSTRAINT pos_registration_intakes_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_shifts pos_shifts_closed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_shifts
    ADD CONSTRAINT pos_shifts_closed_by_id_fkey FOREIGN KEY (closed_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_shifts pos_shifts_opened_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_shifts
    ADD CONSTRAINT pos_shifts_opened_by_id_fkey FOREIGN KEY (opened_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_shifts pos_shifts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_shifts
    ADD CONSTRAINT pos_shifts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_shifts pos_shifts_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_shifts
    ADD CONSTRAINT pos_shifts_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_sync_events pos_sync_events_pos_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_sync_events
    ADD CONSTRAINT pos_sync_events_pos_transaction_id_fkey FOREIGN KEY (pos_transaction_id) REFERENCES public.pos_transactions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pos_sync_events pos_sync_events_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_sync_events
    ADD CONSTRAINT pos_sync_events_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_terminal_enrollments pos_terminal_enrollments_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminal_enrollments
    ADD CONSTRAINT pos_terminal_enrollments_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_terminal_enrollments pos_terminal_enrollments_enrolled_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminal_enrollments
    ADD CONSTRAINT pos_terminal_enrollments_enrolled_terminal_id_fkey FOREIGN KEY (enrolled_terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pos_terminal_enrollments pos_terminal_enrollments_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminal_enrollments
    ADD CONSTRAINT pos_terminal_enrollments_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_terminals pos_terminals_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_terminals
    ADD CONSTRAINT pos_terminals_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transaction_items pos_transaction_items_pos_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_pos_transaction_id_fkey FOREIGN KEY (pos_transaction_id) REFERENCES public.pos_transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_transaction_items pos_transaction_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_cashier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_cashier_id_fkey FOREIGN KEY (cashier_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.pos_shifts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pos_transactions pos_transactions_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_area_visibility product_area_visibility_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_area_visibility
    ADD CONSTRAINT product_area_visibility_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_profiles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_area_visibility product_area_visibility_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_area_visibility
    ADD CONSTRAINT product_area_visibility_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_binary_account_holds product_binary_account_holds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_account_holds
    ADD CONSTRAINT product_binary_account_holds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: product_binary_payout_consumptions product_binary_consumption_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payout_consumptions
    ADD CONSTRAINT product_binary_consumption_lot_fkey FOREIGN KEY (payable_lot_id) REFERENCES public.product_binary_payable_lots(id) ON DELETE RESTRICT;


--
-- Name: product_binary_payout_consumptions product_binary_consumption_payout_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payout_consumptions
    ADD CONSTRAINT product_binary_consumption_payout_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id) ON DELETE RESTRICT;


--
-- Name: product_binary_funding_consumptions product_binary_funding_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_consumptions
    ADD CONSTRAINT product_binary_funding_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: product_binary_funding_consumptions product_binary_funding_lot_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_consumptions
    ADD CONSTRAINT product_binary_funding_lot_fkey FOREIGN KEY (funding_lot_id) REFERENCES public.product_binary_funding_lots(id) ON DELETE RESTRICT;


--
-- Name: product_binary_funding_lots product_binary_funding_lots_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_lots
    ADD CONSTRAINT product_binary_funding_lots_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE RESTRICT;


--
-- Name: product_binary_funding_lots product_binary_funding_movement_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_funding_lots
    ADD CONSTRAINT product_binary_funding_movement_fkey FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE RESTRICT;


--
-- Name: product_binary_inventory_reserve_transfers product_binary_inventory_reserve_tran_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserve_transfers
    ADD CONSTRAINT product_binary_inventory_reserve_tran_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.product_binary_inventory_reserves(source_order_item_id);


--
-- Name: product_binary_inventory_reserve_transfers product_binary_inventory_reserve_transfers_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserve_transfers
    ADD CONSTRAINT product_binary_inventory_reserve_transfers_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_pool_orders(order_event_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_binary_inventory_reserves product_binary_inventory_reserves_city_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserves
    ADD CONSTRAINT product_binary_inventory_reserves_city_order_item_id_fkey FOREIGN KEY (city_order_item_id) REFERENCES public.order_items(id);


--
-- Name: product_binary_inventory_reserves product_binary_inventory_reserves_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserves
    ADD CONSTRAINT product_binary_inventory_reserves_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.users(id);


--
-- Name: product_binary_inventory_reserves product_binary_inventory_reserves_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserves
    ADD CONSTRAINT product_binary_inventory_reserves_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_binary_inventory_reserves product_binary_inventory_reserves_source_movement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_inventory_reserves
    ADD CONSTRAINT product_binary_inventory_reserves_source_movement_id_fkey FOREIGN KEY (source_movement_id) REFERENCES public.inventory_movements(id);


--
-- Name: product_binary_payable_lots product_binary_lot_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_payable_lots
    ADD CONSTRAINT product_binary_lot_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: product_binary_non_member_reserve_restorations product_binary_non_member_res_order_id_source_order_item_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_restorations
    ADD CONSTRAINT product_binary_non_member_res_order_id_source_order_item_i_fkey FOREIGN KEY (order_id, source_order_item_id) REFERENCES public.product_binary_non_member_reserve_releases(order_id, source_order_item_id);


--
-- Name: product_binary_non_member_reserve_processed product_binary_non_member_reserve_processed_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_processed
    ADD CONSTRAINT product_binary_non_member_reserve_processed_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: product_binary_non_member_reserve_releases product_binary_non_member_reserve_rel_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_releases
    ADD CONSTRAINT product_binary_non_member_reserve_rel_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.product_binary_inventory_reserves(source_order_item_id);


--
-- Name: product_binary_non_member_reserve_releases product_binary_non_member_reserve_releases_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_releases
    ADD CONSTRAINT product_binary_non_member_reserve_releases_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: product_binary_non_member_reserve_restorations product_binary_non_member_reserve_restoratio_adjustment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_non_member_reserve_restorations
    ADD CONSTRAINT product_binary_non_member_reserve_restoratio_adjustment_id_fkey FOREIGN KEY (adjustment_id) REFERENCES public.pos_adjustment_requests(id);


--
-- Name: product_binary_order_events product_binary_order_events_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_order_events
    ADD CONSTRAINT product_binary_order_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE RESTRICT;


--
-- Name: product_binary_order_events product_binary_order_events_settlement_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_order_events
    ADD CONSTRAINT product_binary_order_events_settlement_job_id_fkey FOREIGN KEY (settlement_job_id) REFERENCES public.product_binary_settlement_jobs(id) ON DELETE RESTRICT;


--
-- Name: product_binary_package_reserve_releases product_binary_package_reserve_releases_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_package_reserve_releases
    ADD CONSTRAINT product_binary_package_reserve_releases_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_binary_pair_events product_binary_pair_flash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_flash_fkey FOREIGN KEY (flashout_commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: product_binary_pair_events product_binary_pair_normal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_normal_fkey FOREIGN KEY (normal_commission_id) REFERENCES public.commissions(id) ON DELETE RESTRICT;


--
-- Name: product_binary_pair_events product_binary_pair_order_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pair_events
    ADD CONSTRAINT product_binary_pair_order_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_order_events(id) ON DELETE RESTRICT;


--
-- Name: product_binary_pool_allocations product_binary_pool_allocations_commission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_allocations
    ADD CONSTRAINT product_binary_pool_allocations_commission_id_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id);


--
-- Name: product_binary_pool_allocations product_binary_pool_allocations_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_allocations
    ADD CONSTRAINT product_binary_pool_allocations_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id);


--
-- Name: product_binary_pool_allocations product_binary_pool_allocations_week_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_allocations
    ADD CONSTRAINT product_binary_pool_allocations_week_start_fkey FOREIGN KEY (week_start) REFERENCES public.product_binary_pool_weeks(week_start);


--
-- Name: product_binary_pool_orders product_binary_pool_orders_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_orders
    ADD CONSTRAINT product_binary_pool_orders_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_order_events(id);


--
-- Name: product_binary_pool_orders product_binary_pool_orders_week_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_orders
    ADD CONSTRAINT product_binary_pool_orders_week_start_fkey FOREIGN KEY (week_start) REFERENCES public.product_binary_pool_weeks(week_start);


--
-- Name: product_binary_pool_pairs product_binary_pool_pairs_pair_event_id_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_pairs
    ADD CONSTRAINT product_binary_pool_pairs_pair_event_id_order_event_id_fkey FOREIGN KEY (pair_event_id, order_event_id) REFERENCES public.product_binary_pair_events(id, order_event_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_binary_pool_pairs product_binary_pool_pairs_week_start_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pool_pairs
    ADD CONSTRAINT product_binary_pool_pairs_week_start_order_event_id_fkey FOREIGN KEY (week_start, order_event_id) REFERENCES public.product_binary_pool_orders(week_start, order_event_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_binary_prepared_recipients product_binary_prepared_recipients_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_prepared_recipients
    ADD CONSTRAINT product_binary_prepared_recipients_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id);


--
-- Name: product_binary_prepared_recipients product_binary_prepared_recipients_week_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_prepared_recipients
    ADD CONSTRAINT product_binary_prepared_recipients_week_start_fkey FOREIGN KEY (week_start) REFERENCES public.product_binary_week_preparation(week_start);


--
-- Name: product_binary_pu_lots product_binary_pu_lots_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pu_lots
    ADD CONSTRAINT product_binary_pu_lots_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_order_events(id);


--
-- Name: product_binary_pu_lots product_binary_pu_lots_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_pu_lots
    ADD CONSTRAINT product_binary_pu_lots_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES public.users(id);


--
-- Name: product_binary_replacement_reserve_processed product_binary_replacement_reserve_processed_dispatch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_replacement_reserve_processed
    ADD CONSTRAINT product_binary_replacement_reserve_processed_dispatch_id_fkey FOREIGN KEY (dispatch_id) REFERENCES public.reward_stock_dispatches(id);


--
-- Name: product_binary_replacement_reserve_releases product_binary_replacement_reserve_re_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_replacement_reserve_releases
    ADD CONSTRAINT product_binary_replacement_reserve_re_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.product_binary_inventory_reserves(source_order_item_id);


--
-- Name: product_binary_replacement_reserve_releases product_binary_replacement_reserve_releases_dispatch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_replacement_reserve_releases
    ADD CONSTRAINT product_binary_replacement_reserve_releases_dispatch_id_fkey FOREIGN KEY (dispatch_id) REFERENCES public.reward_stock_dispatches(id);


--
-- Name: product_binary_settlement_jobs product_binary_settlement_jobs_order_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_settlement_jobs
    ADD CONSTRAINT product_binary_settlement_jobs_order_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_binary_settlement_jobs product_binary_settlement_jobs_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_settlement_jobs
    ADD CONSTRAINT product_binary_settlement_jobs_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE RESTRICT;


--
-- Name: product_binary_week_funding product_binary_week_funding_week_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_week_funding
    ADD CONSTRAINT product_binary_week_funding_week_start_fkey FOREIGN KEY (week_start) REFERENCES public.product_binary_pool_weeks(week_start);


--
-- Name: product_binary_week_preparation product_binary_week_preparation_week_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_binary_week_preparation
    ADD CONSTRAINT product_binary_week_preparation_week_start_fkey FOREIGN KEY (week_start) REFERENCES public.product_binary_pool_weeks(week_start);


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_claim_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_allocations
    ADD CONSTRAINT product_reward_claim_allocations_claim_id_fkey FOREIGN KEY (claim_id) REFERENCES public.product_reward_claims(id);


--
-- Name: product_reward_claim_allocations product_reward_claim_allocations_reward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_allocations
    ADD CONSTRAINT product_reward_claim_allocations_reward_id_fkey FOREIGN KEY (reward_id) REFERENCES public.package_binary_product_rewards(id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.users(id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.pos_shifts(id);


--
-- Name: product_reward_claim_proofs product_reward_claim_proofs_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claim_proofs
    ADD CONSTRAINT product_reward_claim_proofs_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id);


--
-- Name: product_reward_claims product_reward_claims_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: product_reward_claims product_reward_claims_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: product_reward_claims product_reward_claims_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_reward_claims product_reward_claims_proof_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_proof_id_fkey FOREIGN KEY (proof_id) REFERENCES public.product_reward_claim_proofs(id);


--
-- Name: product_reward_claims product_reward_claims_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.users(id);


--
-- Name: product_reward_claims product_reward_claims_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.pos_shifts(id);


--
-- Name: product_reward_claims product_reward_claims_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reward_claims
    ADD CONSTRAINT product_reward_claims_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id);


--
-- Name: rank_bonus_awards rank_bonus_awards_commission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_commission_id_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rank_bonus_awards rank_bonus_awards_quarter_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_quarter_start_fkey FOREIGN KEY (quarter_start) REFERENCES public.rank_bonus_programs(quarter_start);


--
-- Name: rank_bonus_awards rank_bonus_awards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_awards
    ADD CONSTRAINT rank_bonus_awards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rank_bonus_funding rank_bonus_funding_funded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_funding
    ADD CONSTRAINT rank_bonus_funding_funded_by_fkey FOREIGN KEY (funded_by) REFERENCES public.users(id);


--
-- Name: rank_bonus_funding rank_bonus_funding_quarter_start_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_funding
    ADD CONSTRAINT rank_bonus_funding_quarter_start_fkey FOREIGN KEY (quarter_start) REFERENCES public.rank_bonus_programs(quarter_start);


--
-- Name: rank_bonus_payout_consumptions rank_bonus_payout_consumptions_award_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_payout_consumptions
    ADD CONSTRAINT rank_bonus_payout_consumptions_award_id_fkey FOREIGN KEY (award_id) REFERENCES public.rank_bonus_awards(id);


--
-- Name: rank_bonus_payout_consumptions rank_bonus_payout_consumptions_payout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_bonus_payout_consumptions
    ADD CONSTRAINT rank_bonus_payout_consumptions_payout_id_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id);


--
-- Name: rank_periods rank_periods_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rank_periods
    ADD CONSTRAINT rank_periods_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ranks ranks_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranks
    ADD CONSTRAINT ranks_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_deactivation_events reseller_deactivation_events_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_deactivation_events
    ADD CONSTRAINT reseller_deactivation_events_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: reseller_deactivation_events reseller_deactivation_events_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_deactivation_events
    ADD CONSTRAINT reseller_deactivation_events_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.users(id);


--
-- Name: reseller_profiles reseller_profiles_city_dist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_city_dist_id_fkey FOREIGN KEY (city_dist_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_profiles reseller_profiles_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_profiles reseller_profiles_pin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_pin_id_fkey FOREIGN KEY (pin_id) REFERENCES public.pins(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reseller_profiles reseller_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reseller_profiles
    ADD CONSTRAINT reseller_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reward_stock_dispatch_items reward_stock_dispatch_items_dispatch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatch_items
    ADD CONSTRAINT reward_stock_dispatch_items_dispatch_id_fkey FOREIGN KEY (dispatch_id) REFERENCES public.reward_stock_dispatches(id);


--
-- Name: reward_stock_dispatch_items reward_stock_dispatch_items_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatch_items
    ADD CONSTRAINT reward_stock_dispatch_items_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.reward_stock_units(id);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: reward_stock_dispatches reward_stock_dispatches_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_dispatches
    ADD CONSTRAINT reward_stock_dispatches_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.users(id);


--
-- Name: reward_stock_receipts reward_stock_receipts_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_receipts
    ADD CONSTRAINT reward_stock_receipts_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: reward_stock_receipts reward_stock_receipts_dispatch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_receipts
    ADD CONSTRAINT reward_stock_receipts_dispatch_id_fkey FOREIGN KEY (dispatch_id) REFERENCES public.reward_stock_dispatches(id);


--
-- Name: reward_stock_units reward_stock_units_claim_allocation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_claim_allocation_id_fkey FOREIGN KEY (claim_allocation_id) REFERENCES public.product_reward_claim_allocations(id);


--
-- Name: reward_stock_units reward_stock_units_dispatch_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_dispatch_fkey FOREIGN KEY (current_dispatch_id) REFERENCES public.reward_stock_dispatches(id);


--
-- Name: reward_stock_units reward_stock_units_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_holder_id_fkey FOREIGN KEY (holder_id) REFERENCES public.users(id);


--
-- Name: reward_stock_units reward_stock_units_origin_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_origin_outlet_id_fkey FOREIGN KEY (origin_outlet_id) REFERENCES public.users(id);


--
-- Name: reward_stock_units reward_stock_units_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reward_stock_units
    ADD CONSTRAINT reward_stock_units_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: staff_profiles staff_profiles_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: staff_profiles staff_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_profiles
    ADD CONSTRAINT staff_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_attachments support_attachments_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_attachments
    ADD CONSTRAINT support_attachments_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.support_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: support_messages support_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: support_messages support_messages_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.support_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: support_requests support_requests_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_requests
    ADD CONSTRAINT support_requests_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: support_requests support_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_requests
    ADD CONSTRAINT support_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: support_typing support_typing_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_typing
    ADD CONSTRAINT support_typing_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.support_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: unilevel_inventory_earmarks unilevel_inventory_earmarks_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_inventory_earmarks
    ADD CONSTRAINT unilevel_inventory_earmarks_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.product_binary_inventory_reserves(source_order_item_id);


--
-- Name: unilevel_order_allocations unilevel_order_allocations_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_order_allocations
    ADD CONSTRAINT unilevel_order_allocations_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_order_events(id);


--
-- Name: unilevel_order_allocations unilevel_order_allocations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_order_allocations
    ADD CONSTRAINT unilevel_order_allocations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: unilevel_order_settlements unilevel_order_settlements_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_order_settlements
    ADD CONSTRAINT unilevel_order_settlements_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.product_binary_order_events(id);


--
-- Name: unilevel_payable_lots unilevel_payable_lots_commission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_commission_id_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: unilevel_payable_lots unilevel_payable_lots_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.unilevel_order_settlements(order_event_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: unilevel_payable_lots unilevel_payable_lots_order_event_id_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_order_event_id_level_fkey FOREIGN KEY (order_event_id, level) REFERENCES public.unilevel_order_allocations(order_event_id, level);


--
-- Name: unilevel_payable_lots unilevel_payable_lots_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payable_lots
    ADD CONSTRAINT unilevel_payable_lots_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: unilevel_payout_consumptions unilevel_payout_consumptions_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payout_consumptions
    ADD CONSTRAINT unilevel_payout_consumptions_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.unilevel_payable_lots(id);


--
-- Name: unilevel_payout_consumptions unilevel_payout_consumptions_payout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_payout_consumptions
    ADD CONSTRAINT unilevel_payout_consumptions_payout_id_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id);


--
-- Name: unilevel_qualified_orders unilevel_qualified_orders_settlement_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_qualified_orders
    ADD CONSTRAINT unilevel_qualified_orders_settlement_job_id_fkey FOREIGN KEY (settlement_job_id) REFERENCES public.product_binary_settlement_jobs(id);


--
-- Name: unilevel_qualified_recipients unilevel_qualified_recipients_settlement_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_qualified_recipients
    ADD CONSTRAINT unilevel_qualified_recipients_settlement_job_id_fkey FOREIGN KEY (settlement_job_id) REFERENCES public.unilevel_qualified_orders(settlement_job_id);


--
-- Name: unilevel_qualified_recipients unilevel_qualified_recipients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_qualified_recipients
    ADD CONSTRAINT unilevel_qualified_recipients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: unilevel_retention_entries unilevel_retention_entries_order_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_retention_entries
    ADD CONSTRAINT unilevel_retention_entries_order_event_id_fkey FOREIGN KEY (order_event_id) REFERENCES public.unilevel_order_settlements(order_event_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: unilevel_retention_entries unilevel_retention_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unilevel_retention_entries
    ADD CONSTRAINT unilevel_retention_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: walk_in_member_scan_proofs walk_in_member_scan_proofs_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walk_in_member_scan_proofs
    ADD CONSTRAINT walk_in_member_scan_proofs_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: walk_in_member_scan_proofs walk_in_member_scan_proofs_reseller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walk_in_member_scan_proofs
    ADD CONSTRAINT walk_in_member_scan_proofs_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: wallet_ledger_entries wallet_ledger_entries_commission_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_commission_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: wallet_ledger_entries wallet_ledger_entries_payout_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_payout_fkey FOREIGN KEY (payout_id) REFERENCES public.payouts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: wallet_ledger_entries wallet_ledger_entries_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger_entries
    ADD CONSTRAINT wallet_ledger_entries_user_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--


